from rest_framework import serializers
from .models import Achievement


class AchievementSerializer(serializers.ModelSerializer):
    username = serializers.CharField(source='user.username', read_only=True)

    class Meta:
        model = Achievement
        fields = ['id', 'user', 'username', 'title', 'earned_at']
        read_only_fields = fields  # achievements are only ever created by the system
