from django.conf import settings
from django.db import models

from skills.models import Skill
from exchanges.models import SkillRequest


class Achievement(models.Model):
    """
    A record of a skill a user has *learned* (as opposed to Skill, which
    records what a user *teaches*). Created once a SkillRequest reaches
    'completed'. Shown on the learner's public profile.

    VALIDATION RULE (important — do not break this):
    Achievement is a completely separate table from Skill. Earning an
    achievement NEVER creates or modifies a Skill row, and it must never
    appear in skill search/browse results. A user only shows up as a
    teacher of something if they explicitly create their own Skill
    listing for it — learning a skill does not automatically make you
    a teacher of it.
    """
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='achievements',
    )
    skill = models.ForeignKey(
        Skill,
        on_delete=models.SET_NULL,
        null=True,
        related_name='achievements',
    )
    skill_request = models.OneToOneField(
        SkillRequest,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='achievement',
    )
    title = models.CharField(max_length=120)  # snapshot, survives if the Skill is later deleted
    earned_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-earned_at']

    def __str__(self):
        return f"{self.user.username} learned {self.title}"
