from rest_framework import viewsets, permissions

from .models import Achievement
from .serializers import AchievementSerializer


class AchievementViewSet(viewsets.ReadOnlyModelViewSet):
    """
    Read-only on purpose: achievements are never created or edited through
    the API directly. They are only ever created by the system, inside
    exchanges.views.SkillRequestViewSet.complete(), the moment a skill
    exchange is marked completed.

    GET /api/achievements/achievements/              -> your own achievements (JWT)
    GET /api/achievements/achievements/?user=<id>     -> another user's achievements (public)

    VALIDATION RULE: this list is ALWAYS separate from /api/skills/skills/.
    An achievement here never implies the user teaches this skill, and it
    will never appear in a skill search unless that same user separately
    creates their own Skill listing for it.
    """
    permission_classes = [permissions.IsAuthenticatedOrReadOnly]
    serializer_class = AchievementSerializer

    def get_queryset(self):
        user_id = self.request.query_params.get('user')
        if user_id:
            return Achievement.objects.filter(user_id=user_id)
        if self.request.user.is_authenticated:
            return Achievement.objects.filter(user=self.request.user)
        return Achievement.objects.none()
