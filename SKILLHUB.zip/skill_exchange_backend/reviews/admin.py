from django.contrib import admin
from .models import Review


@admin.register(Review)
class ReviewAdmin(admin.ModelAdmin):
    list_display = [
        'reviewer', 'reviewee', 'rating', 'sentiment_label', 'spam_score',
        'is_flagged_spam', 'is_reported', 'created_at',
    ]
    list_filter = ['rating', 'is_reported', 'is_flagged_spam', 'sentiment_label']
    search_fields = ['reviewer__username', 'reviewee__username', 'report_reason', 'flag_reasons']
