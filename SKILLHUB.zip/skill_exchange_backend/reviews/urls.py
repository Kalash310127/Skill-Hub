from django.urls import path
from rest_framework.routers import DefaultRouter
from .views import ReviewViewSet, user_rating_summary

router = DefaultRouter()
router.register(r'reviews', ReviewViewSet, basename='review')

urlpatterns = router.urls + [
    path('summary/<int:user_id>/', user_rating_summary, name='rating-summary'),
]
