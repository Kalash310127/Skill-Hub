from django.conf import settings
from django.core.validators import MaxValueValidator, MinValueValidator
from django.db import models

from exchanges.models import SkillRequest


class Review(models.Model):
    """
    A rating + comment left by the learner about the teacher, for one
    specific completed SkillRequest. One review per completed request
    (enforced by OneToOneField) so ratings can't be spammed.
    """
    skill_request = models.OneToOneField(
        SkillRequest,
        on_delete=models.CASCADE,
        related_name='review',
    )
    reviewer = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='reviews_given',
    )
    reviewee = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='reviews_received',
    )
    rating = models.PositiveSmallIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(5)]
    )
    comment = models.TextField(blank=True, default='')
    created_at = models.DateTimeField(auto_now_add=True)

    # --- Moderation / abuse reporting ---
    is_reported = models.BooleanField(default=False)
    report_reason = models.TextField(blank=True, default='')
    reported_at = models.DateTimeField(null=True, blank=True)

    # --- Automated sentiment analysis / spam-quality flagging ---
    # Computed once at creation time (see reviews.ml.analyze_review) so the
    # cost of running sentiment analysis is paid once, not on every read.
    sentiment_score = models.FloatField(
        null=True, blank=True,
        help_text="VADER compound sentiment score of the comment, from -1 (very negative) to 1 (very positive).",
    )
    sentiment_label = models.CharField(
        max_length=10, blank=True, default='',
        choices=[('positive', 'Positive'), ('neutral', 'Neutral'), ('negative', 'Negative')],
    )
    spam_score = models.FloatField(
        default=0.0,
        help_text="Heuristic likelihood (0-1) that this review is fake/spam/low-effort.",
    )
    is_flagged_spam = models.BooleanField(
        default=False,
        help_text="Automatically flagged for moderator review as potentially fake/spam.",
    )
    flag_reasons = models.CharField(
        max_length=255, blank=True, default='',
        help_text="Comma-separated list of which spam heuristics fired.",
    )

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.reviewer.username} rated {self.reviewee.username} {self.rating}/5"
