"""
Lightweight sentiment analysis + fake/spam heuristics for reviews.

Uses VADER (a lexicon + rule-based sentiment tool that ships its own word
list, so it works fully offline — no model download needed) to score how
positive/negative a review's text reads, then combines that with a few
cheap heuristics to flag reviews that look fake, spammy, or low-effort.

This is intentionally rule-based rather than a trained classifier: the
review dataset for a single deployment is small and has no labelled
"is this fake" ground truth to train against, so a transparent, tunable
rule set is both more practical and easier to audit than a black-box model.
"""
from difflib import SequenceMatcher

from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

_analyzer = SentimentIntensityAnalyzer()

# Comments that are just generic praise with no real detail. Common on
# fake/incentivized reviews. Matched case-insensitively against the whole
# (stripped) comment.
_GENERIC_PHRASES = {
    "great teacher", "highly recommend", "amazing", "very good", "good teacher",
    "excellent", "nice", "best", "great", "awesome", "10/10", "five stars",
    "great experience", "would recommend", "good", "very nice", "perfect",
}

SPAM_THRESHOLD = 0.55

# Minimum bar for auto-highlighting a teacher as a "standout" on their
# public profile: a solid star rating, a real sample size (so one lucky
# 5-star review isn't enough), genuinely positive sentiment in what people
# wrote (not just the star number), and not a review history that's mostly
# flagged as spam/fake.
STANDOUT_MIN_RATING = 4.5
STANDOUT_MIN_REVIEWS = 3
STANDOUT_MIN_AVG_SENTIMENT = 0.3
STANDOUT_MAX_FLAGGED_RATIO = 0.2


def standout_teacher_stats(user):
    """
    Returns {"is_standout": bool, "average_rating": float|None,
    "review_count": int} for a given teacher (User instance), based on
    their received reviews' star ratings + sentiment + spam-flag ratio.
    """
    from django.db.models import Avg, Count, Q
    from .models import Review

    reviews = Review.objects.filter(reviewee=user)
    stats = reviews.aggregate(
        average_rating=Avg('rating'),
        average_sentiment=Avg('sentiment_score'),
        review_count=Count('id'),
        flagged_count=Count('id', filter=Q(is_flagged_spam=True)),
    )
    review_count = stats['review_count'] or 0
    average_rating = stats['average_rating']
    average_sentiment = stats['average_sentiment'] or 0.0
    flagged_ratio = (stats['flagged_count'] / review_count) if review_count else 0.0

    is_standout = (
        review_count >= STANDOUT_MIN_REVIEWS
        and average_rating is not None
        and average_rating >= STANDOUT_MIN_RATING
        and average_sentiment >= STANDOUT_MIN_AVG_SENTIMENT
        and flagged_ratio <= STANDOUT_MAX_FLAGGED_RATIO
    )
    return {
        "is_standout": is_standout,
        "average_rating": round(average_rating, 2) if average_rating else None,
        "review_count": review_count,
    }



def _sentiment(comment):
    """Returns VADER's compound score in [-1, 1]. Empty text scores neutral (0)."""
    if not comment or not comment.strip():
        return 0.0
    return _analyzer.polarity_scores(comment)["compound"]


def _sentiment_label(compound):
    if compound >= 0.35:
        return "positive"
    if compound <= -0.35:
        return "negative"
    return "neutral"


def _rating_sentiment_mismatch(rating, compound):
    """
    A 5-star review reading as clearly negative text (or a 1-2 star review
    reading as clearly positive text) is a strong tell of a fake/manipulated
    review — the stars and the words disagree.
    """
    if rating >= 4 and compound <= -0.4:
        return True
    if rating <= 2 and compound >= 0.4:
        return True
    return False


def _is_generic(comment):
    text = (comment or "").strip().lower().rstrip("!.").strip()
    if not text:
        return False
    return text in _GENERIC_PHRASES or len(text.split()) <= 2


def _is_near_duplicate(comment, previous_comments, similarity=0.9):
    """True if this comment is (near-)identical to one this reviewer already posted."""
    text = (comment or "").strip().lower()
    if not text:
        return False
    for prev in previous_comments:
        prev = (prev or "").strip().lower()
        if not prev:
            continue
        if SequenceMatcher(None, text, prev).ratio() >= similarity:
            return True
    return False


def analyze_review(rating, comment, previous_reviewer_comments=()):
    """
    Runs sentiment analysis + spam/fake heuristics on a single review.

    `previous_reviewer_comments` is an iterable of comment strings this same
    reviewer has posted before (used for duplicate-text detection).

    Returns a dict:
        sentiment_score  float, VADER compound score in [-1, 1]
        sentiment_label  'positive' | 'neutral' | 'negative'
        spam_score       float in [0, 1], higher = more likely fake/spam
        is_flagged_spam  bool, spam_score >= SPAM_THRESHOLD
        flag_reasons     list[str] of the specific heuristics that fired
    """
    compound = _sentiment(comment)
    reasons = []
    score = 0.0

    if _rating_sentiment_mismatch(rating, compound):
        reasons.append("rating_sentiment_mismatch")
        score += 0.6

    if _is_generic(comment):
        reasons.append("generic_low_effort_text")
        score += 0.3

    if _is_near_duplicate(comment, previous_reviewer_comments):
        reasons.append("duplicate_of_reviewer_past_text")
        score += 0.5

    if not comment or not comment.strip():
        reasons.append("no_written_feedback")
        score += 0.15

    spam_score = min(1.0, round(score, 2))

    return {
        "sentiment_score": round(compound, 3),
        "sentiment_label": _sentiment_label(compound),
        "spam_score": spam_score,
        "is_flagged_spam": spam_score >= SPAM_THRESHOLD,
        "flag_reasons": reasons,
    }
