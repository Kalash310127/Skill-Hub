from django.db.models import Avg, Count
from django.utils import timezone
from rest_framework import viewsets, permissions, mixins, status
from rest_framework.response import Response
from rest_framework.decorators import api_view, permission_classes, action

from .models import Review
from .serializers import ReviewSerializer


class ReviewViewSet(mixins.CreateModelMixin,
                     mixins.ListModelMixin,
                     mixins.RetrieveModelMixin,
                     viewsets.GenericViewSet):
    """
    GET  /api/reviews/reviews/?user=<id>   -> all reviews received by a user (public)
    POST /api/reviews/reviews/              -> leave a review {skill_request, rating, comment}
                                                (JWT required; only the learner, only once
                                                 a request is 'completed')
    POST /api/reviews/reviews/<id>/report/   -> flag a review for moderation {reason}
    """
    permission_classes = [permissions.IsAuthenticatedOrReadOnly]
    serializer_class = ReviewSerializer

    def get_queryset(self):
        qs = Review.objects.select_related('reviewer', 'reviewee', 'skill_request__skill')
        user_id = self.request.query_params.get('user')
        if user_id:
            qs = qs.filter(reviewee_id=user_id)
        return qs

    @action(detail=True, methods=['post'], permission_classes=[permissions.IsAuthenticated])
    def report(self, request, pk=None):
        review = self.get_object()
        reason = (request.data.get('reason') or '').strip()
        if not reason:
            return Response({"detail": "Please provide a reason."}, status=status.HTTP_400_BAD_REQUEST)
        review.is_reported = True
        review.report_reason = reason
        review.reported_at = timezone.now()
        review.save()
        return Response(self.get_serializer(review).data)

    @action(detail=False, methods=['get'], permission_classes=[permissions.IsAdminUser])
    def flagged(self, request):
        """
        GET /api/reviews/reviews/flagged/
        Moderator-only queue of reviews auto-flagged by the sentiment/spam
        heuristics (reviews.ml.analyze_review) — separate from user-reported
        reviews, though a review can appear in both.
        """
        qs = self.get_queryset().filter(is_flagged_spam=True)
        page = self.paginate_queryset(qs)
        serializer = self.get_serializer(page if page is not None else qs, many=True)
        return self.get_paginated_response(serializer.data) if page is not None else Response(serializer.data)


@api_view(['GET'])
@permission_classes([permissions.AllowAny])
def user_rating_summary(request, user_id):
    """
    GET /api/reviews/summary/<user_id>/
    -> {"average_rating": 4.5, "review_count": 12}
    Handy single call for showing a star rating on a profile card.
    """
    stats = Review.objects.filter(reviewee_id=user_id).aggregate(
        average_rating=Avg('rating'),
        review_count=Count('id'),
    )
    return Response({
        "average_rating": round(stats['average_rating'], 2) if stats['average_rating'] else None,
        "review_count": stats['review_count'],
    })
