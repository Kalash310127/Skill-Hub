"""
Backfills sentiment_score / spam_score / is_flagged_spam on reviews that
were created before the sentiment/spam analysis existed (or re-runs it if
the heuristics in reviews.ml change later).

    python manage.py analyze_reviews
"""
from django.core.management.base import BaseCommand

from reviews.models import Review
from reviews.ml import analyze_review


class Command(BaseCommand):
    help = "Run sentiment analysis + spam/fake heuristics on all reviews."

    def handle(self, *args, **options):
        updated = 0
        # Oldest-first so "previous comments by this reviewer" builds up in
        # the same order it would have at the time each review was written.
        for review in Review.objects.order_by('created_at'):
            previous_comments = Review.objects.filter(
                reviewer=review.reviewer, created_at__lt=review.created_at,
            ).values_list('comment', flat=True)

            analysis = analyze_review(
                rating=review.rating,
                comment=review.comment,
                previous_reviewer_comments=previous_comments,
            )
            review.sentiment_score = analysis['sentiment_score']
            review.sentiment_label = analysis['sentiment_label']
            review.spam_score = analysis['spam_score']
            review.is_flagged_spam = analysis['is_flagged_spam']
            review.flag_reasons = ','.join(analysis['flag_reasons'])
            review.save(update_fields=[
                'sentiment_score', 'sentiment_label', 'spam_score',
                'is_flagged_spam', 'flag_reasons',
            ])
            updated += 1

        self.stdout.write(self.style.SUCCESS(f"Analyzed {updated} review(s)."))
