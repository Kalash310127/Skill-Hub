from rest_framework import serializers
from .models import Review
from .ml import analyze_review


class ReviewSerializer(serializers.ModelSerializer):
    reviewer_username = serializers.CharField(source='reviewer.username', read_only=True)
    reviewee_username = serializers.CharField(source='reviewee.username', read_only=True)
    skill_title = serializers.CharField(source='skill_request.skill.title', read_only=True)

    class Meta:
        model = Review
        fields = [
            'id', 'skill_request', 'reviewer', 'reviewer_username',
            'reviewee', 'reviewee_username', 'skill_title',
            'rating', 'comment', 'created_at', 'is_reported',
            'sentiment_score', 'sentiment_label', 'spam_score', 'is_flagged_spam',
        ]
        read_only_fields = [
            'id', 'reviewer', 'reviewee', 'created_at', 'is_reported',
            'sentiment_score', 'sentiment_label', 'spam_score', 'is_flagged_spam',
        ]

    def validate_skill_request(self, skill_request):
        request = self.context['request']

        if skill_request.status != 'completed':
            raise serializers.ValidationError("You can only review a completed exchange.")

        if skill_request.requester_id != request.user.id:
            raise serializers.ValidationError("Only the learner who made the request can leave this review.")

        if hasattr(skill_request, 'review'):
            raise serializers.ValidationError("This exchange has already been reviewed.")

        return skill_request

    def create(self, validated_data):
        request = self.context['request']
        skill_request = validated_data['skill_request']
        validated_data['reviewer'] = request.user
        validated_data['reviewee'] = skill_request.skill.user  # the teacher

        previous_comments = Review.objects.filter(
            reviewer=request.user
        ).values_list('comment', flat=True)

        analysis = analyze_review(
            rating=validated_data.get('rating'),
            comment=validated_data.get('comment', ''),
            previous_reviewer_comments=previous_comments,
        )
        validated_data['sentiment_score'] = analysis['sentiment_score']
        validated_data['sentiment_label'] = analysis['sentiment_label']
        validated_data['spam_score'] = analysis['spam_score']
        validated_data['is_flagged_spam'] = analysis['is_flagged_spam']
        validated_data['flag_reasons'] = ','.join(analysis['flag_reasons'])

        return super().create(validated_data)
