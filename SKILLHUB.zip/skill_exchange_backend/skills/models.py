from django.conf import settings
from django.db import models


class Category(models.Model):
    """
    Normalized lookup table so skill categories aren't repeated as free text
    on every Skill row (e.g. 'Music', 'Programming', 'Cooking').
    """
    name = models.CharField(max_length=80, unique=True)

    class Meta:
        verbose_name_plural = 'Categories'
        ordering = ['name']

    def __str__(self):
        return self.name


class Tag(models.Model):
    """
    Free-form labels a teacher can attach to a Skill (e.g. 'remote-friendly',
    'creative'), separate from Category — a skill can have many tags, used
    for the tag filter on the Browse page.
    """
    name = models.CharField(max_length=40, unique=True)

    class Meta:
        ordering = ['name']

    def __str__(self):
        return self.name


class Skill(models.Model):
    """
    A skill a specific user is offering to teach.
    One user can offer many skills -> ForeignKey (many-to-one), not M2M,
    since each Skill row belongs to exactly one teacher and carries its
    own description/level.
    """
    LEVEL_CHOICES = [
        ('beginner', 'Beginner'),
        ('intermediate', 'Intermediate'),
        ('advanced', 'Advanced'),
    ]

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='skills_offered',
    )
    title = models.CharField(max_length=120)
    category = models.ForeignKey(
        Category,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='skills',
    )
    description = models.TextField(blank=True, default='')
    level = models.CharField(max_length=20, choices=LEVEL_CHOICES, default='beginner')
    # The teacher's own experience with this specific skill, stored in
    # months so it can be entered/displayed as either months or years
    # (e.g. 18 -> "1 yr 6 mo") without a second column to keep in sync.
    experience_months = models.PositiveIntegerField(
        default=0,
        help_text="How long the teacher has practiced this skill, in months (e.g. 18 = 1 year 6 months). Editable by the teacher only.",
    )
    tags = models.ManyToManyField(Tag, blank=True, related_name='skills')
    # One fixed date+time this lecture/session happens (replaces the old
    # per-profile "beginner/intermediate/advanced daily time" system — each
    # listing now just states exactly when its own session is).
    fixed_session_at = models.DateTimeField(
        null=True, blank=True,
        help_text="When this session/lecture happens. Learners see this before requesting.",
    )
    # How many learners the teacher will take for this session. Once the
    # number of accepted (non-waitlisted) requests reaches this, further
    # accepted requests are waitlisted instead of confirmed.
    capacity = models.PositiveSmallIntegerField(default=1)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['title']),
        ]
        # Prevent the same user from listing the exact same skill title twice
        constraints = [
            models.UniqueConstraint(fields=['user', 'title'], name='unique_skill_per_user')
        ]

    def __str__(self):
        return f"{self.title} ({self.user.username})"

    @property
    def capacity_locked(self):
        """
        True once at least one learner has an active (pending/accepted)
        request against this skill — the teacher can no longer change the
        seat count mid-flight. Unlocks again once every request on it is
        completed, rejected, or cancelled.
        """
        return self.requests.filter(status__in=['pending', 'accepted']).exists()

    @property
    def accepted_count(self):
        """How many confirmed (non-waitlisted) seats are currently taken."""
        return self.requests.filter(status='accepted', is_waitlisted=False).count()

    @property
    def teacher_rating(self):
        """
        The teacher's overall rating (average + review count), computed
        from reviews left about them. Shown alongside a skill so a learner
        can judge the teacher before requesting, not just the skill text.
        """
        from django.db.models import Avg, Count
        from reviews.models import Review
        stats = Review.objects.filter(reviewee=self.user).aggregate(
            average_rating=Avg('rating'), review_count=Count('id')
        )
        return {
            'average_rating': round(stats['average_rating'], 2) if stats['average_rating'] else None,
            'review_count': stats['review_count'],
        }


class Wishlist(models.Model):
    """
    "Skills I want to learn" — a lightweight, personal intent list that's
    completely separate from sending an actual SkillRequest. Lets browsing
    feel less binary (request now vs. nothing) by giving a place to just
    note interest.
    """
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='wishlist_items',
    )
    # If this wishlist item came from tapping the heart on an actual
    # listing, it's linked here (so the heart can show filled/unfilled and
    # toggle on/off). Freeform items typed on the Wishlist page leave this
    # blank.
    skill = models.ForeignKey(
        'Skill',
        on_delete=models.CASCADE,
        null=True, blank=True,
        related_name='wishlisted_by',
    )
    title = models.CharField(max_length=120)
    notes = models.TextField(blank=True, default='')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']
        constraints = [
            # A user can only heart a given skill once (freeform items with
            # skill=NULL aren't restricted by this — NULLs don't collide).
            models.UniqueConstraint(fields=['user', 'skill'], name='unique_wishlist_skill_per_user'),
        ]

    def __str__(self):
        return f"{self.user.username} wants to learn {self.title}"
