from rest_framework.routers import DefaultRouter
from .views import CategoryViewSet, TagViewSet, SkillViewSet, WishlistViewSet

router = DefaultRouter()
router.register(r'categories', CategoryViewSet, basename='category')
router.register(r'tags', TagViewSet, basename='tag')
router.register(r'skills', SkillViewSet, basename='skill')
router.register(r'wishlist', WishlistViewSet, basename='wishlist')

urlpatterns = router.urls
