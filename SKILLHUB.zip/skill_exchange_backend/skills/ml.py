"""
Auto-suggests a Category + Tags for a new skill listing as the teacher
types its title/description, by comparing it against the text of every
existing Skill using TF-IDF + cosine similarity (a lightweight nearest-
neighbor "classifier trained on existing Skill entries" — see the
"Skill Tag Auto-Suggestion" feature).

TF-IDF is used instead of a neural embedding model because it needs no
pretrained weights to download (fully offline) and still works fine as a
nearest-neighbor signal on a small, growing set of listings. If a bigger
labelled dataset existed, swapping in a proper classifier (e.g. a small
scikit-learn LogisticRegression over the same TF-IDF features, or sentence-
transformer embeddings) would be a drop-in improvement — the suggest_tags()
call site wouldn't need to change.
"""
from collections import Counter

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Minimum existing skills needed before nearest-neighbor suggestions are
# trustworthy. Below this, fall back to plain keyword matching.
MIN_CORPUS_SIZE = 4

NEIGHBORS_CONSIDERED = 5
MIN_SIMILARITY = 0.12
MAX_SUGGESTED_TAGS = 3

# Fallback keyword -> category map for when there isn't enough existing
# data yet to compare against (a brand new deployment with few listings).
_KEYWORD_CATEGORIES = {
    'Programming': ['python', 'java', 'javascript', 'typescript', 'code', 'coding', 'programming',
                    'react', 'django', 'backend', 'frontend', 'sql', 'api', 'software', 'developer'],
    'Music': ['guitar', 'piano', 'violin', 'singing', 'vocal', 'music', 'drum', 'song'],
    'Cooking': ['cooking', 'baking', 'recipe', 'kitchen', 'chef', 'cuisine'],
    'Design': ['design', 'figma', 'photoshop', 'illustrator', 'ui', 'ux', 'graphic'],
    'Language': ['spanish', 'french', 'english', 'german', 'language', 'grammar', 'speaking'],
    'Fitness': ['yoga', 'fitness', 'workout', 'exercise', 'training', 'gym'],
    'Business': ['marketing', 'business', 'finance', 'accounting', 'sales', 'excel'],
}


def _document_for(skill):
    parts = [skill.title or '', skill.description or '']
    return ' '.join(parts)


def _keyword_fallback(text):
    text_lower = text.lower()
    best_category = None
    best_hits = 0
    for category, keywords in _KEYWORD_CATEGORIES.items():
        hits = sum(1 for kw in keywords if kw in text_lower)
        if hits > best_hits:
            best_hits = hits
            best_category = category
    return {
        "category": best_category,
        "tags": [],
        "confidence": 0.3 if best_category else 0.0,
        "method": "keyword_fallback",
    }


def suggest_category_and_tags(title, description=''):
    """
    Returns {"category": str|None, "tags": [str], "confidence": float, "method": str}
    for a new skill's title + description, based on the most textually
    similar existing skills.
    """
    from .models import Skill

    text = f"{title or ''} {description or ''}".strip()
    if not text:
        return {"category": None, "tags": [], "confidence": 0.0, "method": "none"}

    existing = list(
        Skill.objects.filter(is_active=True)
        .exclude(category__isnull=True)
        .select_related('category')
        .prefetch_related('tags')
    )

    if len(existing) < MIN_CORPUS_SIZE:
        return _keyword_fallback(text)

    corpus = [_document_for(s) for s in existing]
    vectorizer = TfidfVectorizer(stop_words='english', ngram_range=(1, 2), min_df=1)
    matrix = vectorizer.fit_transform(corpus + [text])

    query_vector = matrix[-1]
    corpus_vectors = matrix[:-1]
    similarities = cosine_similarity(query_vector, corpus_vectors)[0]

    ranked = sorted(
        ((score, skill) for score, skill in zip(similarities, existing)),
        key=lambda pair: pair[0],
        reverse=True,
    )
    top_matches = [pair for pair in ranked[:NEIGHBORS_CONSIDERED] if pair[0] >= MIN_SIMILARITY]

    if not top_matches:
        return _keyword_fallback(text)

    category_votes = Counter(skill.category.name for _, skill in top_matches if skill.category)
    tag_votes = Counter()
    for _, skill in top_matches:
        for tag in skill.tags.all():
            tag_votes[tag.name] += 1

    top_category = category_votes.most_common(1)[0][0] if category_votes else None
    top_tags = [name for name, _ in tag_votes.most_common(MAX_SUGGESTED_TAGS)]
    best_similarity = top_matches[0][0]

    return {
        "category": top_category,
        "tags": top_tags,
        "confidence": round(float(best_similarity), 3),
        "method": "tfidf_nearest_neighbors",
    }
