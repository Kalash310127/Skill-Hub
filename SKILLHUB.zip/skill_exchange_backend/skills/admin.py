from django.contrib import admin
from .models import Category, Tag, Skill, Wishlist


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ['id', 'name']
    search_fields = ['name']


@admin.register(Tag)
class TagAdmin(admin.ModelAdmin):
    list_display = ['id', 'name']
    search_fields = ['name']


@admin.register(Skill)
class SkillAdmin(admin.ModelAdmin):
    list_display = ['title', 'user', 'category', 'level', 'experience_months', 'capacity', 'fixed_session_at', 'is_active', 'created_at']
    list_filter = ['level', 'is_active', 'category']
    search_fields = ['title', 'description', 'user__username']


@admin.register(Wishlist)
class WishlistAdmin(admin.ModelAdmin):
    list_display = ['user', 'title', 'created_at']
    search_fields = ['title', 'user__username']
