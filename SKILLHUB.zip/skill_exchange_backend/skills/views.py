from rest_framework import viewsets, permissions, filters, mixins
from rest_framework.decorators import action
from rest_framework.response import Response
from django_filters.rest_framework import DjangoFilterBackend

from .models import Category, Tag, Skill, Wishlist
from .serializers import CategorySerializer, TagSerializer, SkillSerializer, WishlistSerializer
from .permissions import IsOwnerOrReadOnly
from .ml import suggest_category_and_tags
from .search import rank_skills_by_query


class CategoryViewSet(viewsets.ReadOnlyModelViewSet):
    """
    GET /api/skills/categories/        -> list all categories
    GET /api/skills/categories/<id>/   -> one category
    Read-only: categories are created automatically as users list skills.
    """
    permission_classes = [permissions.AllowAny]
    queryset = Category.objects.all()
    serializer_class = CategorySerializer


class TagViewSet(viewsets.ReadOnlyModelViewSet):
    """
    GET /api/skills/tags/        -> list all tags (for the Browse filter)
    Read-only: tags are created automatically as users list skills.
    """
    permission_classes = [permissions.AllowAny]
    queryset = Tag.objects.all()
    serializer_class = TagSerializer


class WishlistViewSet(mixins.ListModelMixin,
                       mixins.CreateModelMixin,
                       mixins.DestroyModelMixin,
                       viewsets.GenericViewSet):
    """
    GET    /api/skills/wishlist/            -> your own "skills I want to learn" list
    POST   /api/skills/wishlist/            -> add {title, notes} or {skill}
    DELETE /api/skills/wishlist/<id>/       -> remove an item
    POST   /api/skills/wishlist/toggle/     -> {skill: <id>} heart on/off; used by the
                                                heart icon on skill cards. Returns
                                                {wishlisted: true/false}.
    """
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = WishlistSerializer

    def get_queryset(self):
        return Wishlist.objects.filter(user=self.request.user)

    @action(detail=False, methods=['post'])
    def toggle(self, request):
        skill_id = request.data.get('skill')
        if not skill_id:
            return Response({"detail": "skill id is required."}, status=400)
        existing = Wishlist.objects.filter(user=request.user, skill_id=skill_id).first()
        if existing:
            existing.delete()
            return Response({"wishlisted": False})
        skill = Skill.objects.filter(id=skill_id).first()
        if not skill:
            return Response({"detail": "Skill not found."}, status=404)
        Wishlist.objects.create(user=request.user, skill=skill, title=skill.title)
        return Response({"wishlisted": True}, status=201)


class SkillViewSet(viewsets.ModelViewSet):
    """
    GET    /api/skills/skills/             -> browse/search all offered skills
    POST   /api/skills/skills/             -> create a new skill (JWT required)
    GET    /api/skills/skills/<id>/        -> skill detail
    PATCH  /api/skills/skills/<id>/        -> edit (owner only)
    DELETE /api/skills/skills/<id>/        -> delete (owner only)

    Search & filter:
      ?search=guitar            -> ranked search over title/description/category/tags
                                    (semantic-ish: matches don't need the exact same words,
                                    see skills.search.rank_skills_by_query)
      ?category=Music           -> exact category name
      ?level=beginner           -> filter by level
      ?user=3                   -> skills offered by a specific user
      ?ordering=-created_at     -> newest first (default; ignored while ?search= ranking is active)
    """
    permission_classes = [permissions.IsAuthenticatedOrReadOnly, IsOwnerOrReadOnly]
    serializer_class = SkillSerializer

    # NOTE: rest_framework.filters.SearchFilter is deliberately left out —
    # 'search' is handled by rank_skills_by_query() in list() below instead
    # of a plain icontains match, so semantically-related-but-differently-
    # worded queries ("python for beginners" vs. a listing tagged
    # differently) can still surface high on the results.
    filter_backends = [DjangoFilterBackend, filters.OrderingFilter]
    filterset_fields = {
        'level': ['exact'],
        'user': ['exact'],
        'category__name': ['exact', 'icontains'],
        'tags__name': ['exact'],
    }
    ordering_fields = ['created_at', 'title']
    ordering = ['-created_at']

    def get_queryset(self):
        qs = Skill.objects.filter(is_active=True).select_related('user', 'category').prefetch_related('tags')
        # Only the general browse/search *listing* excludes your own skills
        # (you can't request to learn from yourself). A direct lookup by id
        # — retrieve, update, or delete a specific skill — must still find
        # your own skill regardless, or actions like deleting your own
        # listing 404 with "No Skill matches the given query."
        if self.action == 'list' and not self.request.query_params.get('user') and self.request.user.is_authenticated:
            qs = qs.exclude(user=self.request.user)
        return qs.distinct()

    def list(self, request, *args, **kwargs):
        query = (request.query_params.get('search') or '').strip()
        if not query:
            return super().list(request, *args, **kwargs)

        # DjangoFilterBackend still applies (category/level/tags/user);
        # OrderingFilter is skipped once a search query is present since
        # relevance ranking replaces it.
        queryset = DjangoFilterBackend().filter_queryset(request, self.get_queryset(), self)
        ranked = rank_skills_by_query(list(queryset), query)

        page = self.paginate_queryset(ranked)
        serializer = self.get_serializer(page if page is not None else ranked, many=True)
        if page is not None:
            return self.get_paginated_response(serializer.data)
        return Response(serializer.data)

    @action(detail=False, methods=['post'], permission_classes=[permissions.IsAuthenticated])
    def suggest_tags(self, request):
        """
        POST /api/skills/skills/suggest_tags/  {title, description}
        -> {category, tags, confidence, method}
        Used by SkillForm.jsx while a teacher is typing a new listing, to
        auto-suggest a Category + Tags and cut down on inconsistent tagging.
        Purely advisory — the teacher can still edit/override before saving.
        """
        title = (request.data.get('title') or '').strip()
        description = (request.data.get('description') or '').strip()
        if not title and not description:
            return Response({"category": None, "tags": [], "confidence": 0.0, "method": "none"})
        return Response(suggest_category_and_tags(title, description))

    @action(detail=False, methods=['get'], permission_classes=[permissions.AllowAny])
    def random_picks(self, request):
        """
        GET /api/skills/skills/random_picks/
        A handful of genuinely random active listings for the homepage
        carousel — deliberately NOT based on the user's history/achievements,
        so it stays fresh and unbiased on every visit instead of narrowing
        to "more of the same." Shown to logged-out visitors too, since it's
        just a taste of the board, not a personalized recommendation — only
        excludes the viewer's own listings when they're actually logged in.
        """
        qs = Skill.objects.filter(is_active=True)
        if request.user.is_authenticated:
            qs = qs.exclude(user=request.user)
        qs = (
            qs.select_related('user', 'category')
            .prefetch_related('tags')
            .order_by('?')[:8]
        )
        return Response(SkillSerializer(qs, many=True, context={'request': request}).data)
