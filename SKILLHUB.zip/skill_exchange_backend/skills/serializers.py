from rest_framework import serializers
from .models import Category, Tag, Skill, Wishlist


class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = ['id', 'name']


class TagSerializer(serializers.ModelSerializer):
    class Meta:
        model = Tag
        fields = ['id', 'name']


class SkillSerializer(serializers.ModelSerializer):
    # Read-friendly extras (nice for the React frontend to display directly)
    username = serializers.CharField(source='user.username', read_only=True)
    category_name = serializers.CharField(source='category.name', read_only=True, default=None)
    teacher_rating = serializers.ReadOnlyField()
    tags = TagSerializer(many=True, read_only=True)
    capacity_locked = serializers.ReadOnlyField()

    # Write-friendly: accept a category by name; create it if it doesn't exist yet
    category_input = serializers.CharField(write_only=True, required=False, allow_blank=True)
    # Write-friendly: accept a list of tag names; create any that don't exist yet
    tag_input = serializers.ListField(
        child=serializers.CharField(max_length=40), write_only=True, required=False
    )

    class Meta:
        model = Skill
        fields = [
            'id', 'title', 'description', 'level', 'experience_months',
            'category', 'category_name', 'category_input',
            'tags', 'tag_input',
            'fixed_session_at', 'capacity', 'capacity_locked',
            'user', 'username', 'is_active', 'teacher_rating',
            'created_at', 'updated_at',
        ]
        read_only_fields = ['id', 'user', 'category', 'created_at', 'updated_at']

    def validate_experience_months(self, value):
        if value < 0 or value > 1200:  # 100 years — generous sanity ceiling
            raise serializers.ValidationError("Experience must be between 0 and 1200 months.")
        return value

    def validate_capacity(self, value):
        if value < 1 or value > 10:
            raise serializers.ValidationError("Capacity must be between 1 and 10 seats.")
        if self.instance and self.instance.capacity_locked and value != self.instance.capacity:
            raise serializers.ValidationError(
                "Seat count is locked while learners have active requests on this session."
            )
        return value

    def _resolve_category(self, validated_data):
        name = validated_data.pop('category_input', None)
        if name:
            category, _ = Category.objects.get_or_create(name__iexact=name, defaults={'name': name})
            validated_data['category'] = category
        return validated_data

    def _resolve_tags(self, validated_data):
        names = validated_data.pop('tag_input', None)
        tags = None
        if names is not None:
            tags = [Tag.objects.get_or_create(name__iexact=n, defaults={'name': n})[0] for n in names if n]
        return tags

    def create(self, validated_data):
        validated_data = self._resolve_category(validated_data)
        tags = self._resolve_tags(validated_data)
        validated_data['user'] = self.context['request'].user
        skill = super().create(validated_data)
        if tags is not None:
            skill.tags.set(tags)
        return skill

    def update(self, instance, validated_data):
        validated_data = self._resolve_category(validated_data)
        tags = self._resolve_tags(validated_data)
        skill = super().update(instance, validated_data)
        if tags is not None:
            skill.tags.set(tags)
        return skill


class WishlistSerializer(serializers.ModelSerializer):
    skill_title = serializers.CharField(source='skill.title', read_only=True, default=None)
    title = serializers.CharField(required=False, allow_blank=True, max_length=120)

    class Meta:
        model = Wishlist
        fields = ['id', 'skill', 'skill_title', 'title', 'notes', 'created_at']
        read_only_fields = ['id', 'created_at']

    def validate(self, attrs):
        # Freeform items (no linked skill) still need a title typed by hand;
        # skill-linked items (from the heart button) can borrow the skill's
        # own title automatically.
        if not attrs.get('skill') and not attrs.get('title'):
            raise serializers.ValidationError("Give this wishlist item a title.")
        return attrs

    def create(self, validated_data):
        validated_data['user'] = self.context['request'].user
        if validated_data.get('skill') and not validated_data.get('title'):
            validated_data['title'] = validated_data['skill'].title
        return super().create(validated_data)
