"""
Ranked search for the Browse page, upgrading the old plain substring
filter (title/description icontains) to similarity-based ranking so a
query like "python for beginners" can still surface a listing titled
"Intro to Python scripting" even though the words don't match exactly.

Implementation note: this uses TF-IDF + cosine similarity rather than
sentence-transformer embeddings. TF-IDF needs no pretrained model weights
(this environment has no access to download one), and — combined with the
small synonym expansion below — gets most of the same "semantically close,
lexically different" matching that a query like "python for beginners"
needs. If real sentence embeddings are available in your deployment
environment, swap this module's ranking step for
`sentence_transformers.SentenceTransformer(...).encode(...)` and cosine
similarity on those vectors instead — the call site (SkillViewSet.list)
doesn't need to change, since it just consumes a ranked list of Skills.
"""
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

MIN_SIMILARITY = 0.1

# Small synonym map to bridge common wording gaps a plain TF-IDF match
# would otherwise miss entirely (no shared tokens = zero similarity).
# Expansion is applied to both the query and each document.
_SYNONYMS = {
    'beginner': ['beginner', 'novice', 'intro', 'introductory', 'starter', 'basics', 'fundamentals'],
    'intro': ['intro', 'introduction', 'beginner', 'basics'],
    'advanced': ['advanced', 'expert', 'master', 'pro'],
    'coding': ['coding', 'programming', 'development', 'dev'],
    'programming': ['programming', 'coding', 'development', 'dev'],
    'js': ['js', 'javascript'],
    'py': ['py', 'python'],
}


def _expand(text):
    words = text.lower().split()
    expanded = list(words)
    for word in words:
        expanded.extend(_SYNONYMS.get(word, []))
    return ' '.join(expanded)


def _document_for(skill):
    tag_names = ' '.join(t.name for t in skill.tags.all())
    category_name = skill.category.name if skill.category else ''
    return _expand(f"{skill.title} {skill.description} {category_name} {tag_names} {skill.level}")


def rank_skills_by_query(skills, query):
    """
    skills: an iterable of Skill instances (already materialized, e.g. via
            list(queryset) — this function doesn't hit the DB).
    query:  the free-text search string typed by the learner.

    Returns skills sorted most-to-least relevant, dropping any whose
    similarity to the query falls below MIN_SIMILARITY. Falls back to
    returning all skills unranked if the corpus is too small/sparse for
    TF-IDF to produce a meaningful signal (e.g. only 1 listing exists).
    """
    skills = list(skills)
    if not query or not query.strip():
        return skills
    if not skills:
        return skills

    documents = [_document_for(s) for s in skills]
    query_doc = _expand(query)

    try:
        vectorizer = TfidfVectorizer(stop_words='english', ngram_range=(1, 2), min_df=1)
        matrix = vectorizer.fit_transform(documents + [query_doc])
    except ValueError:
        # Empty vocabulary (e.g. every document was pure stop-words) —
        # fall back to a plain substring check rather than erroring out.
        q = query.lower()
        return [s for s in skills if q in (s.title or '').lower() or q in (s.description or '').lower()]

    query_vector = matrix[-1]
    doc_vectors = matrix[:-1]
    similarities = cosine_similarity(query_vector, doc_vectors)[0]

    ranked = sorted(zip(similarities, skills), key=lambda pair: pair[0], reverse=True)
    matches = [skill for score, skill in ranked if score >= MIN_SIMILARITY]

    if not matches:
        # Nothing cleared the bar (tiny/sparse corpus) — fall back to a
        # plain substring match so search still returns something sensible
        # rather than an empty page.
        q = query.lower()
        matches = [s for s in skills if q in (s.title or '').lower() or q in (s.description or '').lower()]

    return matches
