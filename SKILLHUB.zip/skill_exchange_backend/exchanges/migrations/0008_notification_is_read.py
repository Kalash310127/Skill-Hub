from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('exchanges', '0007_remove_skillrequest_extra_reminder_sent'),
    ]

    operations = [
        migrations.AddField(
            model_name='notification',
            name='is_read',
            field=models.BooleanField(default=False, help_text="Whether the recipient has opened/seen this notification."),
        ),
    ]
