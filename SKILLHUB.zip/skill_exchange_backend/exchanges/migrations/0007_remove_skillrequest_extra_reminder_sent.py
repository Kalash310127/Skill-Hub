# Generated manually — removes the field added for the (now removed)
# No-show / Churn Prediction feature.

from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        ('exchanges', '0006_skillrequest_extra_reminder_sent'),
    ]

    operations = [
        migrations.RemoveField(
            model_name='skillrequest',
            name='extra_reminder_sent',
        ),
    ]
