from rest_framework.routers import DefaultRouter
from .views import SkillRequestViewSet, NotificationViewSet

router = DefaultRouter()
router.register(r'requests', SkillRequestViewSet, basename='skillrequest')
router.register(r'notifications', NotificationViewSet, basename='notification')

urlpatterns = router.urls
