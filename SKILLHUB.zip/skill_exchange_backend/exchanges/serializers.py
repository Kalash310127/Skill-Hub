from django.utils import timezone
from rest_framework import serializers
from .models import SkillRequest, Notification, SessionMaterial


class NotificationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Notification
        fields = ['id', 'skill_request', 'title', 'body', 'is_read', 'created_at']
        read_only_fields = fields


class SessionMaterialSerializer(serializers.ModelSerializer):
    version = serializers.SerializerMethodField()

    class Meta:
        model = SessionMaterial
        fields = ['id', 'request', 'file', 'lecture_number', 'note', 'uploaded_at', 'version']
        read_only_fields = ['id', 'request', 'uploaded_at']

    def get_version(self, obj):
        """
        Position of this upload within its own lecture_number group, in
        upload order (1 = first upload for that lecture, 2 = the next one
        on top of it, etc.) — this is the "versioning" the file list is
        grouped/labelled by on the frontend.
        """
        return SessionMaterial.objects.filter(
            request_id=obj.request_id,
            lecture_number=obj.lecture_number,
            uploaded_at__lte=obj.uploaded_at,
        ).count()


class SkillRequestSerializer(serializers.ModelSerializer):
    requester_username = serializers.CharField(source='requester.username', read_only=True)
    teacher_username = serializers.CharField(source='skill.user.username', read_only=True)
    skill_title = serializers.CharField(source='skill.title', read_only=True)
    skill_level = serializers.CharField(source='skill.level', read_only=True)
    materials = SessionMaterialSerializer(many=True, read_only=True)
    materials_unlocked = serializers.SerializerMethodField()

    class Meta:
        model = SkillRequest
        fields = [
            'id', 'skill', 'skill_title', 'skill_level', 'message', 'status',
            'meet_link', 'fixed_session_at', 'is_waitlisted',
            'requester', 'requester_username', 'teacher_username',
            'materials', 'materials_unlocked',
            'created_at', 'updated_at',
        ]
        read_only_fields = [
            'id', 'requester', 'status', 'meet_link', 'fixed_session_at', 'is_waitlisted',
            'created_at', 'updated_at',
        ]

    def get_materials_unlocked(self, obj):
        """
        Sharing unlocks once the session's scheduled time has passed —
        matches the "after the first lecture is over, stays open forever"
        rule, since time only moves forward once that's true.
        """
        return bool(obj.fixed_session_at and timezone.now() >= obj.fixed_session_at)

    def validate_skill(self, skill):
        request = self.context['request']
        if skill.user_id == request.user.id:
            raise serializers.ValidationError("You can't send a request for your own skill.")
        return skill

    def create(self, validated_data):
        validated_data['requester'] = self.context['request'].user
        return super().create(validated_data)
