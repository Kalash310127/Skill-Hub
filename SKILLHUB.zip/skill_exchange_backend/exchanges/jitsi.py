"""
Jitsi Meet integration.

Jitsi Meet rooms need no account, no API key, and no server-side booking
call — any URL of the form https://meet.jit.si/<room-name> works the
instant someone opens it, and creates the room on first join. So
"integrating" it is really just: generate a unique, hard-to-guess room
name per SkillRequest, using Django's own crypto helper, and store it as
a URL once the request is accepted.

No third-party credentials or paid accounts are required (unlike Zoom or
Google Meet, which need a connected account + OAuth to auto-create real
meeting links — see project notes).
"""
from django.utils.crypto import get_random_string

JITSI_BASE_URL = "https://meet.jit.si"


def generate_jitsi_room(skill_request_id: int) -> str:
    """
    Build a unique Jitsi Meet URL for a given SkillRequest.

    The room name embeds the request's own id (so it's traceable back to
    which exchange it belongs to) plus a random token (so it can't be
    guessed or joined by someone who wasn't invited).
    """
    token = get_random_string(
        length=10,
        allowed_chars='abcdefghijklmnopqrstuvwxyz0123456789',
    )
    room_name = f"skillhub-req-{skill_request_id}-{token}"
    return f"{JITSI_BASE_URL}/{room_name}"
