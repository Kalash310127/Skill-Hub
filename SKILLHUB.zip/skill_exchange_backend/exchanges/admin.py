from django.contrib import admin
from .models import SkillRequest, Notification, SessionMaterial


@admin.register(SkillRequest)
class SkillRequestAdmin(admin.ModelAdmin):
    list_display = ['requester', 'skill', 'status', 'is_waitlisted', 'fixed_session_at', 'created_at']
    list_filter = ['status', 'is_waitlisted']
    search_fields = ['requester__username', 'skill__title']


@admin.register(Notification)
class NotificationAdmin(admin.ModelAdmin):
    list_display = ['recipient', 'title', 'created_at']
    search_fields = ['recipient__username', 'title']


@admin.register(SessionMaterial)
class SessionMaterialAdmin(admin.ModelAdmin):
    list_display = ['request', 'lecture_number', 'note', 'uploaded_at']
    list_filter = ['lecture_number']
    search_fields = ['request__skill__title', 'note']
