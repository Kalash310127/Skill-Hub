from django.db import models as db_models
from django.utils import timezone
from rest_framework import viewsets, permissions, status
from rest_framework.decorators import action
from rest_framework.response import Response

from .models import SkillRequest, Notification, SessionMaterial
from .serializers import SkillRequestSerializer, NotificationSerializer, SessionMaterialSerializer
from .permissions import IsRequesterOrTeacher
from .jitsi import generate_jitsi_room


def _notify(user, req, title, body=''):
    Notification.objects.create(recipient=user, skill_request=req, title=title, body=body)


def _promote_next_waitlisted(skill):
    """
    Called after a confirmed (non-waitlisted) accepted request frees a seat
    early (cancelled/rejected before the session happened). Promotes the
    oldest waitlisted request into a confirmed seat, generating its Jitsi
    room and notifying both sides.
    """
    next_up = (
        SkillRequest.objects
        .filter(skill=skill, status='accepted', is_waitlisted=True)
        .order_by('created_at')
        .first()
    )
    if not next_up:
        return
    next_up.is_waitlisted = False
    next_up.meet_link = generate_jitsi_room(next_up.id)
    next_up.save()
    _notify(next_up.requester, next_up, "A seat opened up!", f"You're off the waitlist for '{next_up.skill.title}' — you now have a confirmed seat.")
    _notify(next_up.teacher, next_up, "Waitlist promoted", f"{next_up.requester.username} was promoted from the waitlist for '{next_up.skill.title}'.")


class SkillRequestViewSet(viewsets.ModelViewSet):
    """
    GET    /api/exchanges/requests/            -> requests you sent OR received
    POST   /api/exchanges/requests/             -> send a new request {skill, message}
    GET    /api/exchanges/requests/<id>/        -> detail (only the 2 people involved)

    Workflow actions (POST, no body needed):
      /api/exchanges/requests/<id>/accept/         -> teacher accepts a pending request
      /api/exchanges/requests/<id>/reject/         -> teacher rejects a pending request
      /api/exchanges/requests/<id>/cancel/         -> requester cancels their own request
      /api/exchanges/requests/<id>/complete/       -> either side marks it done -> creates an Achievement
      /api/exchanges/requests/<id>/set_meet_link/  -> TEACHER ONLY: sets/edits the Jitsi link {meet_link}
      /api/exchanges/requests/<id>/upload_material/            -> TEACHER ONLY: share a file, once the session has passed
      /api/exchanges/requests/<id>/materials/<material_id>/delete/ -> TEACHER ONLY: remove a shared file
    """
    permission_classes = [permissions.IsAuthenticated, IsRequesterOrTeacher]
    serializer_class = SkillRequestSerializer

    def get_queryset(self):
        user = self.request.user
        return (
            SkillRequest.objects
            .filter(db_models.Q(requester=user) | db_models.Q(skill__user=user))
            .select_related('requester', 'skill', 'skill__user')
        )

    def _forbid(self, msg):
        return Response({"detail": msg}, status=status.HTTP_400_BAD_REQUEST)

    # Capacity/waitlist: a skill states its own fixed_session_at + capacity
    # (number of seats) directly on the listing now, instead of the old
    # per-profile "beginner/intermediate/advanced daily time" lookup.
    @action(detail=True, methods=['post'])
    def accept(self, request, pk=None):
        req = self.get_object()
        if req.skill.user_id != request.user.id:
            return self._forbid("Only the teacher who owns this skill can accept.")
        if req.status != 'pending':
            return self._forbid(f"Request is already '{req.status}'.")

        req.status = 'accepted'
        req.fixed_session_at = req.skill.fixed_session_at

        has_seat = req.skill.accepted_count < req.skill.capacity
        if has_seat:
            req.is_waitlisted = False
            req.meet_link = generate_jitsi_room(req.id)
            req.save()
            _notify(req.requester, req, "Request accepted", f"{req.teacher.username} accepted your request for '{req.skill.title}'. Your Jitsi room is ready.")
        else:
            req.is_waitlisted = True
            req.save()
            _notify(req.requester, req, "You're on the waitlist", f"'{req.skill.title}' is full for now — you'll be notified if a seat opens up.")

        return Response(self.get_serializer(req).data)

    @action(detail=True, methods=['post'])
    def reject(self, request, pk=None):
        req = self.get_object()
        if req.skill.user_id != request.user.id:
            return self._forbid("Only the teacher who owns this skill can reject.")
        if req.status != 'pending':
            return self._forbid(f"Request is already '{req.status}'.")
        req.status = 'rejected'
        req.save()
        return Response(self.get_serializer(req).data)

    @action(detail=True, methods=['post'])
    def cancel(self, request, pk=None):
        req = self.get_object()
        if req.requester_id != request.user.id:
            return self._forbid("Only the requester can cancel their own request.")
        # Previously this only allowed cancelling while still 'pending' —
        # meaning once a teacher accepted (and a meeting link was set), the
        # learner had no way to back out at all. Now an already-accepted-
        # but-not-yet-completed request can be cancelled too; only
        # 'rejected'/'completed'/'cancelled' (already-final states) are blocked.
        if req.status not in ('pending', 'accepted'):
            return self._forbid(f"Request is already '{req.status}'.")
        was_confirmed_seat = req.status == 'accepted' and not req.is_waitlisted
        req.status = 'cancelled'
        req.save()
        if was_confirmed_seat:
            _promote_next_waitlisted(req.skill)
        return Response(self.get_serializer(req).data)

    @action(detail=True, methods=['post'])
    def complete(self, request, pk=None):
        req = self.get_object()
        if req.status != 'accepted':
            return self._forbid("Only an 'accepted' request can be marked complete.")
        req.status = 'completed'
        req.save()

        # Achievement lives in its own app (achievements) to keep "skills
        # taught" and "skills learned" fully independent of each other.
        from achievements.models import Achievement
        Achievement.objects.get_or_create(
            skill_request=req,
            defaults={
                'user': req.requester,
                'skill': req.skill,
                'title': req.skill.title,
            },
        )
        _notify(
            req.requester, req, "Rate your session",
            f"How was '{req.skill.title}' with @{req.teacher.username}? Leave a rating so others know what to expect.",
        )
        return Response(self.get_serializer(req).data)

    @action(detail=True, methods=['post'])
    def set_meet_link(self, request, pk=None):
        """
        Only the teacher (the user who owns the skill being taught) can
        paste/replace the Jitsi room link on an accepted request — a
        manual fallback/override alongside the auto-generated one. The
        student/requester can view the link but not change it.
        """
        req = self.get_object()
        if req.skill.user_id != request.user.id:
            return self._forbid("Only the teacher can set or change the meeting link.")
        if req.status != 'accepted':
            return self._forbid("You can only set a meeting link on an accepted request.")
        link = (request.data.get('meet_link') or '').strip()
        if not link:
            return self._forbid("Please provide a meeting link.")
        req.meet_link = link
        req.save()
        return Response(self.get_serializer(req).data)

    @action(detail=True, methods=['post'])
    def upload_material(self, request, pk=None):
        """
        Sharing: the teacher uploads a file (zip) for this specific
        request. Only the teacher can upload, and only once the session's
        scheduled time has passed — after that it stays open forever, and
        multiple uploads over time are fine (nothing gets overwritten).
        """
        req = self.get_object()
        if req.skill.user_id != request.user.id:
            return self._forbid("Only the teacher can share session materials.")
        if req.status not in ('accepted', 'completed'):
            return self._forbid("You can only share materials on an accepted (or completed) request.")
        if not req.fixed_session_at or timezone.now() < req.fixed_session_at:
            return self._forbid("Materials unlock once the session's scheduled time has passed.")
        uploaded_file = request.FILES.get('file')
        if not uploaded_file:
            return self._forbid("Please attach a file to upload.")
        try:
            lecture_number = int(request.data.get('lecture_number') or 1)
        except (TypeError, ValueError):
            return self._forbid("Lecture number must be a whole number.")
        if lecture_number < 1:
            return self._forbid("Lecture number must be 1 or higher.")
        SessionMaterial.objects.create(
            request=req,
            file=uploaded_file,
            lecture_number=lecture_number,
            note=(request.data.get('note') or '').strip(),
        )
        _notify(req.requester, req, "New materials shared", f"{req.teacher.username} shared new files for '{req.skill.title}' (Lecture {lecture_number}).")
        return Response(self.get_serializer(req).data, status=status.HTTP_201_CREATED)

    @action(detail=True, methods=['post'], url_path='materials/(?P<material_id>[^/.]+)/delete')
    def delete_material(self, request, pk=None, material_id=None):
        """Only the teacher can remove a material they uploaded."""
        req = self.get_object()
        if req.skill.user_id != request.user.id:
            return self._forbid("Only the teacher can remove shared materials.")
        material = req.materials.filter(id=material_id).first()
        if not material:
            return self._forbid("Material not found.")
        material.file.delete(save=False)
        material.delete()
        return Response(self.get_serializer(req).data)


class NotificationViewSet(viewsets.ReadOnlyModelViewSet):
    """
    GET  /api/exchanges/notifications/                 -> your own notifications, newest first
    GET  /api/exchanges/notifications/unread_count/     -> {"count": <int>} — for the navbar badge
    POST /api/exchanges/notifications/<id>/mark_read/   -> marks one notification read
    POST /api/exchanges/notifications/mark_all_read/    -> marks every unread notification read
    """
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = NotificationSerializer

    def get_queryset(self):
        return Notification.objects.filter(recipient=self.request.user)

    @action(detail=False, methods=['get'])
    def unread_count(self, request):
        count = self.get_queryset().filter(is_read=False).count()
        return Response({"count": count})

    @action(detail=True, methods=['post'])
    def mark_read(self, request, pk=None):
        note = self.get_object()
        if not note.is_read:
            note.is_read = True
            note.save(update_fields=['is_read'])
        return Response(self.get_serializer(note).data)

    @action(detail=False, methods=['post'])
    def mark_all_read(self, request):
        updated = self.get_queryset().filter(is_read=False).update(is_read=True)
        return Response({"updated": updated})
