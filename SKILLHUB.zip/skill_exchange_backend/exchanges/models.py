from django.conf import settings
from django.db import models

from skills.models import Skill


class SkillRequest(models.Model):
    """
    A request from one user (the learner) to another (the teacher, via
    their Skill listing) to be taught that skill.
    """
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('accepted', 'Accepted'),
        ('rejected', 'Rejected'),
        ('completed', 'Completed'),
        ('cancelled', 'Cancelled'),
    ]

    requester = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='sent_requests',
    )
    skill = models.ForeignKey(
        Skill,
        on_delete=models.CASCADE,
        related_name='requests',
    )
    message = models.TextField(blank=True, default='')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    meet_link = models.URLField(
        blank=True,
        default='',
        help_text="Jitsi Meet room. Auto-generated the moment the teacher accepts, and editable by either side afterwards.",
    )
    fixed_session_at = models.DateTimeField(
        null=True, blank=True,
        help_text=(
            "Snapshot of the skill's fixed session date/time, taken the "
            "moment the request is accepted. Stored as a snapshot (not "
            "looked up live) so it stays fixed even if the teacher later "
            "reschedules the listing."
        ),
    )
    is_waitlisted = models.BooleanField(
        default=False,
        help_text="True if this request was accepted after the skill's capacity was already full.",
    )
    reminder_sent = models.BooleanField(
        default=False,
        help_text="Whether the 30-minutes-before notification has already been sent for this session.",
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.requester.username} -> {self.skill.title} ({self.status})"

    @property
    def teacher(self):
        """The user offering the skill (the other side of the exchange)."""
        return self.skill.user


class SessionMaterial(models.Model):
    """
    A file (zip) the teacher shares with the learner for a specific
    request, after that request's session has taken place. Grouped by
    lecture_number so a recurring skill's files stay organized by class
    (Lecture 1, Lecture 2, ...); multiple uploads under the same
    lecture_number are treated as versions of that lecture's material —
    nothing gets overwritten, the history just piles up in upload order.
    """
    request = models.ForeignKey(
        SkillRequest,
        on_delete=models.CASCADE,
        related_name='materials',
    )
    file = models.FileField(upload_to='session_materials/%Y/%m/')
    lecture_number = models.PositiveIntegerField(
        default=1,
        help_text="Which lecture/session this file belongs to (Lecture 1, 2, 3...).",
    )
    note = models.CharField(
        max_length=150, blank=True, default='',
        help_text="Optional short label, e.g. 'Week 3 notes'.",
    )
    uploaded_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-uploaded_at']

    def __str__(self):
        return f"Request #{self.request_id} · Lecture {self.lecture_number} ({self.file.name})"


class Notification(models.Model):
    """
    An in-app message to one user about a specific request — e.g. "your
    request was accepted" or a "starts in 30 minutes" reminder. Kept simple
    (no read/unread state) since the frontend just lists them chronologically.
    """
    recipient = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='notifications',
    )
    skill_request = models.ForeignKey(
        SkillRequest,
        on_delete=models.CASCADE,
        related_name='notifications',
        null=True, blank=True,
    )
    title = models.CharField(max_length=150)
    body = models.TextField(blank=True, default='')
    is_read = models.BooleanField(
        default=False,
        help_text="Whether the recipient has opened/seen this notification.",
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.title} -> {self.recipient.username}"
