from rest_framework import permissions


class IsRequesterOrTeacher(permissions.BasePermission):
    """
    Only the two people involved in a SkillRequest (the learner who sent
    it, or the teacher who owns the Skill) can view/act on it.
    """
    def has_object_permission(self, request, view, obj):
        return (
            obj.requester_id == request.user.id
            or obj.skill.user_id == request.user.id
        )
