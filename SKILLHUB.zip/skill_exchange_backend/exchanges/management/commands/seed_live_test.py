"""
Creates (or refreshes) a single skill + already-accepted request whose
session starts about 3 minutes from right now — so you can immediately
watch the Join button unlock (5-minute window means it's already open)
and actually test the real Jitsi call end-to-end.

Safe to re-run any time: it deletes its own previous test data first, so
the "starts in 3 minutes" timing is always fresh relative to when you run it.

Usage:
    python manage.py seed_live_test
    python manage.py seed_live_test --minutes 2   # start sooner/later
"""
from datetime import timedelta

from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand
from django.utils import timezone

from skills.models import Category, Skill
from exchanges.models import SkillRequest, Notification
from exchanges.jitsi import generate_jitsi_room

User = get_user_model()

TEACHER_USERNAME = "demo_asha"
LEARNER_USERNAME = "demo_wei"
SKILL_TITLE = "LIVE TEST — Jitsi Check"


class Command(BaseCommand):
    help = "Create a live-in-a-few-minutes accepted session for testing the real Jitsi call end-to-end."

    def add_arguments(self, parser):
        parser.add_argument('--minutes', type=int, default=3, help="How many minutes from now the session starts (default 3).")

    def handle(self, *args, **options):
        minutes = options['minutes']
        teacher = User.objects.filter(username=TEACHER_USERNAME).first()
        learner = User.objects.filter(username=LEARNER_USERNAME).first()
        if not teacher or not learner:
            self.stderr.write(self.style.ERROR(
                f"Run `python manage.py seed_demo` first — {TEACHER_USERNAME} / {LEARNER_USERNAME} don't exist yet."
            ))
            return

        # Wipe any previous run of this same test so timing stays fresh.
        Skill.objects.filter(user=teacher, title=SKILL_TITLE).delete()

        category, _ = Category.objects.get_or_create(name="Testing")
        session_at = timezone.now() + timedelta(minutes=minutes)

        skill = Skill.objects.create(
            user=teacher,
            title=SKILL_TITLE,
            category=category,
            level='beginner',
            description="Not a real listing — just here so you can test the live Jitsi join flow.",
            fixed_session_at=session_at,
            capacity=1,
        )

        req = SkillRequest.objects.create(
            requester=learner,
            skill=skill,
            message="Testing the Jitsi flow.",
            status='accepted',
            fixed_session_at=session_at,
        )
        req.meet_link = generate_jitsi_room(req.id)
        req.save()

        Notification.objects.create(
            recipient=learner, skill_request=req,
            title="Request accepted", body=f"Your test session starts at {session_at.strftime('%I:%M %p')}.",
        )

        self.stdout.write(self.style.SUCCESS(
            f"\nLive test session created — starts at {session_at.strftime('%I:%M:%S %p')} ({minutes} min from now)."
        ))
        self.stdout.write(f"Log in as '{LEARNER_USERNAME}' (password DemoPass123!) -> Learning page -> Join session once the {minutes}-min mark passes the 5-min join window.")
        self.stdout.write(f"Meet link: {req.meet_link}")
        self.stdout.write("Re-run this command any time to reset the timer.")
