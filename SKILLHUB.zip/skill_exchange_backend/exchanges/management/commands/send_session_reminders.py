"""
Sends a "your session starts soon" notification to both the learner and
the teacher, 30 minutes before an accepted (confirmed, non-waitlisted)
session's fixed_session_at.

This is meant to be run on a schedule (cron, Celery beat, etc.), e.g.
every 5 minutes:

    */5 * * * * cd /path/to/project && python manage.py send_session_reminders

It's safe to run as often as you like — each request is only reminded
once (tracked by the reminder_sent flag), regardless of how often the
command runs.

Usage:
    python manage.py send_session_reminders
"""
from django.core.management.base import BaseCommand
from django.utils import timezone
from datetime import timedelta

from exchanges.models import SkillRequest, Notification

REMINDER_WINDOW_MINUTES = 30


class Command(BaseCommand):
    help = "Send a reminder notification ~30 minutes before each confirmed session."

    def handle(self, *args, **options):
        now = timezone.now()
        cutoff = now + timedelta(minutes=REMINDER_WINDOW_MINUTES)

        due = SkillRequest.objects.filter(
            status='accepted',
            is_waitlisted=False,
            reminder_sent=False,
            fixed_session_at__isnull=False,
            fixed_session_at__gt=now,
            fixed_session_at__lte=cutoff,
        ).select_related('requester', 'skill', 'skill__user')

        sent = 0
        for req in due:
            when = req.fixed_session_at.strftime('%I:%M %p on %b %d')
            Notification.objects.create(
                recipient=req.requester,
                skill_request=req,
                title="Your session starts soon",
                body=f"'{req.skill.title}' with @{req.teacher.username} starts at {when} (in about {REMINDER_WINDOW_MINUTES} minutes).",
            )
            Notification.objects.create(
                recipient=req.teacher,
                skill_request=req,
                title="Your session starts soon",
                body=f"'{req.skill.title}' with @{req.requester.username} starts at {when} (in about {REMINDER_WINDOW_MINUTES} minutes).",
            )
            req.reminder_sent = True
            req.save(update_fields=['reminder_sent'])
            sent += 1

        self.stdout.write(self.style.SUCCESS(f"Sent reminders for {sent} session(s)."))
