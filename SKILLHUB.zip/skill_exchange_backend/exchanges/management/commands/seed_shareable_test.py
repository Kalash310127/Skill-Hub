"""
Creates (or refreshes) 1-2 already-completed requests whose session time
is in the PAST — so `materials_unlocked` is true immediately, and you can
go straight to the Sharing page and test uploading a zip (and deleting
it) without waiting for any timer.

Unlike `seed_live_test` (which schedules a session a few minutes in the
FUTURE to test the Jitsi join window), this one is for testing the
Sharing feature specifically, which only unlocks AFTER a session time.

Safe to re-run any time: it wipes its own previous test data first.

Usage:
    python manage.py seed_shareable_test
    python manage.py seed_shareable_test --hours-ago 5
"""
from datetime import timedelta

from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand
from django.utils import timezone

from skills.models import Category, Skill
from exchanges.models import SkillRequest, Notification
from exchanges.jitsi import generate_jitsi_room

User = get_user_model()

TEACHER_USERNAME = "demo_asha"
LEARNER_USERNAMES = ["demo_wei", "demo_sofia"]  # up to 2 — separate cards on the Sent tab
SKILL_TITLE = "SHARE TEST — Materials Upload Check"


class Command(BaseCommand):
    help = "Create 1-2 already-completed, already-past sessions so Sharing/materials upload unlocks immediately."

    def add_arguments(self, parser):
        parser.add_argument('--hours-ago', type=int, default=2, help="How many hours in the past the session was (default 2).")

    def handle(self, *args, **options):
        hours_ago = options['hours_ago']
        teacher = User.objects.filter(username=TEACHER_USERNAME).first()
        if not teacher:
            self.stderr.write(self.style.ERROR(
                f"Run `python manage.py seed_demo` first — {TEACHER_USERNAME} doesn't exist yet."
            ))
            return

        learners = [User.objects.filter(username=u).first() for u in LEARNER_USERNAMES]
        learners = [l for l in learners if l is not None]
        if not learners:
            self.stderr.write(self.style.ERROR(
                f"Run `python manage.py seed_demo` first — none of {LEARNER_USERNAMES} exist yet."
            ))
            return

        # Wipe any previous run of this same test so it's always fresh.
        Skill.objects.filter(user=teacher, title=SKILL_TITLE).delete()

        category, _ = Category.objects.get_or_create(name="Testing")
        session_at = timezone.now() - timedelta(hours=hours_ago)

        skill = Skill.objects.create(
            user=teacher,
            title=SKILL_TITLE,
            category=category,
            level='beginner',
            description="Not a real listing — just here so you can test uploading/deleting shared materials.",
            fixed_session_at=session_at,
            capacity=len(learners),
        )

        self.stdout.write(self.style.SUCCESS(
            f"\nSkill created — session was {hours_ago}h ago ({session_at.strftime('%b %d, %I:%M %p')}), so materials are unlocked right now."
        ))

        for learner in learners:
            req = SkillRequest.objects.create(
                requester=learner,
                skill=skill,
                message="Testing the materials-sharing flow.",
                status='completed',
                fixed_session_at=session_at,
            )
            req.meet_link = generate_jitsi_room(req.id)
            req.save()
            Notification.objects.create(
                recipient=learner, skill_request=req,
                title="Session completed", body=f"Your test session for '{skill.title}' is done.",
            )
            self.stdout.write(f"  request: {learner.username} <- {teacher.username}  (id #{req.id}, completed, unlocked)")

        self.stdout.write(f"\nLog in as '{TEACHER_USERNAME}' (password DemoPass123!) -> Sharing -> Sent tab.")
        self.stdout.write("Each learner above gets their own card — click one, upload a zip under a lecture number, then use the delete button on it to test removal.")
        self.stdout.write(f"Log in as any of {', '.join(l.username for l in learners)} -> Sharing -> Received tab to see/download what the teacher shares.")
        self.stdout.write("Re-run this command any time to reset it.")
