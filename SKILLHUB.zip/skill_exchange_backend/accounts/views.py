from rest_framework import generics, permissions
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.tokens import RefreshToken

from .models import Profile
from .serializers import (
    RegisterSerializer,
    UserSerializer,
    ProfileUpdateSerializer,
    PublicUserSerializer,
    PublicDirectorySerializer,
)


class RegisterView(generics.CreateAPIView):
    """
    POST /api/accounts/register/
    Public endpoint. Creates a user + profile, and immediately returns
    JWT tokens so the frontend can log the user straight in.
    """
    permission_classes = [permissions.AllowAny]
    serializer_class = RegisterSerializer

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.save()

        refresh = RefreshToken.for_user(user)
        return Response({
            "user": UserSerializer(user, context={'request': request}).data,
            "access": str(refresh.access_token),
            "refresh": str(refresh),
        }, status=201)


class MeView(APIView):
    """
    GET  /api/accounts/me/   -> current user's full profile
    Requires a valid JWT access token in the Authorization header.
    """
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        return Response(UserSerializer(request.user, context={'request': request}).data)


class ProfileUpdateView(generics.RetrieveUpdateAPIView):
    """
    GET/PATCH /api/accounts/profile/
    Lets the logged-in user view/edit their own profile fields.
    """
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = ProfileUpdateSerializer

    def get_object(self):
        return self.request.user.profile


class PublicProfileView(generics.RetrieveAPIView):
    """
    GET /api/accounts/users/<id>/
    Public read-only view of any user's profile (e.g. before sending
    them a skill request) — shows bio, skills, rating, but never email.
    """
    permission_classes = [permissions.AllowAny]
    serializer_class = PublicUserSerializer
    queryset = Profile.objects.select_related('user').all()
    lookup_field = 'user_id'
    lookup_url_kwarg = 'user_id'

    def get_object(self):
        from django.contrib.auth import get_user_model
        User = get_user_model()
        return User.objects.get(pk=self.kwargs['user_id'])


class DirectoryListView(generics.ListAPIView):
    """
    GET /api/accounts/directory/
    Public "meet the teachers" list for the home page carousel.
    Deliberately no ratings/reviews here — just who they are and what
    they teach. Only includes users who actually offer at least one
    active skill (so it doesn't list every empty account).
    """
    permission_classes = [permissions.AllowAny]
    serializer_class = PublicDirectorySerializer

    def get_queryset(self):
        from django.contrib.auth import get_user_model
        from skills.models import Skill
        User = get_user_model()
        teacher_ids = Skill.objects.filter(is_active=True).values_list('user_id', flat=True).distinct()
        return User.objects.filter(id__in=teacher_ids).select_related('profile')
