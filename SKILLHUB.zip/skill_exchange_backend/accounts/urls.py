from django.urls import path
from .views import RegisterView, MeView, ProfileUpdateView, PublicProfileView, DirectoryListView

urlpatterns = [
    path('register/', RegisterView.as_view(), name='register'),
    path('me/', MeView.as_view(), name='me'),
    path('profile/', ProfileUpdateView.as_view(), name='profile-update'),
    path('users/<int:user_id>/', PublicProfileView.as_view(), name='public-profile'),
    path('directory/', DirectoryListView.as_view(), name='directory'),
]
