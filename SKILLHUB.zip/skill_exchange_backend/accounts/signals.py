from django.conf import settings
from django.db.models.signals import post_save
from django.dispatch import receiver

from .models import Profile


@receiver(post_save, sender=settings.AUTH_USER_MODEL)
def create_or_update_profile(sender, instance, created, **kwargs):
    """
    Automatically create a Profile the moment a User is created,
    so every user always has one (no null checks needed elsewhere).
    """
    if created:
        Profile.objects.create(user=instance)
    else:
        # Make sure older users (created before this signal existed) still get one.
        Profile.objects.get_or_create(user=instance)
