from django.conf import settings
from django.db import models


class Profile(models.Model):
    """
    Extends Django's built-in User model with extra fields.
    We keep Django's default User model for auth (username, email, password)
    to keep things simple, and store everything else here (1-to-1).
    """
    user = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='profile',
    )
    bio = models.TextField(blank=True, default='')
    location = models.CharField(max_length=120, blank=True, default='')
    profile_picture = models.ImageField(upload_to='profile_pics/', blank=True, null=True)

    # Each teacher sets their own preferred daily time-of-day for each
    # skill level. When they accept a request, the request's skill level
    # decides which of these gets assigned — so a beginner-level session
    # and an advanced-level session from the same teacher never land on
    # the same time, even if both get accepted the same day.
    beginner_session_time = models.TimeField(
        null=True, blank=True,
        help_text="Daily time this teacher holds beginner-level sessions, e.g. 17:00.",
    )
    intermediate_session_time = models.TimeField(
        null=True, blank=True,
        help_text="Daily time this teacher holds intermediate-level sessions, e.g. 18:00.",
    )
    experienced_session_time = models.TimeField(
        null=True, blank=True,
        help_text="Daily time this teacher holds advanced/experienced-level sessions, e.g. 19:00.",
    )

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"Profile of {self.user.username}"
