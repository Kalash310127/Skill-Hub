from django.contrib.auth import get_user_model
from django.contrib.auth.password_validation import validate_password
from django.db.models import Avg, Count
from rest_framework import serializers

from .models import Profile

User = get_user_model()


class AchievementInlineSerializer(serializers.Serializer):
    """Lightweight read-only view of a learned skill, embedded in a profile."""
    id = serializers.IntegerField()
    title = serializers.CharField()
    earned_at = serializers.DateTimeField()
    skill_id = serializers.SerializerMethodField()
    level = serializers.SerializerMethodField()
    taught_by = serializers.SerializerMethodField()
    taught_by_id = serializers.SerializerMethodField()

    def get_skill_id(self, achievement):
        return achievement.skill_id

    def get_level(self, achievement):
        return achievement.skill.level if achievement.skill_id else None

    def get_taught_by(self, achievement):
        req = achievement.skill_request
        return req.teacher.username if req else None

    def get_taught_by_id(self, achievement):
        req = achievement.skill_request
        return req.teacher.id if req else None


class ProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = Profile
        fields = [
            'bio', 'location', 'profile_picture',
            'beginner_session_time', 'intermediate_session_time', 'experienced_session_time',
            'created_at', 'updated_at',
        ]
        read_only_fields = ['created_at', 'updated_at']


class UserSerializer(serializers.ModelSerializer):
    """
    Read-only-ish view of a user, with their profile, learned-skill
    achievements, and rating summary all nested in one response —
    everything needed to render a profile page in a single API call.
    """
    profile = ProfileSerializer(read_only=True)
    achievements = serializers.SerializerMethodField()
    rating = serializers.SerializerMethodField()
    completed_sessions = serializers.SerializerMethodField()

    class Meta:
        model = User
        fields = [
            'id', 'username', 'email', 'first_name', 'last_name',
            'profile', 'achievements', 'rating', 'completed_sessions',
        ]
        read_only_fields = ['id']

    def get_achievements(self, user):
        # Imported here (not at module level) to avoid a circular import.
        from achievements.models import Achievement
        qs = Achievement.objects.filter(user=user).select_related('skill', 'skill_request', 'skill_request__skill__user').order_by('-earned_at')
        return AchievementInlineSerializer(qs, many=True).data

    def get_rating(self, user):
        from reviews.models import Review
        stats = Review.objects.filter(reviewee=user).aggregate(
            average_rating=Avg('rating'), review_count=Count('id')
        )
        return {
            "average_rating": round(stats['average_rating'], 2) if stats['average_rating'] else None,
            "review_count": stats['review_count'],
        }

    def get_completed_sessions(self, user):
        """How many sessions this user has taught to completion (verified count)."""
        from exchanges.models import SkillRequest
        return SkillRequest.objects.filter(skill__user=user, status='completed').count()


class PublicUserSerializer(serializers.ModelSerializer):
    """
    Same shape as UserSerializer (profile, achievements, rating) but with
    no email — this one is served with AllowAny, so it must never expose
    contact details, only what's meant to be public.
    """
    profile = ProfileSerializer(read_only=True)
    achievements = serializers.SerializerMethodField()
    rating = serializers.SerializerMethodField()
    full_name = serializers.SerializerMethodField()
    skills = serializers.SerializerMethodField()
    completed_sessions = serializers.SerializerMethodField()
    is_standout_teacher = serializers.SerializerMethodField()

    class Meta:
        model = User
        fields = [
            'id', 'username', 'full_name', 'profile', 'achievements', 'rating',
            'skills', 'completed_sessions', 'is_standout_teacher',
        ]
        read_only_fields = ['id']

    def get_is_standout_teacher(self, user):
        """
        Auto-highlighted on PublicProfile.jsx when a teacher's reviews show
        a consistently strong rating + genuinely positive sentiment in the
        written feedback (not just star-farming) — see reviews.ml.standout_teacher_stats.
        """
        from reviews.ml import standout_teacher_stats
        return standout_teacher_stats(user)['is_standout']

    def get_completed_sessions(self, user):
        from exchanges.models import SkillRequest
        return SkillRequest.objects.filter(skill__user=user, status='completed').count()

    def get_full_name(self, user):
        name = f"{user.first_name} {user.last_name}".strip()
        return name or user.username

    def get_skills(self, user):
        from skills.models import Skill
        qs = Skill.objects.filter(user=user, is_active=True).select_related('category')
        return [
            {
                'id': s.id, 'title': s.title, 'level': s.level,
                'category_name': s.category.name if s.category else None,
            }
            for s in qs
        ]

    def get_achievements(self, user):
        from achievements.models import Achievement
        qs = Achievement.objects.filter(user=user).select_related('skill', 'skill_request', 'skill_request__skill__user').order_by('-earned_at')
        return AchievementInlineSerializer(qs, many=True).data

    def get_rating(self, user):
        from reviews.models import Review
        stats = Review.objects.filter(reviewee=user).aggregate(
            average_rating=Avg('rating'), review_count=Count('id')
        )
        return {
            "average_rating": round(stats['average_rating'], 2) if stats['average_rating'] else None,
            "review_count": stats['review_count'],
        }


class PublicDirectorySerializer(serializers.ModelSerializer):
    """
    Public "who's teaching here" info — deliberately excludes ratings,
    reviews, and contact details. Just enough to decide whether to view
    their skills: name, a short bio, general location, and what they teach.
    Actually contacting them requires logging in (enforced by the skills/
    exchanges endpoints, not by hiding info here).
    """
    full_name = serializers.SerializerMethodField()
    bio = serializers.CharField(source='profile.bio', default='')
    location = serializers.CharField(source='profile.location', default='')
    skills = serializers.SerializerMethodField()

    class Meta:
        model = User
        fields = ['id', 'username', 'full_name', 'bio', 'location', 'skills']

    def get_full_name(self, user):
        name = f"{user.first_name} {user.last_name}".strip()
        return name or user.username

    def get_skills(self, user):
        from skills.models import Skill
        qs = Skill.objects.filter(user=user, is_active=True).select_related('category')
        return [
            {
                'id': s.id,
                'title': s.title,
                'level': s.level,
                'category_name': s.category.name if s.category else None,
            }
            for s in qs
        ]


class RegisterSerializer(serializers.ModelSerializer):
    """
    Handles new user sign-up.
    POST /api/auth/register/  {username, email, password, password2}
    """
    password = serializers.CharField(
        write_only=True, required=True, validators=[validate_password]
    )
    password2 = serializers.CharField(write_only=True, required=True, label='Confirm password')

    class Meta:
        model = User
        fields = ['username', 'email', 'password', 'password2', 'first_name', 'last_name']

    def validate_email(self, value):
        if User.objects.filter(email__iexact=value).exists():
            raise serializers.ValidationError("A user with that email already exists.")
        return value

    def validate(self, attrs):
        if attrs['password'] != attrs['password2']:
            raise serializers.ValidationError({"password2": "Passwords do not match."})
        return attrs

    def create(self, validated_data):
        validated_data.pop('password2')
        password = validated_data.pop('password')
        user = User(**validated_data)
        user.set_password(password)
        user.save()  # Profile is auto-created via the post_save signal
        return user


class ProfileUpdateSerializer(serializers.ModelSerializer):
    """
    Lets a logged-in user update their own name + profile fields together
    in a single PATCH request.
    """
    first_name = serializers.CharField(source='user.first_name', required=False)
    last_name = serializers.CharField(source='user.last_name', required=False)

    class Meta:
        model = Profile
        fields = [
            'first_name', 'last_name', 'bio', 'location', 'profile_picture',
            'beginner_session_time', 'intermediate_session_time', 'experienced_session_time',
        ]

    def update(self, instance, validated_data):
        user_data = validated_data.pop('user', {})
        for attr, value in user_data.items():
            setattr(instance.user, attr, value)
        instance.user.save()

        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        instance.save()
        return instance
