"""
Seeds the database with realistic, coding/database-themed demo data so
the site looks alive immediately after a fresh `migrate` — demo users,
skills (with tags, capacity, a fixed session time), requests in every
status (pending/accepted/waitlisted/completed/rejected), achievements,
reviews, notifications, and wishlist items.

Usage:
    python manage.py seed_demo            # add demo data (safe to re-run)
    python manage.py seed_demo --reset     # wipe demo data first, then reseed
"""
import random
from datetime import timedelta

from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand
from django.db import transaction
from django.utils import timezone

from accounts.models import Profile
from skills.models import Category, Tag, Skill, Wishlist
from exchanges.models import SkillRequest, Notification
from exchanges.jitsi import generate_jitsi_room
from achievements.models import Achievement
from reviews.models import Review

User = get_user_model()
DEMO_PASSWORD = "DemoPass123!"

# Every demo account uses this same username prefix, so --reset can find
# and remove exactly these users without touching any real accounts.
DEMO_PREFIX = "demo_"

DEMO_USERS = [
    # username,        first,      last,     bio,                                                          location
    ("demo_asha",       "Asha",     "Rao",    "Backend engineer. I teach Python and Django in my spare time.", "Bengaluru, IN"),
    ("demo_marcus",     "Marcus",   "Lee",    "DBA for 8 years. PostgreSQL, indexing, query tuning.",           "Austin, TX"),
    ("demo_priya",      "Priya",    "Nair",   "Frontend dev — React, TypeScript, a bit of design.",             "Kochi, IN"),
    ("demo_tom",        "Tom",      "Becker", "DevOps: Docker, Kubernetes, CI/CD pipelines.",                   "Berlin, DE"),
    ("demo_wei",        "Wei",      "Zhang",  "Learning full-stack dev, mostly picking up SQL and Git so far.", "Toronto, CA"),
    ("demo_sofia",      "Sofia",    "Martins","CS student. Learning React, want to teach basic Python later.",  "Lisbon, PT"),
]

# (title, category, level, description, teacher_username, tags, hours_from_now, capacity)
DEMO_SKILLS = [
    ("Python Fundamentals",       "Python",   "beginner",     "Variables, loops, functions, and writing your first real scripts.", "demo_asha",   ["python", "beginner-friendly"], 26, 4),
    ("Django REST Framework",     "Backend",  "intermediate", "Build a JWT-authenticated API from scratch, just like this project.", "demo_asha", ["python", "django", "api"], 50, 3),
    ("Advanced Django ORM",       "Backend",  "advanced",     "Query optimization, select_related/prefetch_related, custom managers.", "demo_asha", ["python", "django"], 74, 2),
    ("PostgreSQL for Beginners",  "Database", "beginner",     "Tables, joins, and writing your first real queries.", "demo_marcus", ["sql", "database", "beginner-friendly"], 32, 5),
    ("SQL Query Optimization",    "Database", "intermediate", "EXPLAIN plans, indexing strategy, and fixing slow queries.", "demo_marcus", ["sql", "database"], 0.4, 1),
    ("React Fundamentals",        "React",    "beginner",     "Components, props, state — building your first interactive UI.", "demo_priya", ["react", "frontend", "beginner-friendly"], 28, 3),
    ("React + TypeScript",        "React",    "intermediate", "Typing props, hooks, and common patterns in real apps.", "demo_priya", ["react", "typescript", "frontend"], 44, 2),
    ("Docker Basics",             "DevOps",   "beginner",     "Images, containers, and Dockerfiles for your own projects.", "demo_tom", ["docker", "devops", "beginner-friendly"], 0.5, 1),
    ("CI/CD with GitHub Actions", "DevOps",   "intermediate", "Automate tests and deployments on every push.", "demo_tom", ["ci-cd", "devops", "remote-friendly"], 56, 2),
    ("Kubernetes for Developers", "DevOps",   "advanced",     "Pods, deployments, and debugging a real cluster.", "demo_tom", ["kubernetes", "devops"], 90, 1),
]


class Command(BaseCommand):
    help = "Seed the database with demo users, skills, requests, achievements, reviews, notifications and wishlist items."

    def add_arguments(self, parser):
        parser.add_argument(
            '--reset', action='store_true',
            help="Delete all existing demo_* users (and everything cascading from them) before reseeding.",
        )

    def handle(self, *args, **options):
        if options['reset']:
            deleted, _ = User.objects.filter(username__startswith=DEMO_PREFIX).delete()
            self.stdout.write(self.style.WARNING(f"Removed {deleted} existing demo rows."))

        with transaction.atomic():
            users = self._create_users()
            self._create_skills(users)
            self._create_requests_and_followups(users)
            self._create_wishlist_items(users)

        self.stdout.write(self.style.SUCCESS("\nDemo data ready."))
        self.stdout.write(f"Log in as any of: {', '.join(u[0] for u in DEMO_USERS)}")
        self.stdout.write(f"Password for all demo accounts: {DEMO_PASSWORD}")
        self.stdout.write(
            "\nTip: run `python manage.py send_session_reminders` any time — "
            "'SQL Query Optimization' and 'Docker Basics' are seeded to start "
            "within the next hour, so a reminder should fire for them."
        )

    def _create_users(self):
        users = {}
        for username, first, last, bio, location in DEMO_USERS:
            user, created = User.objects.get_or_create(
                username=username,
                defaults={"email": f"{username}@example.com", "first_name": first, "last_name": last},
            )
            if created:
                user.set_password(DEMO_PASSWORD)
                user.save()
            profile, _ = Profile.objects.get_or_create(user=user)
            profile.bio = bio
            profile.location = location
            profile.save()
            users[username] = user
            self.stdout.write(f"  user: {username}")
        return users

    def _create_skills(self, users):
        self.skills = {}
        now = timezone.now()
        for title, category_name, level, description, teacher_username, tag_names, hours_from_now, capacity in DEMO_SKILLS:
            category, _ = Category.objects.get_or_create(name=category_name)
            skill, _ = Skill.objects.get_or_create(
                user=users[teacher_username],
                title=title,
                defaults={
                    "category": category,
                    "level": level,
                    "description": description,
                    "fixed_session_at": now + timedelta(hours=hours_from_now),
                    "capacity": capacity,
                },
            )
            tags = [Tag.objects.get_or_create(name=n)[0] for n in tag_names]
            skill.tags.set(tags)
            self.skills[title] = skill
            self.stdout.write(f"  skill: {title} ({level}, by {teacher_username}, {capacity} seat(s))")

    def _create_requests_and_followups(self, users):
        """
        Creates one request per scenario, all with realistic messages, so
        every part of the /exchanges/ UI has something to show: pending,
        accepted (with a live meet_link + fixed_session_at), waitlisted
        (capacity already full), completed (with an Achievement + Review),
        and rejected.
        """
        scenarios = [
            # (learner, skill title, status, message)
            ("demo_wei", "PostgreSQL for Beginners", "completed",
             "Would love to finally understand joins properly."),
            ("demo_wei", "Python Fundamentals", "completed",
             "Picking up Python before I start Django."),
            ("demo_sofia", "React Fundamentals", "accepted",
             "I know HTML/CSS, ready to learn components."),
            ("demo_sofia", "Docker Basics", "pending",
             "Want to containerize my class project."),
            ("demo_wei", "SQL Query Optimization", "accepted",
             "My queries are painfully slow, help!"),
            ("demo_sofia", "Advanced Django ORM", "rejected",
             "Is this too advanced for someone who just started Django?"),
            # SQL Query Optimization has only 1 seat and demo_wei already
            # took it above — this second request demonstrates the waitlist.
            ("demo_sofia", "SQL Query Optimization", "accepted",
             "(second learner, to demo the waitlist — capacity is 1)"),
        ]

        for learner_username, skill_title, target_status, message in scenarios:
            learner = users[learner_username]
            skill = self.skills[skill_title]
            if learner == skill.user:
                continue  # skip nonsensical self-requests if usernames ever collide

            req, created = SkillRequest.objects.get_or_create(
                requester=learner,
                skill=skill,
                defaults={"message": message, "status": "pending"},
            )
            if not created:
                continue  # already seeded on a previous run

            if target_status == "pending":
                pass  # leave as-is

            elif target_status == "rejected":
                req.status = "rejected"
                req.save()

            elif target_status == "accepted":
                req.status = "accepted"
                req.fixed_session_at = skill.fixed_session_at
                if skill.accepted_count < skill.capacity:
                    req.is_waitlisted = False
                    req.meet_link = generate_jitsi_room(req.id)
                    Notification.objects.create(
                        recipient=learner, skill_request=req,
                        title="Request accepted",
                        body=f"{skill.user.username} accepted your request for '{skill.title}'. Your Jitsi room is ready.",
                    )
                else:
                    req.is_waitlisted = True
                    Notification.objects.create(
                        recipient=learner, skill_request=req,
                        title="You're on the waitlist",
                        body=f"'{skill.title}' is full for now — you'll be notified if a seat opens up.",
                    )
                req.save()

            elif target_status == "completed":
                req.status = "accepted"
                req.fixed_session_at = skill.fixed_session_at
                req.meet_link = generate_jitsi_room(req.id)
                req.status = "completed"
                req.save()

                Achievement.objects.get_or_create(
                    skill_request=req,
                    defaults={"user": learner, "skill": skill, "title": skill.title},
                )
                Review.objects.get_or_create(
                    skill_request=req,
                    defaults={
                        "reviewer": learner,
                        "reviewee": skill.user,
                        "rating": random.choice([4, 5, 5]),
                        "comment": random.choice([
                            "Really clear explanations, went at a good pace.",
                            "Patient teacher, answered all my questions.",
                            "Exactly what I needed to get unstuck.",
                        ]),
                    },
                )

            self.stdout.write(f"  request: {learner_username} -> {skill_title} [{req.status}{' / waitlisted' if req.is_waitlisted else ''}]")

    def _create_wishlist_items(self, users):
        items = [
            ("demo_wei", "GraphQL API design", "Want to compare it against the REST APIs I already know."),
            ("demo_sofia", "Unit testing in Python", "Before I touch Django's test framework."),
        ]
        for username, title, notes in items:
            Wishlist.objects.get_or_create(user=users[username], title=title, defaults={"notes": notes})
            self.stdout.write(f"  wishlist: {username} wants to learn {title}")
