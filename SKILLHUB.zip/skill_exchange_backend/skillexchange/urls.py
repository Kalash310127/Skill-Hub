"""
URL configuration for skillexchange project.

The frontend is now a standalone React/Vite app (skill_exchange_frontend/)
that talks to this project purely over the JSON REST API below. This
project no longer serves any server-rendered frontend pages.
"""
from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import path, include
from rest_framework_simplejwt.views import (
    TokenObtainPairView,
    TokenRefreshView,
)
from .views import api_home

urlpatterns = [
    # ---- Admin -----------------------------------------------------------
    path('admin/', admin.site.urls),

    # ---- REST API ----------------------------------------------------------
    path('api/', api_home, name='api-home'),
    path('api/auth/login/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('api/auth/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    path('api/accounts/', include('accounts.urls')),
    path('api/skills/', include('skills.urls')),
    path('api/exchanges/', include('exchanges.urls')),
    path('api/achievements/', include('achievements.urls')),
    path('api/reviews/', include('reviews.urls')),
]

# Uploaded session-material zips — served directly by Django only in dev
# (DEBUG=True). In production these should be served by your web server
# or object storage, not Django itself.
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
