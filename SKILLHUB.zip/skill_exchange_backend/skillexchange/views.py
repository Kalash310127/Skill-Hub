from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny
from rest_framework.response import Response


@api_view(['GET'])
@permission_classes([AllowAny])
def api_home(request):
    """
    GET /
    A simple index of the API so hitting the root URL is useful instead
    of a 404 — handy for the frontend team and for quick sanity checks.
    """
    base = request.build_absolute_uri('/')[:-1]  # strip trailing slash
    return Response({
        "message": "SkillHub API is running",
        "docs": "See README for full endpoint list",
        "endpoints": {
            "admin": f"{base}/admin/",
            "auth": {
                "login": f"{base}/api/auth/login/",
                "refresh": f"{base}/api/auth/refresh/",
            },
            "accounts": {
                "register": f"{base}/api/accounts/register/",
                "me": f"{base}/api/accounts/me/",
                "profile": f"{base}/api/accounts/profile/",
                "public_profile": f"{base}/api/accounts/users/<id>/",
            },
            "skills": {
                "list_create": f"{base}/api/skills/skills/",
                "categories": f"{base}/api/skills/categories/",
            },
            "exchanges": {
                "requests": f"{base}/api/exchanges/requests/",
                "accept": f"{base}/api/exchanges/requests/<id>/accept/",
                "reject": f"{base}/api/exchanges/requests/<id>/reject/",
                "cancel": f"{base}/api/exchanges/requests/<id>/cancel/",
                "complete": f"{base}/api/exchanges/requests/<id>/complete/",
            },
            "achievements": f"{base}/api/achievements/achievements/",
            "reviews": {
                "list_create": f"{base}/api/reviews/reviews/",
                "rating_summary": f"{base}/api/reviews/summary/<user_id>/",
            },
        },
    })
