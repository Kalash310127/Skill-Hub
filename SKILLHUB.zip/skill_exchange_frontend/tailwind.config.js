/** @type {import('tailwindcss').Config} */
export default {
  darkMode: 'class',
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        // ink & parchment are CSS-variable driven (see src/index.css) so
        // toggling the `dark` class on <html> flips every text/background
        // color that uses them across the whole app automatically.
        ink: {
          DEFAULT: 'rgb(var(--color-ink-800) / <alpha-value>)',
          50: 'rgb(var(--color-ink-50) / <alpha-value>)',
          100: 'rgb(var(--color-ink-100) / <alpha-value>)',
          400: 'rgb(var(--color-ink-400) / <alpha-value>)',
          600: 'rgb(var(--color-ink-600) / <alpha-value>)',
          700: 'rgb(var(--color-ink-700) / <alpha-value>)',
          800: 'rgb(var(--color-ink-800) / <alpha-value>)',
          900: 'rgb(var(--color-ink-900) / <alpha-value>)',
        },
        parchment: {
          DEFAULT: 'rgb(var(--color-parchment-100) / <alpha-value>)',
          50: 'rgb(var(--color-parchment-50) / <alpha-value>)',
          100: 'rgb(var(--color-parchment-100) / <alpha-value>)',
          200: 'rgb(var(--color-parchment-200) / <alpha-value>)',
        },
        // Five fixed accent colors — vivid, and deliberately varied so the
        // board reads as colorful rather than monochrome.
        amber: { DEFAULT: '#F5A524', 50: '#FEF3E0', 100: '#FCE4B8', 400: '#F7B94E', 500: '#F5A524', 600: '#DB8B12', 700: '#B06F0D' },
        clay:  { DEFAULT: '#FF6B5B', 50: '#FFEEEC', 100: '#FFD9D3', 400: '#FF8A7D', 500: '#FF6B5B', 600: '#E8503F', 700: '#C43F30' },
        moss:  { DEFAULT: '#12B76A', 50: '#E8FBF1', 100: '#D8F5E7', 400: '#3ECB8C', 500: '#12B76A', 600: '#0E9F5C', 700: '#0A7C48' },
        teal:  { DEFAULT: '#14B8A6', 50: '#E6FBF9', 100: '#D3F3EF', 400: '#3FCCBD', 500: '#14B8A6', 600: '#0E9488', 700: '#0B776D' },
        plum:  { DEFAULT: '#7C5CFC', 50: '#F1EEFF', 100: '#E7E1FF', 400: '#9B82FD', 500: '#7C5CFC', 600: '#6142E0', 700: '#4E32BB' },
      },
      fontFamily: {
        display: ['"Sora"', 'sans-serif'],
        body: ['"Inter"', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'monospace'],
      },
      boxShadow: {
        soft: '0 2px 10px -2px rgb(15 23 42 / 0.06), 0 1px 2px -1px rgb(15 23 42 / 0.04)',
        lift: '0 12px 28px -8px rgb(15 23 42 / 0.16), 0 2px 6px -2px rgb(15 23 42 / 0.06)',
      },
    },
  },
  plugins: [],
}
