# public/

Anything placed in this folder is served as-is at the site root by Vite
(both in `npm run dev` and in the production build).

## Adding the tutorial video

1. Drop your video file here, e.g. `tutorial.mp4`
   (so the full path is `skill_exchange_frontend/public/tutorial.mp4`).
2. In `skill_exchange_frontend/.env`, set:
   ```
   VITE_TUTORIAL_VIDEO_URL=/tutorial.mp4
   ```
3. Restart `npm run dev` (Vite only reads `.env` on startup).

`TutorialModal.jsx` will then play that file directly — no YouTube/hosting
needed. If you'd rather host it externally (YouTube, Google Drive share
link, S3, Cloudinary, etc.), set `VITE_TUTORIAL_VIDEO_URL` to that URL
instead (a `https://www.youtube.com/embed/VIDEO_ID` link renders as an
embedded iframe; any other URL renders as a plain `<video>` tag).
