# SkillHub — Skill Exchange Frontend

A React + Vite + Tailwind frontend built for the `skill_exchange_backend` Django REST API.
Post skills you can teach, browse the board, send trade requests, and leave reviews once
an exchange is complete.

## Folder structure

```
src/
  api/            # one file per Django app — thin wrappers around axios calls
  context/        # AuthContext — JWT login state, shared across the app
  components/
    layout/       # Navbar, Footer, ProtectedRoute
    ui/            Button-less primitives: Modal, Loader, ErrorNote, Badge, StarRating
    skills/         SkillCard, SkillForm
    requests/       RequestCard
    reviews/        ReviewForm, ReviewCard
  pages/          # one file per route
```

## 1. Run the backend

```bash
cd skill_exchange_backend
python -m venv venv
source venv/bin/activate        # venv\Scripts\activate on Windows
pip install -r requirements.txt
python manage.py migrate
python manage.py runserver
```

The API will be live at `http://localhost:8000/api/`.

## 2. Run the frontend

```bash
cd skill_exchange_frontend
npm install
cp .env.example .env       # VITE_API_URL=http://localhost:8000/api
npm run dev
```

Open `http://localhost:5173`. CORS is already configured on the backend for this origin.

## Optional: seed some demo data

A fresh database has no users or listings, so the board looks empty at first. To
populate it with a few demo users and skills, run this from the backend folder
(with the venv active):

```bash
python manage.py seed_demo_data
```

This creates 3 demo users (`amara`, `ravi`, `lena`, all with password `tradepost123`)
and a handful of skill listings so you have something to click through immediately.
Safe to re-run — it won't duplicate existing records.

## How the two talk to each other

- `POST /api/accounts/register/` and `POST /api/auth/login/` return `access` + `refresh`
  JWTs, stored in `localStorage`. Every request through `src/api/client.js` attaches the
  access token, and a 401 automatically tries `/api/auth/refresh/` once before giving up.
- Browsing skills, categories, and public profiles works logged out.
- Sending a request, posting a skill, editing your profile, and leaving a review all
  require login (the API enforces this too — the frontend just avoids showing dead ends).

## What each page does

| Route | What happens there |
|---|---|
| `/` | Search & filter the skill board (category, level, text search), paginated |
| `/skills/:id` | Full listing + teacher's rating, send a request to learn it |
| `/my-skills` | Create / edit / delete your own skill listings |
| `/requests` | Received vs. sent requests — accept, decline, cancel, mark complete, review |
| `/profile`, `/profile/edit` | Your card: bio, rating, achievements (skills learned), listings |
| `/users/:id` | Anyone else's public trading card |

## New: Google Meet links, dark mode, and onboarding video

**Google Meet links** — once a request is `accepted`, the teacher sees an inline
field on the Requests page to paste a `meet.google.com` link. Once saved, both
sides see a "Join Google Meet" button on that request card. The link is stored
on the backend (`SkillRequest.meet_link`) and can only be set by the teacher,
only while the request is `accepted` (enforced server-side, not just hidden in
the UI).

**Dark mode** — click the gear icon in the navbar (desktop and mobile) to open
Settings, then flip the Light/Dark switch. The whole app re-themes instantly;
the choice is remembered in `localStorage` and otherwise defaults to the
visitor's OS-level preference. This is implemented with CSS variables (see
`src/index.css`), not scattered `dark:` classes — every existing page and
component picks up the correct colors automatically.

**Onboarding tutorial video** — shown once per account, right after their
first login or registration. Set `VITE_TUTORIAL_VIDEO_URL` in `.env` to either
a YouTube embed URL (`https://www.youtube.com/embed/VIDEO_ID`) or a direct
`.mp4` link; leave it blank and a placeholder card shows instead of a broken
embed.

**More color variety** — category tags on skill listings now rotate through
five accent colors (amber, moss, clay, teal, plum) based on the category name,
instead of a single flat color everywhere.

## Notes

- Achievements are read-only and created automatically by the backend when a request is
  marked `complete` — there's no "add achievement" UI on purpose.
- A review can only be left by the learner on a `completed` request, once, matching the
  backend's validation.
