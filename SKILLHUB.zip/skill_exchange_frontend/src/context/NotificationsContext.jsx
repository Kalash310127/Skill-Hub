import { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react'
import { getUnreadNotificationCount } from '../api/exchanges'
import { useAuth } from './AuthContext'

const NotificationsContext = createContext(null)

const POLL_INTERVAL_MS = 15000

export function NotificationsProvider({ children }) {
  const { user } = useAuth()
  const [unreadCount, setUnreadCount] = useState(0)
  const intervalRef = useRef(null)

  const refreshUnreadCount = useCallback(async () => {
    if (!user) return
    try {
      const { data } = await getUnreadNotificationCount()
      setUnreadCount(data.count)
    } catch {
      // Silently ignore — the badge just won't update this cycle.
    }
  }, [user])

  useEffect(() => {
    if (!user) {
      setUnreadCount(0)
      return
    }
    refreshUnreadCount()
    intervalRef.current = setInterval(refreshUnreadCount, POLL_INTERVAL_MS)
    return () => clearInterval(intervalRef.current)
  }, [user, refreshUnreadCount])

  return (
    <NotificationsContext.Provider value={{ unreadCount, refreshUnreadCount }}>
      {children}
    </NotificationsContext.Provider>
  )
}

export const useNotifications = () => useContext(NotificationsContext)
