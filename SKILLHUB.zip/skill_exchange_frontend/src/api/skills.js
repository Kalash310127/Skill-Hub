import client from './client'

export const listSkills = (params = {}) => client.get('/skills/skills/', { params })

export const getSkill = (id) => client.get(`/skills/skills/${id}/`)

export const createSkill = (payload) => client.post('/skills/skills/', payload)

export const updateSkill = (id, payload) => client.patch(`/skills/skills/${id}/`, payload)

export const deleteSkill = (id) => client.delete(`/skills/skills/${id}/`)

export const listCategories = () => client.get('/skills/categories/')
export const listTags = () => client.get('/skills/tags/')
export const listRandomPicks = () => client.get('/skills/skills/random_picks/')
export const suggestSkillTags = (payload) => client.post('/skills/skills/suggest_tags/', payload)
export const listWishlist = () => client.get('/skills/wishlist/')
export const addWishlistItem = (payload) => client.post('/skills/wishlist/', payload)
export const deleteWishlistItem = (id) => client.delete(`/skills/wishlist/${id}/`)
export const toggleWishlist = (skillId) => client.post('/skills/wishlist/toggle/', { skill: skillId })
