import client from './client'

export const listRequests = () => client.get('/exchanges/requests/')

export const getRequest = (id) => client.get(`/exchanges/requests/${id}/`)

export const sendRequest = (payload) => client.post('/exchanges/requests/', payload)

export const acceptRequest = (id) => client.post(`/exchanges/requests/${id}/accept/`)

export const rejectRequest = (id) => client.post(`/exchanges/requests/${id}/reject/`)

export const cancelRequest = (id) => client.post(`/exchanges/requests/${id}/cancel/`)

export const completeRequest = (id) => client.post(`/exchanges/requests/${id}/complete/`)

export const setMeetLink = (id, meetLink) => client.post(`/exchanges/requests/${id}/set_meet_link/`, { meet_link: meetLink })
export const listNotifications = () => client.get('/exchanges/notifications/')
export const getUnreadNotificationCount = () => client.get('/exchanges/notifications/unread_count/')
export const markNotificationRead = (id) => client.post(`/exchanges/notifications/${id}/mark_read/`)
export const markAllNotificationsRead = () => client.post('/exchanges/notifications/mark_all_read/')

export const uploadMaterial = (id, file, { lectureNumber, note } = {}) => {
  const form = new FormData()
  form.append('file', file)
  if (lectureNumber) form.append('lecture_number', lectureNumber)
  if (note) form.append('note', note)
  return client.post(`/exchanges/requests/${id}/upload_material/`, form, {
    headers: { 'Content-Type': 'multipart/form-data' },
  })
}

export const deleteMaterial = (requestId, materialId) =>
  client.post(`/exchanges/requests/${requestId}/materials/${materialId}/delete/`)
