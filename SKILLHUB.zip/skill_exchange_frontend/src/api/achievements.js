import client from './client'

export const listAchievements = (userId) =>
  client.get('/achievements/achievements/', { params: userId ? { user: userId } : {} })
