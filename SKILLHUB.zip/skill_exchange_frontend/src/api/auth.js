import client from './client'

export const login = (username, password) => client.post('/auth/login/', { username, password })

export const register = (payload) => client.post('/accounts/register/', payload)

export const getMe = () => client.get('/accounts/me/')

export const updateProfile = (payload) =>
  payload instanceof FormData
    ? client.patch('/accounts/profile/', payload, { headers: { 'Content-Type': 'multipart/form-data' } })
    : client.patch('/accounts/profile/', payload)

export const getPublicProfile = (userId) => client.get(`/accounts/users/${userId}/`)
