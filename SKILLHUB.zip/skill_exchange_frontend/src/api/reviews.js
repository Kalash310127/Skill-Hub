import client from './client'

export const listReviews = (userId) => client.get('/reviews/reviews/', { params: userId ? { user: userId } : {} })

export const createReview = (payload) => client.post('/reviews/reviews/', payload)

export const getRatingSummary = (userId) => client.get(`/reviews/summary/${userId}/`)
export const reportReview = (id, reason) => client.post(`/reviews/reviews/${id}/report/`, { reason })
