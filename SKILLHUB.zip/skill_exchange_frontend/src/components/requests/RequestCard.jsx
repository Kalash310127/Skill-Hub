import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { Video, Pencil, Clock, Lock } from 'lucide-react'
import { StatusStamp } from '../ui/Badge'

const JOIN_WINDOW_MINUTES = 5

export default function RequestCard({ request, perspective, onAction, onSetMeetLink, busy }) {
  const isReceived = perspective === 'received'
  const [editingLink, setEditingLink] = useState(false)
  const [linkInput, setLinkInput] = useState(request.meet_link || '')
  const [savingLink, setSavingLink] = useState(false)
  const [linkError, setLinkError] = useState('')

  // Ticks every 30s so the Join button flips on automatically once the
  // JOIN_WINDOW_MINUTES-before window opens, without needing a page refresh.
  const [now, setNow] = useState(() => new Date())
  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 30000)
    return () => clearInterval(id)
  }, [])

  const sessionAt = request.fixed_session_at ? new Date(request.fixed_session_at) : null
  const joinOpensAt = sessionAt ? new Date(sessionAt.getTime() - JOIN_WINDOW_MINUTES * 60000) : null
  // No fixed time set on the skill at all -> nothing to gate against, so
  // allow joining as soon as it's accepted (matches skills with no fixed slot).
  const canJoin = !sessionAt || now >= joinOpensAt

  const saveLink = async () => {
    setLinkError('')
    setSavingLink(true)
    try {
      await onSetMeetLink(request.id, linkInput.trim())
      setEditingLink(false)
    } catch (err) {
      setLinkError(err?.response?.data?.detail || 'Could not save that link.')
    } finally {
      setSavingLink(false)
    }
  }

  const minutesUntilOpen = joinOpensAt ? Math.max(0, Math.round((joinOpensAt - now) / 60000)) : 0

  return (
    <div className="ticket p-5">
      <div className="flex items-start justify-between gap-3">
        <span className="font-mono text-[11px] text-ink-400">#{String(request.id).padStart(4, '0')}</span>
        <StatusStamp status={request.status} />
      </div>

      <h3 className="font-display text-lg font-semibold mt-4">
        <Link to={`/skills/${request.skill}`} className="hover:underline">{request.skill_title}</Link>
      </h3>

      <p className="text-sm text-ink-600 mt-1">
        {isReceived ? (
          <>from <span className="font-semibold text-ink-800">@{request.requester_username}</span></>
        ) : (
          <>with <span className="font-semibold text-ink-800">@{request.teacher_username}</span></>
        )}
      </p>

      {request.message && (
        <p className="text-sm text-ink-700 mt-3 border-t border-ink-800/10 pt-3">
          "{request.message}"
        </p>
      )}
      {request.fixed_session_at && <p className="mt-3 text-xs text-ink-600 flex items-center gap-1"><Clock size={13} /> Fixed slot: {new Date(request.fixed_session_at).toLocaleString()}</p>}
      {request.is_waitlisted && <p className="mt-2 text-xs font-semibold text-amber-700">Waitlisted — this slot is currently full.</p>}

      {request.status === 'accepted' && !request.is_waitlisted && (
        <div className="mt-4 border-t border-ink-800/10 pt-3">
          {request.meet_link && !editingLink ? (
            <div className="flex items-center justify-between gap-2 flex-wrap">
              {canJoin ? (
                <Link
                  to={`/sessions/${request.id}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-amber !py-2 !px-3 !text-xs"
                >
                  <Video size={14} /> Join Jitsi meeting
                </Link>
              ) : (
                <span
                  className="btn-secondary !py-2 !px-3 !text-xs opacity-70 cursor-not-allowed"
                  title={`Opens at ${joinOpensAt.toLocaleTimeString()} (${JOIN_WINDOW_MINUTES} minutes before the session)`}
                >
                  <Lock size={14} /> Opens in {minutesUntilOpen} min
                </span>
              )}
              {isReceived && (
                <button
                  className="text-ink-400 hover:text-ink-800"
                  onClick={() => { setLinkInput(request.meet_link); setEditingLink(true) }}
                  aria-label="Edit meeting link"
                >
                  <Pencil size={14} />
                </button>
              )}
            </div>
          ) : isReceived ? (
            <div className="space-y-2">
              <label className="label !mb-1">Jitsi room link</label>
              <div className="flex gap-2">
                <input
                  className="input"
                  placeholder="https://meet.jit.si/your-room"
                  value={linkInput}
                  onChange={(e) => setLinkInput(e.target.value)}
                />
                <button className="btn-primary !py-2 !px-3 !text-xs shrink-0" disabled={savingLink} onClick={saveLink}>
                  {savingLink ? 'Saving…' : 'Save'}
                </button>
              </div>
              {linkError && <p className="text-clay-600 text-xs">{linkError}</p>}
              <p className="text-[11px] text-ink-400">
                Only you (the teacher) can set this link — the student will see a Join button once it's saved.
              </p>
            </div>
          ) : (
            <p className="text-xs text-ink-400">
              Waiting on the teacher to add the meeting link — you'll see a Join button here once it's ready.
            </p>
          )}
          {sessionAt && !canJoin && (
            <p className="text-[11px] text-ink-400 mt-2">
              The Join button unlocks automatically {JOIN_WINDOW_MINUTES} minutes before your session — no need to refresh.
            </p>
          )}
        </div>
      )}

      <div className="mt-4 flex flex-wrap gap-2">
        {isReceived && request.status === 'pending' && (
          <>
            <button className="btn-primary !py-2 !px-3 !text-xs" disabled={busy} onClick={() => onAction('accept', request.id)}>Accept</button>
            <button className="btn-danger !py-2 !px-3 !text-xs" disabled={busy} onClick={() => onAction('reject', request.id)}>Decline</button>
          </>
        )}
        {!isReceived && request.status === 'pending' && (
          <button className="btn-secondary !py-2 !px-3 !text-xs" disabled={busy} onClick={() => onAction('cancel', request.id)}>Cancel request</button>
        )}
        {request.status === 'accepted' && (
          <button className="btn-amber !py-2 !px-3 !text-xs" disabled={busy} onClick={() => onAction('complete', request.id)}>Mark complete</button>
        )}
        {!isReceived && request.status === 'completed' && (
          <button className="btn-secondary !py-2 !px-3 !text-xs" disabled={busy} onClick={() => onAction('review', request.id)}>
            {request.review ? 'View review' : 'Leave a review'}
          </button>
        )}
      </div>
    </div>
  )
}
