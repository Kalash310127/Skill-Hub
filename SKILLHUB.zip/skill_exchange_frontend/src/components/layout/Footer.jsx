export default function Footer() {
  return (
    <footer className="border-t border-ink-800/15 mt-24">
      <div className="max-w-6xl mx-auto px-5 py-10 flex flex-col md:flex-row items-center justify-between gap-3">
        <p className="font-display text-sm text-ink-600">SkillHub — trade code for code, not cash.</p>
        <p className="font-mono text-[11px] uppercase tracking-widest text-ink-400">
          No money changes hands here. Just know-how.
        </p>
      </div>
    </footer>
  )
}
