import { Link, NavLink, useNavigate } from 'react-router-dom'
import { ArrowLeftRight, LogOut, Menu, X } from 'lucide-react'
import { useState } from 'react'
import { useAuth } from '../../context/AuthContext'
import { useNotifications } from '../../context/NotificationsContext'
import SettingsMenu from './SettingsMenu'

const navLinkClass = ({ isActive }) =>
  `font-mono text-xs uppercase tracking-widest transition-colors ${
    isActive ? 'text-ink-900' : 'text-ink-400 hover:text-ink-800'
  }`

export default function Navbar() {
  const { user, logout } = useAuth()
  const { unreadCount } = useNotifications() ?? {}
  const navigate = useNavigate()
  const [open, setOpen] = useState(false)

  const handleLogout = () => {
    logout()
    setOpen(false)
    navigate('/')
  }

  return (
    <header className="sticky top-0 z-40 bg-parchment-50 border-b border-ink-800/15">
      <div className="w-full px-6 md:px-10 h-16 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2 group shrink-0" onClick={() => setOpen(false)}>
          <span
            className="h-8 w-8 rounded-xl text-white flex items-center justify-center rotate-[-6deg] group-hover:rotate-0 transition-transform"
            style={{ background: 'linear-gradient(135deg, #7C5CFC 0%, #FF6B5B 100%)' }}
          >
            <ArrowLeftRight size={16} />
          </span>
          <span className="font-display text-xl font-semibold tracking-tight">SkillHub</span>
        </Link>

        {/* Everything else lives in one right-aligned group, but split into
            two clearly separated clusters (nav links, then account controls)
            with a divider between them — so it reads as organized, not
            packed together. */}
        <div className="hidden md:flex items-center gap-6">
          <nav className="flex items-center gap-6">
            <NavLink to="/" className={navLinkClass} end>Browse</NavLink>
            {user && <NavLink to="/my-skills" className={navLinkClass}>Listings</NavLink>}
            {user && <NavLink to="/requests" className={navLinkClass}>Requests</NavLink>}
            {user && <NavLink to="/learning" className={navLinkClass}>Learning</NavLink>}
            {user && <NavLink to="/sharing" className={navLinkClass}>Sharing</NavLink>}
            {user && <NavLink to="/wishlist" className={navLinkClass}>Wishlist</NavLink>}
            {user && (
              <NavLink to="/notifications" className={navLinkClass}>
                <span className="relative inline-flex items-center">
                  Notification
                  {unreadCount > 0 && (
                    <span className="absolute -top-2 -right-3.5 min-w-[16px] h-4 px-1 rounded-full bg-clay-500 text-white text-[10px] font-sans font-semibold flex items-center justify-center leading-none">
                      {unreadCount > 99 ? '99+' : unreadCount}
                    </span>
                  )}
                </span>
              </NavLink>
            )}
            {user && <NavLink to="/profile" className={navLinkClass}>Profile</NavLink>}
          </nav>

          <span className="h-5 w-px bg-ink-800/15" />

          <div className="flex items-center gap-3">
            {user ? (
              <>
                <span className="font-mono text-xs text-ink-600">@{user.username}</span>
                <button onClick={handleLogout} className="btn-secondary !px-3 !py-1.5">
                  <LogOut size={14} /> Log out
                </button>
              </>
            ) : (
              <>
                <Link to="/login" className="btn-secondary !px-3 !py-1.5">Log in</Link>
                <Link to="/register" className="btn-primary !px-3 !py-1.5">Join</Link>
              </>
            )}
            <SettingsMenu />
          </div>
        </div>

        <div className="md:hidden flex items-center gap-1">
          <SettingsMenu />
          <button onClick={() => setOpen((o) => !o)} aria-label="Toggle menu">
            {open ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </div>

      {open && (
        <div className="md:hidden border-t border-ink-800/15 bg-parchment-50 px-5 py-4 flex flex-col gap-4">
          <NavLink to="/" className={navLinkClass} end onClick={() => setOpen(false)}>Browse</NavLink>
          {user && <NavLink to="/my-skills" className={navLinkClass} onClick={() => setOpen(false)}>Listings</NavLink>}
          {user && <NavLink to="/requests" className={navLinkClass} onClick={() => setOpen(false)}>Requests</NavLink>}
          {user && <NavLink to="/learning" className={navLinkClass} onClick={() => setOpen(false)}>Learning</NavLink>}
          {user && <NavLink to="/sharing" className={navLinkClass} onClick={() => setOpen(false)}>Sharing</NavLink>}
          {user && <NavLink to="/wishlist" className={navLinkClass} onClick={() => setOpen(false)}>Wishlist</NavLink>}
          {user && (
            <NavLink to="/notifications" className={navLinkClass} onClick={() => setOpen(false)}>
              <span className="relative inline-flex items-center">
                Notification
                {unreadCount > 0 && (
                  <span className="absolute -top-2 -right-3.5 min-w-[16px] h-4 px-1 rounded-full bg-clay-500 text-white text-[10px] font-sans font-semibold flex items-center justify-center leading-none">
                    {unreadCount > 99 ? '99+' : unreadCount}
                  </span>
                )}
              </span>
            </NavLink>
          )}
          {user && <NavLink to="/profile" className={navLinkClass} onClick={() => setOpen(false)}>Profile</NavLink>}
          <div className="pt-2 flex gap-3">
            {user ? (
              <button onClick={handleLogout} className="btn-secondary flex-1">Log out</button>
            ) : (
              <>
                <Link to="/login" className="btn-secondary flex-1" onClick={() => setOpen(false)}>Log in</Link>
                <Link to="/register" className="btn-primary flex-1" onClick={() => setOpen(false)}>Join</Link>
              </>
            )}
          </div>
        </div>
      )}
    </header>
  )
}
