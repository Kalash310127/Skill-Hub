import { useEffect, useRef, useState } from 'react'
import { Settings, Sun, Moon } from 'lucide-react'
import { useTheme } from '../../context/ThemeContext'

export default function SettingsMenu() {
  const { theme, toggleTheme } = useTheme()
  const [open, setOpen] = useState(false)
  const ref = useRef(null)

  useEffect(() => {
    const handleClick = (e) => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false)
    }
    document.addEventListener('mousedown', handleClick)
    return () => document.removeEventListener('mousedown', handleClick)
  }, [])

  return (
    <div className="relative" ref={ref}>
      <button
        onClick={() => setOpen((o) => !o)}
        aria-label="App settings"
        className="h-9 w-9 flex items-center justify-center rounded-full text-ink-600 hover:text-ink-900 hover:bg-ink-800/10 transition-colors"
      >
        <Settings size={18} />
      </button>

      {open && (
        <div className="absolute right-0 mt-2 w-60 ticket shadow-lift p-4 z-50">
          <p className="font-mono text-[11px] uppercase tracking-widest text-ink-400 mb-3">App settings</p>

          <div className="flex items-center justify-between">
            <span className="flex items-center gap-2 text-sm font-semibold text-ink-800">
              {theme === 'dark' ? <Moon size={15} /> : <Sun size={15} />}
              {theme === 'dark' ? 'Dark mode' : 'Light mode'}
            </span>
            <button
              role="switch"
              aria-checked={theme === 'dark'}
              onClick={toggleTheme}
              className="theme-switch"
              data-on={theme === 'dark'}
            >
              <span
                className="theme-switch-thumb"
                style={{ transform: theme === 'dark' ? 'translateX(22px)' : 'translateX(2px)' }}
              />
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
