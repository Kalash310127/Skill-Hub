import { PlayCircle } from 'lucide-react'
import Modal from '../ui/Modal'

const VIDEO_URL = import.meta.env.VITE_TUTORIAL_VIDEO_URL || ''

function isYouTube(url) {
  return /youtube\.com\/embed|youtu\.be/.test(url)
}

export default function TutorialModal({ onClose }) {
  return (
    <Modal title="Welcome to SkillHub" onClose={onClose}>
      <p className="text-sm text-ink-600 mb-4">
        Quick 90-second walkthrough of how the board works — posting a skill,
        sending a request, and getting matched up for a lesson.
      </p>

      <div className="aspect-video w-full bg-ink-900/5 border border-ink-800/15 rounded-xl overflow-hidden flex items-center justify-center">
        {VIDEO_URL ? (
          isYouTube(VIDEO_URL) ? (
            <iframe
              className="w-full h-full"
              src={VIDEO_URL}
              title="SkillHub walkthrough"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            />
          ) : (
            <video className="w-full h-full" src={VIDEO_URL} controls />
          )
        ) : (
          <div className="text-center px-6 py-10 text-ink-400">
            <PlayCircle size={32} className="mx-auto mb-2" />
            <p className="text-sm font-mono">
              No tutorial video set yet.
              <br />
              Add one via <code>VITE_TUTORIAL_VIDEO_URL</code> in your <code>.env</code>.
            </p>
          </div>
        )}
      </div>

      <button className="btn-primary w-full mt-5" onClick={onClose}>
        Got it, let's go
      </button>
    </Modal>
  )
}
