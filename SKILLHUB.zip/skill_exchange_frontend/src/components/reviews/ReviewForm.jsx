import { useState } from 'react'
import { Star } from 'lucide-react'
import ErrorNote from '../ui/ErrorNote'
import { formatError } from '../skills/SkillForm'

export default function ReviewForm({ onSubmit, onCancel }) {
  const [rating, setRating] = useState(5)
  const [comment, setComment] = useState('')
  const [error, setError] = useState('')
  const [saving, setSaving] = useState(false)

  const submit = async (e) => {
    e.preventDefault()
    setError('')
    setSaving(true)
    try {
      await onSubmit({ rating, comment })
    } catch (err) {
      setError(formatError(err))
    } finally {
      setSaving(false)
    }
  }

  return (
    <form onSubmit={submit} className="space-y-4">
      <ErrorNote>{error}</ErrorNote>
      <div>
        <label className="label">Rating</label>
        <div className="flex gap-1">
          {[1, 2, 3, 4, 5].map((n) => (
            <button type="button" key={n} onClick={() => setRating(n)} aria-label={`${n} stars`}>
              <Star size={26} className={n <= rating ? 'fill-amber-500 text-amber-500' : 'text-ink-800/20'} />
            </button>
          ))}
        </div>
      </div>
      <div>
        <label className="label">Comment</label>
        <textarea className="input min-h-[90px]" value={comment} onChange={(e) => setComment(e.target.value)} placeholder="How did the exchange go?" />
      </div>
      <div className="flex gap-3">
        <button type="submit" className="btn-primary" disabled={saving}>{saving ? 'Posting…' : 'Post review'}</button>
        <button type="button" onClick={onCancel} className="btn-secondary">Cancel</button>
      </div>
    </form>
  )
}
