import StarRating from '../ui/StarRating'
import { useState } from 'react'
import { reportReview } from '../../api/reviews'

export default function ReviewCard({ review }) {
  const [reported, setReported] = useState(false)
  const report = async () => {
    const reason = window.prompt('Why should this review be moderated?')
    if (!reason) return
    await reportReview(review.id, reason)
    setReported(true)
  }
  return (
    <div className="border-b border-ink-800/10 py-4 last:border-none">
      <div className="flex items-center justify-between">
        <span className="font-mono text-xs text-ink-600">@{review.reviewer_username}</span>
        <StarRating value={review.rating} size={13} />
      </div>
      {review.skill_title && (
        <p className="font-mono text-[11px] uppercase tracking-widest text-moss-600 mt-1">{review.skill_title}</p>
      )}
      {review.comment && <p className="text-sm text-ink-700 mt-2">{review.comment}</p>}
      <button onClick={report} disabled={reported} className="mt-3 text-[11px] font-mono text-ink-400 hover:text-clay-600">{reported ? 'Reported for moderation' : 'Report abuse'}</button>
    </div>
  )
}
