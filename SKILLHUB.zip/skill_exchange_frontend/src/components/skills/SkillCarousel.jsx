import { useEffect, useState } from 'react'
import { ChevronLeft, ChevronRight } from 'lucide-react'
import SkillCard from './SkillCard'

// How many cards are visible at once, based on viewport width — 1 on
// mobile, 2 from the sm breakpoint, 3 from lg — so the carousel reads as
// "a few pages" of cards rather than a single card floating alone.
function useItemsPerView() {
  const getValue = () => {
    if (typeof window === 'undefined') return 1
    if (window.innerWidth >= 1024) return 3
    if (window.innerWidth >= 640) return 2
    return 1
  }
  const [itemsPerView, setItemsPerView] = useState(getValue)
  useEffect(() => {
    const onResize = () => setItemsPerView(getValue())
    window.addEventListener('resize', onResize)
    return () => window.removeEventListener('resize', onResize)
  }, [])
  return itemsPerView
}

const AUTOPLAY_MS = 2500

/**
 * A carousel that shows 2-3 cards per "page" (responsive) but always
 * glides (slides) by exactly one card at a time. It loops continuously
 * in both directions (next from the last page wraps to the first, prev
 * from the first wraps to the last) and auto-advances on its own every
 * couple of seconds, pausing while the user is hovering over it.
 *
 * To make the wrap feel like a normal one-step glide (instead of
 * sweeping all the way back across every card), a clone of the last
 * page is placed before the real cards and a clone of the first page
 * after them. Wrapping animates into the clone, then snaps instantly
 * (no transition) to the matching real position once the glide ends —
 * invisible to the eye since the clone looks identical.
 */
export default function SkillCarousel({ skills, wishlistedIds, onToggleWishlist }) {
  const itemsPerView = useItemsPerView()
  const total = skills?.length ?? 0
  const maxIndex = Math.max(0, total - itemsPerView)
  const positions = maxIndex + 1 // number of distinct scroll positions
  const looping = positions > 1 && total > itemsPerView

  const [index, setIndex] = useState(0) // logical position, always within [0, positions-1]
  const [displayIndex, setDisplayIndex] = useState(0) // drives the transform; briefly -1 or `positions` mid-wrap
  const [transitionsOn, setTransitionsOn] = useState(true)
  const [paused, setPaused] = useState(false)

  // Keep the current position valid when the viewport (and therefore
  // itemsPerView/positions) changes, e.g. resizing from desktop to mobile.
  useEffect(() => {
    setTransitionsOn(false)
    setIndex((i) => i % positions)
    setDisplayIndex((i) => i % positions)
  }, [positions])

  const movePrev = () => {
    setTransitionsOn(true)
    if (looping && index === 0) {
      setDisplayIndex(-1) // glide left into the cloned last page
    } else {
      const n = Math.max(0, index - 1)
      setDisplayIndex(n)
      setIndex(n)
    }
  }

  const moveNext = () => {
    setTransitionsOn(true)
    if (looping && index === positions - 1) {
      setDisplayIndex(positions) // glide right into the cloned first page
    } else {
      const n = Math.min(positions - 1, index + 1)
      setDisplayIndex(n)
      setIndex(n)
    }
  }

  const jumpTo = (i) => {
    setTransitionsOn(true)
    setIndex(i)
    setDisplayIndex(i)
  }

  // Once the glide into a clone finishes, snap (no transition) to the
  // real position it's a clone of — this is the part that makes the
  // wrap invisible instead of jarring.
  const handleTransitionEnd = () => {
    if (!looping) return
    if (displayIndex === positions) {
      setTransitionsOn(false)
      setDisplayIndex(0)
      setIndex(0)
    } else if (displayIndex === -1) {
      setTransitionsOn(false)
      setDisplayIndex(positions - 1)
      setIndex(positions - 1)
    }
  }

  // Auto-advance — restarts on every index change so a manual click or
  // a wrap-correction doesn't get immediately overridden.
  useEffect(() => {
    if (positions <= 1 || paused) return
    const timer = setTimeout(moveNext, AUTOPLAY_MS)
    return () => clearTimeout(timer)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [index, positions, paused])

  if (!skills || skills.length === 0) return null

  const slideWidth = 100 / itemsPerView
  const renderSkills = looping
    ? [
        ...skills.slice(-itemsPerView).map((s) => ({ ...s, __key: `pre-${s.id}` })),
        ...skills.map((s) => ({ ...s, __key: `real-${s.id}` })),
        ...skills.slice(0, itemsPerView).map((s) => ({ ...s, __key: `post-${s.id}` })),
      ]
    : skills.map((s) => ({ ...s, __key: `real-${s.id}` }))
  const renderIndex = looping ? displayIndex + itemsPerView : displayIndex

  return (
    <div
      className="relative max-w-4xl mx-auto"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
    >
      <div className="overflow-hidden rounded-2xl">
        <div
          className={`flex ${transitionsOn ? 'transition-transform duration-500 ease-[cubic-bezier(0.22,1,0.36,1)]' : ''}`}
          style={{ transform: `translateX(-${renderIndex * slideWidth}%)` }}
          onTransitionEnd={handleTransitionEnd}
        >
          {renderSkills.map((skill) => (
            <div key={skill.__key} className="flex-shrink-0 px-2" style={{ width: `${slideWidth}%` }}>
              <SkillCard skill={skill} wishlisted={wishlistedIds?.has(skill.id)} onToggleWishlist={onToggleWishlist} />
            </div>
          ))}
        </div>
      </div>

      {positions > 1 && (
        <>
          <button
            aria-label="Previous"
            onClick={movePrev}
            className="absolute top-1/2 -left-4 -translate-y-1/2 h-9 w-9 rounded-full flex items-center justify-center text-white shadow-lift transition hover:brightness-110"
            style={{ background: 'linear-gradient(135deg, #7C5CFC 0%, #FF6B5B 100%)' }}
          >
            <ChevronLeft size={18} />
          </button>
          <button
            aria-label="Next"
            onClick={moveNext}
            className="absolute top-1/2 -right-4 -translate-y-1/2 h-9 w-9 rounded-full flex items-center justify-center text-white shadow-lift transition hover:brightness-110"
            style={{ background: 'linear-gradient(135deg, #7C5CFC 0%, #FF6B5B 100%)' }}
          >
            <ChevronRight size={18} />
          </button>

          <div className="flex justify-center gap-1.5 mt-4">
            {Array.from({ length: positions }).map((_, i) => (
              <button
                key={i}
                aria-label={`Go to position ${i + 1}`}
                onClick={() => jumpTo(i)}
                className={`h-1.5 rounded-full transition-all ${i === index ? 'w-6 bg-violet-600' : 'w-1.5 bg-ink-800/20'}`}
              />
            ))}
          </div>
        </>
      )}
    </div>
  )
}
