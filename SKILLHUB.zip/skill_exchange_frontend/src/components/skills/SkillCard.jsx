import { Link } from 'react-router-dom'
import { Clock, Heart, GraduationCap } from 'lucide-react'
import { LevelStamp } from '../ui/Badge'
import { categoryPillClasses } from '../../utils/categoryColor'
import { formatExperience } from '../../utils/experience'

export default function SkillCard({ skill, wishlisted = false, onToggleWishlist }) {
  const sessionAt = skill.fixed_session_at ? new Date(skill.fixed_session_at) : null
  const experience = formatExperience(skill.experience_months)

  const handleHeart = (e) => {
    e.preventDefault()   // don't navigate to the skill detail page
    e.stopPropagation()
    onToggleWishlist?.(skill)
  }

  return (
    <Link to={`/skills/${skill.id}`} className="ticket ticket-hover flex flex-col h-full p-5 hover:-translate-y-1 transition-transform relative">
      <div className="flex items-start justify-between gap-3">
        <span className="font-mono text-[11px] text-ink-400">#{String(skill.id).padStart(4, '0')}</span>
        <div className="flex items-center gap-2">
          <LevelStamp level={skill.level} />
          {onToggleWishlist && (
            <button
              type="button"
              onClick={handleHeart}
              aria-label={wishlisted ? 'Remove from wishlist' : 'Add to wishlist'}
              className="h-7 w-7 -mr-1 -mt-1 flex items-center justify-center rounded-full hover:bg-ink-800/5 transition-colors"
            >
              <Heart
                size={17}
                className={wishlisted ? 'fill-rose-500 text-rose-500 transition-transform scale-110' : 'text-ink-400 hover:text-rose-400 transition-colors'}
              />
            </button>
          )}
        </div>
      </div>
      <h3 className="font-display text-lg font-semibold mt-4 leading-snug">{skill.title}</h3>
      {experience && (
        <p className="mt-1.5 text-[11px] font-mono text-ink-600 flex items-center gap-1">
          <GraduationCap size={12} />
          {experience} experience
        </p>
      )}
      {sessionAt && (
        <p className="mt-1.5 text-[11px] font-mono text-violet-600 flex items-center gap-1">
          <Clock size={12} />
          {sessionAt.toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' })} · {sessionAt.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' })}
        </p>
      )}
      <p className="text-sm text-ink-600 mt-2 line-clamp-3 flex-1">
        {skill.description || 'No description provided yet.'}
      </p>
      {skill.tags?.length > 0 && <p className="mt-3 text-[11px] text-violet-600">{skill.tags.map((tag) => `#${tag.name}`).join('  ')}</p>}
      <div className="mt-5 pt-3 flex items-center justify-between border-t border-ink-800/10">
        <span className="text-xs text-ink-600">taught by <span className="font-semibold text-ink-800">@{skill.username}</span></span>
        {skill.category_name && (
          <span className={`text-[11px] font-semibold px-2.5 py-1 rounded-full ${categoryPillClasses(skill.category_name)}`}>
            {skill.category_name}
          </span>
        )}
      </div>
    </Link>
  )
}
