import { useEffect, useRef, useState } from 'react'
import ErrorNote from '../ui/ErrorNote'
import { suggestSkillTags } from '../../api/skills'

const LEVELS = ['beginner', 'intermediate', 'advanced']

export default function SkillForm({ initial, onSubmit, onCancel, submitLabel = 'Post listing' }) {
  const initialExperience = initial?.experience_months || 0
  const [form, setForm] = useState({
    title: initial?.title || '',
    description: initial?.description || '',
    level: initial?.level || 'beginner',
    category_input: initial?.category_name || '',
    tag_input: initial?.tags?.map((tag) => tag.name).join(', ') || '',
    fixed_session_at: initial?.fixed_session_at ? initial.fixed_session_at.slice(0, 16) : '',
    capacity: initial?.capacity || 1,
    experience_years: Math.floor(initialExperience / 12),
    experience_months: initialExperience % 12,
  })
  const [error, setError] = useState('')
  const [saving, setSaving] = useState(false)
  const [suggestion, setSuggestion] = useState(null)
  const debounceRef = useRef(null)

  const change = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.value }))

  // Auto-suggest a Category + Tags as the teacher types the title/description,
  // debounced so it doesn't fire on every keystroke. Only offered while
  // creating a listing (not editing an existing one) and only while the
  // teacher hasn't already filled those fields in themselves.
  useEffect(() => {
    if (initial) return
    if (form.category_input.trim() || form.tag_input.trim()) {
      setSuggestion(null)
      return
    }
    if (!form.title.trim() && !form.description.trim()) {
      setSuggestion(null)
      return
    }
    if (debounceRef.current) clearTimeout(debounceRef.current)
    debounceRef.current = setTimeout(() => {
      suggestSkillTags({ title: form.title, description: form.description })
        .then(({ data }) => {
          if (data.category || (data.tags && data.tags.length)) setSuggestion(data)
          else setSuggestion(null)
        })
        .catch(() => setSuggestion(null))
    }, 500)
    return () => clearTimeout(debounceRef.current)
  }, [form.title, form.description])

  const applySuggestion = () => {
    if (!suggestion) return
    setForm((f) => ({
      ...f,
      category_input: suggestion.category || f.category_input,
      tag_input: suggestion.tags && suggestion.tags.length ? suggestion.tags.join(', ') : f.tag_input,
    }))
    setSuggestion(null)
  }

  const submit = async (e) => {
    e.preventDefault()
    setError('')
    setSaving(true)
    try {
      const years = Math.max(0, Number(form.experience_years) || 0)
      const months = Math.max(0, Math.min(11, Number(form.experience_months) || 0))
      const { experience_years, ...rest } = form
      await onSubmit({
        ...rest,
        tag_input: form.tag_input.split(',').map((tag) => tag.trim()).filter(Boolean),
        fixed_session_at: form.fixed_session_at || null,
        capacity: Math.min(10, Math.max(1, Number(form.capacity) || 1)),
        experience_months: years * 12 + months,
      })
    } catch (err) {
      setError(formatError(err))
    } finally {
      setSaving(false)
    }
  }

  return (
    <form onSubmit={submit} className="space-y-4">
      <ErrorNote>{error}</ErrorNote>
      <div>
        <label className="label">Skill title</label>
        <input className="input" required maxLength={120} value={form.title} onChange={change('title')} placeholder="e.g. React state management with hooks" />
      </div>
      <div>
        <label className="label">Description</label>
        <textarea className="input min-h-[110px]" value={form.description} onChange={change('description')} placeholder="What will someone actually learn from you?" />
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="label">Level</label>
          <select className="input" value={form.level} onChange={change('level')}>
            {LEVELS.map((l) => (
              <option key={l} value={l}>{l[0].toUpperCase() + l.slice(1)}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="label">Category</label>
          <input className="input" value={form.category_input} onChange={change('category_input')} placeholder="e.g. Backend, Database, DevOps" />
        </div>
      </div>
      <div>
        <label className="label">Tags (comma-separated)</label>
        <input className="input" value={form.tag_input} onChange={change('tag_input')} placeholder="e.g. creative, remote-friendly" />
      </div>
      {suggestion && (
        <button
          type="button"
          onClick={applySuggestion}
          className="text-xs font-mono text-amber-700 bg-amber-50 border border-amber-200 rounded px-3 py-2 text-left hover:bg-amber-100 transition"
        >
          Suggested{suggestion.category ? ` category: ${suggestion.category}` : ''}
          {suggestion.tags?.length ? `${suggestion.category ? ' ·' : ''} tags: ${suggestion.tags.join(', ')}` : ''}
          {' '}— tap to apply
        </button>
      )}
      <div>
        <label className="label">Your experience with this skill</label>
        <div className="grid grid-cols-2 gap-4">
          <div className="flex items-center gap-2">
            <input
              className="input"
              type="number"
              min="0"
              max="100"
              value={form.experience_years}
              onChange={change('experience_years')}
            />
            <span className="text-xs text-ink-600 shrink-0">years</span>
          </div>
          <div className="flex items-center gap-2">
            <input
              className="input"
              type="number"
              min="0"
              max="11"
              value={form.experience_months}
              onChange={change('experience_months')}
            />
            <span className="text-xs text-ink-600 shrink-0">months</span>
          </div>
        </div>
        <p className="text-[11px] text-ink-400 mt-1">
          How long you've personally practiced this — shown on your listing so learners know who they're learning from.
        </p>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div><label className="label">Fixed session time (optional)</label><input className="input" type="datetime-local" value={form.fixed_session_at} onChange={change('fixed_session_at')} /></div>
        <div>
          <label className="label">Seats in this slot (max 10)</label>
          <input
            className="input"
            type="number"
            min="1"
            max="10"
            value={form.capacity}
            disabled={initial?.capacity_locked}
            onChange={change('capacity')}
          />
          {initial?.capacity_locked && (
            <p className="text-[11px] text-ink-400 mt-1">
              Locked — learners have already requested this session. Unlocks once every request is completed, rejected, or cancelled.
            </p>
          )}
        </div>
      </div>
      <div className="flex gap-3 pt-2">
        <button type="submit" className="btn-primary" disabled={saving}>{saving ? 'Saving…' : submitLabel}</button>
        {onCancel && <button type="button" onClick={onCancel} className="btn-secondary">Cancel</button>}
      </div>
    </form>
  )
}

export function formatError(err) {
  const data = err?.response?.data
  if (!data) return 'Something went wrong. Please try again.'
  if (typeof data === 'string') return data
  if (data.detail) return data.detail
  const first = Object.values(data)[0]
  return Array.isArray(first) ? first[0] : String(first)
}
