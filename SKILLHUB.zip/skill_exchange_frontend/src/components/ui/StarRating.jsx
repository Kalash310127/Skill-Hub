import { Star } from 'lucide-react'

export default function StarRating({ value = 0, count, size = 15 }) {
  const rounded = Math.round(value)
  return (
    <span className="inline-flex items-center gap-1">
      <span className="inline-flex">
        {[1, 2, 3, 4, 5].map((n) => (
          <Star
            key={n}
            size={size}
            className={n <= rounded ? 'fill-amber-500 text-amber-500' : 'text-ink-800/20'}
          />
        ))}
      </span>
      {value ? (
        <span className="font-mono text-xs text-ink-600">
          {value.toFixed(1)}
          {typeof count === 'number' ? ` (${count})` : ''}
        </span>
      ) : (
        <span className="font-mono text-xs text-ink-400">no ratings yet</span>
      )}
    </span>
  )
}
