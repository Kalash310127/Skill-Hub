export default function ErrorNote({ children }) {
  if (!children) return null
  return (
    <div className="border border-clay-500/40 bg-clay-500/5 text-clay-600 font-body text-sm px-4 py-3 rounded-xl">
      {children}
    </div>
  )
}
