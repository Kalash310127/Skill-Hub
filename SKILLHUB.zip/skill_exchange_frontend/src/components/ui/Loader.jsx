export default function Loader({ label = 'Loading' }) {
  return (
    <div className="flex items-center justify-center gap-3 py-16 text-ink-600">
      <span className="h-3 w-3 rounded-full bg-clay-500 animate-ping" />
      <span className="font-mono text-xs uppercase tracking-widest">{label}…</span>
    </div>
  )
}
