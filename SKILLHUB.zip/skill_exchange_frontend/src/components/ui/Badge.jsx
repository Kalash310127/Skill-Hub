const LEVEL_STYLES = {
  beginner: 'bg-moss-100 text-moss-700',
  intermediate: 'bg-amber-100 text-amber-700',
  advanced: 'bg-clay-100 text-clay-700',
}

export function LevelStamp({ level }) {
  return (
    <span className={`stamp ${LEVEL_STYLES[level] || 'bg-ink-800/10 text-ink-700'}`}>
      {level}
    </span>
  )
}

const STATUS_STYLES = {
  pending: 'bg-amber-100 text-amber-700',
  accepted: 'bg-moss-100 text-moss-700',
  rejected: 'bg-clay-100 text-clay-700',
  cancelled: 'bg-ink-800/10 text-ink-400',
  completed: 'bg-plum-100 text-plum-700',
}

export function StatusStamp({ status }) {
  return (
    <span className={`stamp ${STATUS_STYLES[status] || 'bg-ink-800/10 text-ink-700'}`}>
      {status}
    </span>
  )
}
