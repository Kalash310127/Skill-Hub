import { X } from 'lucide-react'

export default function Modal({ title, onClose, children }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center px-4">
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={onClose} />
      <div className="relative ticket w-full max-w-lg p-6 pt-5 max-h-[90vh] overflow-y-auto">
        <div className="flex items-start justify-between mb-5">
          <h2 className="font-display text-xl font-semibold pr-6">{title}</h2>
          <button onClick={onClose} aria-label="Close" className="text-ink-600 hover:text-ink-900">
            <X size={20} />
          </button>
        </div>
        {children}
      </div>
    </div>
  )
}
