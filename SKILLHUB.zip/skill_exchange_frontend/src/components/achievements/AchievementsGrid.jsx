import { useState } from 'react'
import { Link } from 'react-router-dom'
import { Award, Calendar, GraduationCap } from 'lucide-react'
import Modal from '../ui/Modal'
import { LevelStamp, StatusStamp } from '../ui/Badge'

export default function AchievementsGrid({ achievements, heading = "Skills you've learned" }) {
  const [selected, setSelected] = useState(null)

  if (!achievements?.length) return null

  return (
    <div className="mt-10">
      <h2 className="font-display text-xl font-semibold mb-4 flex items-center gap-2">
        <Award size={18} className="text-amber-600" /> {heading}
      </h2>
      <div className="flex flex-wrap gap-2">
        {achievements.map((a) => (
          <button
            key={a.id}
            onClick={() => setSelected(a)}
            className="stamp border-moss-500 text-moss-600 hover:bg-moss-50 transition-colors cursor-pointer"
          >
            {a.title}
          </button>
        ))}
      </div>

      {selected && (
        <Modal title={selected.title} onClose={() => setSelected(null)}>
          <div className="space-y-3 text-sm">
            <div className="flex items-center gap-2">
              <span className="text-ink-600">Status:</span>
              <StatusStamp status="completed" />
            </div>
            {selected.level && (
              <div className="flex items-center gap-2">
                <GraduationCap size={15} className="text-ink-400" />
                <span className="text-ink-600">Level:</span>
                <LevelStamp level={selected.level} />
              </div>
            )}
            {selected.taught_by && (
              <div className="flex items-center gap-2">
                <Award size={15} className="text-ink-400" />
                <span className="text-ink-600">Taught by:</span>
                <Link to={`/users/${selected.taught_by_id ?? ''}`} className="font-semibold text-ink-900 hover:underline">
                  @{selected.taught_by}
                </Link>
              </div>
            )}
            <div className="flex items-center gap-2">
              <Calendar size={15} className="text-ink-400" />
              <span className="text-ink-600">Earned:</span>
              <span className="text-ink-800">{new Date(selected.earned_at).toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' })}</span>
            </div>
            {selected.skill_id && (
              <Link
                to={`/skills/${selected.skill_id}`}
                onClick={() => setSelected(null)}
                className="btn-secondary w-full mt-2 !py-2 !text-xs justify-center"
              >
                View this listing
              </Link>
            )}
          </div>
        </Modal>
      )}
    </div>
  )
}
