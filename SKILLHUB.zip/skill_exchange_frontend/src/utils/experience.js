// Formats a raw months count (as stored on the Skill model) into a short,
// human-friendly string — e.g. 0 -> null, 6 -> "6 mo", 12 -> "1 yr",
// 18 -> "1 yr 6 mo", 24 -> "2 yrs".
export function formatExperience(months) {
  const total = Number(months) || 0
  if (total <= 0) return null

  const years = Math.floor(total / 12)
  const remMonths = total % 12

  const parts = []
  if (years > 0) parts.push(`${years} yr${years === 1 ? '' : 's'}`)
  if (remMonths > 0) parts.push(`${remMonths} mo`)
  return parts.join(' ')
}
