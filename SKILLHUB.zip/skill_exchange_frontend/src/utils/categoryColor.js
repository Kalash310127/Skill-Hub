// Deterministically assigns one of five accent colors to a category name,
// so the board reads like a wall of different colored tags instead of a
// single flat color repeated on every card.
const PALETTE = [
  'bg-amber-100 text-amber-700',
  'bg-moss-100 text-moss-700',
  'bg-clay-100 text-clay-700',
  'bg-teal-100 text-teal-700',
  'bg-plum-100 text-plum-700',
]

export function categoryPillClasses(name = '') {
  if (!name) return 'bg-ink-800/10 text-ink-600'
  let hash = 0
  for (let i = 0; i < name.length; i++) {
    hash = (hash * 31 + name.charCodeAt(i)) >>> 0
  }
  return PALETTE[hash % PALETTE.length]
}
