import { useEffect, useState } from 'react'
import { Route, Routes } from 'react-router-dom'
import Navbar from './components/layout/Navbar'
import Footer from './components/layout/Footer'
import ProtectedRoute from './components/layout/ProtectedRoute'
import TutorialModal from './components/onboarding/TutorialModal'
import { useAuth } from './context/AuthContext'

import Home from './pages/Home'
import Login from './pages/Login'
import Register from './pages/Register'
import SkillDetail from './pages/SkillDetail'
import MySkills from './pages/MySkills'
import Requests from './pages/Requests'
import Profile from './pages/Profile'
import EditProfile from './pages/EditProfile'
import PublicProfile from './pages/PublicProfile'
import NotFound from './pages/NotFound'
import Wishlist from './pages/Wishlist'
import Learning from './pages/Learning'
import Sharing from './pages/Sharing'
import SharingDetail from './pages/SharingDetail'
import JitsiSession from './pages/JitsiSession'
import Notifications from './pages/Notifications'

const tutorialKey = (userId) => `se_tutorial_seen_${userId}`

export default function App() {
  const { user } = useAuth()
  const [showTutorial, setShowTutorial] = useState(false)

  useEffect(() => {
    if (user && !localStorage.getItem(tutorialKey(user.id))) {
      setShowTutorial(true)
    }
  }, [user])

  const dismissTutorial = () => {
    if (user) localStorage.setItem(tutorialKey(user.id), 'true')
    setShowTutorial(false)
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-1">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/skills/:id" element={<SkillDetail />} />
          <Route path="/users/:id" element={<PublicProfile />} />
          <Route path="/my-skills" element={<ProtectedRoute><MySkills /></ProtectedRoute>} />
          <Route path="/requests" element={<ProtectedRoute><Requests /></ProtectedRoute>} />
          <Route path="/wishlist" element={<ProtectedRoute><Wishlist /></ProtectedRoute>} />
          <Route path="/learning" element={<ProtectedRoute><Learning /></ProtectedRoute>} />
          <Route path="/sharing" element={<ProtectedRoute><Sharing /></ProtectedRoute>} />
          <Route path="/sharing/:id" element={<ProtectedRoute><SharingDetail /></ProtectedRoute>} />
          <Route path="/sessions/:id" element={<ProtectedRoute><JitsiSession /></ProtectedRoute>} />
          <Route path="/notifications" element={<ProtectedRoute><Notifications /></ProtectedRoute>} />
          <Route path="/profile" element={<ProtectedRoute><Profile /></ProtectedRoute>} />
          <Route path="/profile/edit" element={<ProtectedRoute><EditProfile /></ProtectedRoute>} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>
      <Footer />
      {showTutorial && <TutorialModal onClose={dismissTutorial} />}
    </div>
  )
}
