import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { updateProfile } from '../api/auth'
import { useAuth } from '../context/AuthContext'
import ErrorNote from '../components/ui/ErrorNote'
import { formatError } from '../components/skills/SkillForm'

export default function EditProfile() {
  const { user, refreshUser } = useAuth()
  const navigate = useNavigate()
  const [form, setForm] = useState({
    first_name: user?.first_name || '',
    last_name: user?.last_name || '',
    bio: user?.profile?.bio || '',
    location: user?.profile?.location || '',
  })
  const [photoFile, setPhotoFile] = useState(null)
  const [photoPreview, setPhotoPreview] = useState(user?.profile?.profile_picture || '')
  const [error, setError] = useState('')
  const [saving, setSaving] = useState(false)

  const change = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.value }))

  const pickPhoto = (e) => {
    const file = e.target.files?.[0]
    if (!file) return
    setPhotoFile(file)
    setPhotoPreview(URL.createObjectURL(file))
  }

  const submit = async (e) => {
    e.preventDefault()
    setError('')
    setSaving(true)
    try {
      const data = new FormData()
      Object.entries(form).forEach(([key, value]) => data.append(key, value))
      if (photoFile) data.append('profile_picture', photoFile)
      await updateProfile(data)
      await refreshUser()
      navigate('/profile')
    } catch (err) {
      setError(formatError(err))
    } finally {
      setSaving(false)
    }
  }

  const initials = `${form.first_name?.[0] || user?.username?.[0] || '?'}${form.last_name?.[0] || ''}`.toUpperCase()

  return (
    <div className="max-w-md mx-auto px-5 py-14">
      <p className="font-mono text-xs uppercase tracking-widest text-amber-600 mb-2">Update your card</p>
      <h1 className="font-display text-3xl font-semibold mb-8">Edit profile</h1>
      <form onSubmit={submit} className="ticket p-6 pt-5 space-y-4">
        <ErrorNote>{error}</ErrorNote>

        <div className="flex items-center gap-4">
          {photoPreview ? (
            <img src={photoPreview} alt="Profile" className="h-16 w-16 rounded-full object-cover shrink-0" />
          ) : (
            <div className="h-16 w-16 rounded-full shrink-0 flex items-center justify-center text-white font-display text-lg font-semibold"
                 style={{ background: 'linear-gradient(135deg, #7C5CFC 0%, #FF6B5B 100%)' }}>
              {initials}
            </div>
          )}
          <div>
            <label className="label !mb-1">Profile photo</label>
            <input
              type="file" accept="image/*"
              className="input !py-1.5 file:mr-3 file:py-1 file:px-2 file:rounded-md file:border-0 file:bg-violet-100 file:text-violet-700 file:text-xs"
              onChange={pickPhoto}
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="label">First name</label>
            <input className="input" value={form.first_name} onChange={change('first_name')} />
          </div>
          <div>
            <label className="label">Last name</label>
            <input className="input" value={form.last_name} onChange={change('last_name')} />
          </div>
        </div>
        <div>
          <label className="label">Bio</label>
          <textarea className="input min-h-[100px]" value={form.bio} onChange={change('bio')} placeholder="What should the board know about you?" />
        </div>
        <div>
          <label className="label">Location</label>
          <input className="input" value={form.location} onChange={change('location')} placeholder="e.g. Ahmedabad, IN" />
        </div>
        <div className="flex gap-3 pt-2">
          <button className="btn-primary" disabled={saving}>{saving ? 'Saving…' : 'Save changes'}</button>
          <button type="button" className="btn-secondary" onClick={() => navigate('/profile')}>Cancel</button>
        </div>
      </form>
    </div>
  )
}
