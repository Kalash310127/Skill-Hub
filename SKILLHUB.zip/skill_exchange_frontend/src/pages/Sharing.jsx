import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { FolderOpen, Lock } from 'lucide-react'
import { listRequests } from '../api/exchanges'
import { useAuth } from '../context/AuthContext'
import { LevelStamp } from '../components/ui/Badge'
import Loader from '../components/ui/Loader'
import ErrorNote from '../components/ui/ErrorNote'

const SHAREABLE_STATUSES = ['accepted', 'completed']

function SkillTicket({ request, isTeacher }) {
  const sessionAt = request.fixed_session_at ? new Date(request.fixed_session_at) : null
  const lectureCount = new Set((request.materials || []).map((m) => m.lecture_number)).size
  const withPerson = isTeacher ? request.requester_username : request.teacher_username

  return (
    <Link
      to={`/sharing/${request.id}`}
      className="ticket ticket-hover text-left p-5 flex flex-col hover:-translate-y-1 transition-transform"
    >
      <div className="flex items-start justify-between gap-3">
        <span className="font-mono text-[11px] text-ink-400">#{String(request.id).padStart(4, '0')}</span>
        <LevelStamp level={request.skill_level} />
      </div>
      <h3 className="font-display text-lg font-semibold mt-4 leading-snug">{request.skill_title}</h3>
      <p className="text-xs text-ink-600 mt-1">
        {isTeacher ? 'learner' : 'taught by'} <span className="font-semibold text-ink-800">@{withPerson}</span>
      </p>
      {sessionAt && (
        <p className="mt-2 text-[11px] font-mono text-violet-600">
          {sessionAt.toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' })} · {sessionAt.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' })}
        </p>
      )}
      <div className="mt-5 pt-3 border-t border-ink-800/10 flex items-center justify-between">
        {request.materials_unlocked ? (
          <span className="text-xs text-ink-600 flex items-center gap-1.5">
            <FolderOpen size={14} />
            {lectureCount > 0 ? `${lectureCount} lecture${lectureCount === 1 ? '' : 's'} shared` : (isTeacher ? 'Nothing uploaded yet' : 'Nothing shared yet')}
          </span>
        ) : (
          <span className="text-xs text-ink-400 flex items-center gap-1.5">
            <Lock size={13} /> Unlocks after the session
          </span>
        )}
      </div>
    </Link>
  )
}

export default function Sharing() {
  const { user } = useAuth()
  const [requests, setRequests] = useState([])
  const [tab, setTab] = useState('received')
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    if (!user) return
    setLoading(true)
    listRequests()
      .then(({ data }) => setRequests(data.results ?? data))
      .catch(() => setError('Could not load your shared materials.'))
      .finally(() => setLoading(false))
  }, [user])

  const sent = requests.filter((r) => r.teacher_username === user?.username && SHAREABLE_STATUSES.includes(r.status))
  const received = requests.filter((r) => r.requester_username === user?.username && SHAREABLE_STATUSES.includes(r.status))
  const list = tab === 'received' ? received : sent

  return (
    <div className="max-w-4xl mx-auto px-5 py-14">
      <p className="font-mono text-xs uppercase tracking-widest text-amber-600 mb-2">Sharing</p>
      <h1 className="font-display text-3xl font-semibold mb-8">Session materials</h1>

      <div className="flex gap-2 mb-8 border-b border-ink-800/15">
        {['received', 'sent'].map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`font-mono text-xs uppercase tracking-widest px-4 py-3 border-b-2 -mb-px transition-colors ${
              tab === t ? 'border-ink-800 text-ink-900' : 'border-transparent text-ink-400 hover:text-ink-700'
            }`}
          >
            {t} ({t === 'received' ? received.length : sent.length})
          </button>
        ))}
      </div>

      {error && <ErrorNote>{error}</ErrorNote>}
      {loading ? (
        <Loader label="Gathering your materials" />
      ) : list.length === 0 ? (
        <p className="text-ink-600 font-display text-lg py-10">
          {tab === 'received'
            ? "Nothing here yet — once a teacher shares files for a session you've joined, they'll show up here."
            : "You don't have any accepted sessions to share materials for yet."}
        </p>
      ) : (
        <div className="grid sm:grid-cols-2 gap-5">
          {list.map((req) => (
            <SkillTicket key={req.id} request={req} isTeacher={tab === 'sent'} />
          ))}
        </div>
      )}
    </div>
  )
}
