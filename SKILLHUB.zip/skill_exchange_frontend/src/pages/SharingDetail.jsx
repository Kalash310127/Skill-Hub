import { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { ArrowLeft, Upload, Download, Lock, FileArchive, Trash2 } from 'lucide-react'
import { getRequest, uploadMaterial, deleteMaterial } from '../api/exchanges'
import { useAuth } from '../context/AuthContext'
import { LevelStamp } from '../components/ui/Badge'
import Loader from '../components/ui/Loader'
import ErrorNote from '../components/ui/ErrorNote'

function nextLectureNumber(materials = []) {
  return materials.reduce((max, m) => Math.max(max, m.lecture_number), 0) + 1
}

function fileName(url) {
  try {
    return decodeURIComponent(url.split('/').pop().split('?')[0])
  } catch {
    return url
  }
}

export default function SharingDetail() {
  const { id } = useParams()
  const { user } = useAuth()
  const [request, setRequest] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  const [file, setFile] = useState(null)
  const [lecture, setLecture] = useState(1)
  const [note, setNote] = useState('')
  const [uploading, setUploading] = useState(false)
  const [deletingId, setDeletingId] = useState(null)

  const load = () => {
    setLoading(true)
    getRequest(id)
      .then(({ data }) => {
        setRequest(data)
        setLecture(nextLectureNumber(data.materials))
      })
      .catch(() => setError('Could not load this session.'))
      .finally(() => setLoading(false))
  }

  useEffect(() => { load() }, [id])

  if (loading) return <div className="max-w-5xl mx-auto px-5 py-14"><Loader label="Loading materials" /></div>
  if (error || !request) return <div className="max-w-5xl mx-auto px-5 py-14"><ErrorNote>{error || 'Session not found.'}</ErrorNote></div>

  const isTeacher = request.teacher_username === user?.username
  const sessionAt = request.fixed_session_at ? new Date(request.fixed_session_at) : null

  // Grouped by lecture (newest lecture first), each group's uploads newest
  // version first — this is what lets several zips share one lecture number
  // without the table repeating "Lecture N" on every single row.
  const lectureGroups = Object.values(
    request.materials.reduce((acc, m) => {
      if (!acc[m.lecture_number]) acc[m.lecture_number] = { lecture: m.lecture_number, items: [] }
      acc[m.lecture_number].items.push(m)
      return acc
    }, {})
  )
    .sort((a, b) => b.lecture - a.lecture)
    .map((g) => ({ ...g, items: [...g.items].sort((a, b) => b.version - a.version) }))

  const submitUpload = async (e) => {
    e.preventDefault()
    if (!file) return
    setError('')
    setUploading(true)
    try {
      const { data } = await uploadMaterial(request.id, file, { lectureNumber: lecture, note })
      setRequest(data)
      setLecture(nextLectureNumber(data.materials))
      setFile(null)
      setNote('')
    } catch (err) {
      setError(err?.response?.data?.detail || 'Could not upload that file.')
    } finally {
      setUploading(false)
    }
  }

  const handleDelete = async (materialId) => {
    if (!confirm('Remove this file? This cannot be undone.')) return
    setError('')
    setDeletingId(materialId)
    try {
      const { data } = await deleteMaterial(request.id, materialId)
      setRequest(data)
    } catch (err) {
      setError(err?.response?.data?.detail || 'Could not remove that file.')
    } finally {
      setDeletingId(null)
    }
  }

  return (
    <div className="max-w-5xl mx-auto px-5 py-14">
      <Link to="/sharing" className="text-xs text-ink-500 hover:text-ink-800 flex items-center gap-1 mb-6">
        <ArrowLeft size={14} /> Back to Sharing
      </Link>

      <div className="flex items-start justify-between gap-4 flex-wrap mb-2">
        <h1 className="font-display text-3xl font-semibold">{request.skill_title}</h1>
        <LevelStamp level={request.skill_level} />
      </div>
      <p className="text-sm text-ink-600 mb-1">
        {isTeacher ? `Learner: @${request.requester_username}` : `Taught by @${request.teacher_username}`}
      </p>
      {sessionAt && (
        <p className="text-xs font-mono text-violet-600 mb-8">
          Session: {sessionAt.toLocaleDateString(undefined, { weekday: 'long', month: 'short', day: 'numeric' })} · {sessionAt.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' })}
        </p>
      )}
      {!sessionAt && <div className="mb-8" />}

      {error && <ErrorNote>{error}</ErrorNote>}

      {isTeacher && (
        request.materials_unlocked ? (
          <form onSubmit={submitUpload} className="mb-8 p-4 rounded-xl bg-parchment-100 flex flex-wrap items-end gap-3">
            <div className="w-28">
              <label className="label !mb-1 !text-[10px]">Lecture no.</label>
              <input type="number" min="1" className="input" value={lecture} onChange={(e) => setLecture(e.target.value)} />
            </div>
            <div className="flex-1 min-w-[180px]">
              <label className="label !mb-1 !text-[10px]">Zip file</label>
              <input
                type="file" accept=".zip"
                className="input !py-1.5 file:mr-3 file:py-1 file:px-2 file:rounded-md file:border-0 file:bg-violet-100 file:text-violet-700 file:text-xs"
                onChange={(e) => setFile(e.target.files?.[0] || null)}
              />
            </div>
            <div className="flex-1 min-w-[180px]">
              <label className="label !mb-1 !text-[10px]">Note (optional)</label>
              <input className="input" placeholder="e.g. Slides + practice files" value={note} onChange={(e) => setNote(e.target.value)} />
            </div>
            <button className="btn-primary !py-2 !px-3 !text-xs shrink-0" disabled={!file || uploading}>
              <Upload size={14} /> {uploading ? 'Uploading…' : 'Upload'}
            </button>
          </form>
        ) : (
          <p className="mb-8 text-xs text-ink-500 flex items-center gap-1.5">
            <Lock size={13} /> Uploading unlocks once the session's scheduled time has passed.
          </p>
        )
      )}

      {lectureGroups.length === 0 ? (
        <p className="text-ink-500 text-sm py-10 text-center border border-dashed border-ink-800/15 rounded-xl">
          {isTeacher ? "You haven't shared anything for this session yet." : 'Nothing has been shared here yet.'}
        </p>
      ) : (
        <div className="overflow-x-auto rounded-xl border border-ink-800/10">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-parchment-100 text-left text-[11px] uppercase tracking-widest text-ink-500">
                <th className="px-4 py-3 font-medium">Lecture</th>
                <th className="px-4 py-3 font-medium">File</th>
                <th className="px-4 py-3 font-medium">Version</th>
                <th className="px-4 py-3 font-medium">Date</th>
                <th className="px-4 py-3 font-medium text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {lectureGroups.map(({ lecture, items }) => (
                items.map((m, i) => (
                  <tr key={m.id} className={`border-t border-ink-800/10 ${i > 0 ? 'bg-parchment-50/50' : ''}`}>
                    {i === 0 && (
                      <td className="px-4 py-3 font-mono text-xs text-ink-700 align-top" rowSpan={items.length}>
                        Lecture {lecture}
                        {items.length > 1 && (
                          <span className="block text-[10px] text-ink-400 font-sans mt-0.5">{items.length} files</span>
                        )}
                      </td>
                    )}
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2 min-w-0">
                        <FileArchive size={15} className="text-violet-600 shrink-0" />
                        <div className="min-w-0">
                          <p className="text-xs font-semibold text-ink-800 truncate">{fileName(m.file)}</p>
                          {m.note && <p className="text-[11px] text-ink-500 truncate">{m.note}</p>}
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-xs text-ink-600">v{m.version}</td>
                    <td className="px-4 py-3 text-xs text-ink-600">
                      {new Date(m.uploaded_at).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-end gap-2">
                        <a
                          href={m.file} target="_blank" rel="noopener noreferrer"
                          className="btn-secondary !py-1.5 !px-2.5 !text-[11px] shrink-0"
                        >
                          <Download size={12} /> Download
                        </a>
                        {isTeacher && (
                          <button
                            onClick={() => handleDelete(m.id)}
                            disabled={deletingId === m.id}
                            aria-label="Delete this file"
                            className="btn-danger !py-1.5 !px-2.5 !text-[11px] shrink-0"
                          >
                            <Trash2 size={12} /> {deletingId === m.id ? '…' : 'Delete'}
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
