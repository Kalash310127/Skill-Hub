import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { Circle } from 'lucide-react'
import { listNotifications, markAllNotificationsRead, markNotificationRead } from '../api/exchanges'
import { useNotifications } from '../context/NotificationsContext'
import Loader from '../components/ui/Loader'
import ErrorNote from '../components/ui/ErrorNote'

export default function Notifications() {
  const [notes, setNotes] = useState([])
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(true)
  const { refreshUnreadCount } = useNotifications() ?? {}

  useEffect(() => {
    listNotifications()
      .then(({ data }) => setNotes(data.results ?? data))
      .catch(() => setError('Could not load notifications.'))
      .finally(() => setLoading(false))
  }, [])

  // Viewing this page is "reading" the list, WhatsApp-style — clear the
  // navbar badge once everything's loaded, without waiting for individual
  // clicks on each notification.
  useEffect(() => {
    if (loading || notes.every((n) => n.is_read)) return
    markAllNotificationsRead()
      .then(() => {
        setNotes((prev) => prev.map((n) => ({ ...n, is_read: true })))
        refreshUnreadCount?.()
      })
      .catch(() => {})
  }, [loading, notes, refreshUnreadCount])

  const handleClick = (note) => {
    if (!note.is_read) {
      markNotificationRead(note.id).catch(() => {})
    }
  }

  if (loading) return <Loader label="Loading notifications" />

  return (
    <div className="max-w-3xl mx-auto px-5 py-14">
      <p className="font-mono text-xs uppercase tracking-widest text-violet-600 mb-2">Session updates</p>
      <h1 className="font-display text-3xl font-semibold">Notifications</h1>
      <ErrorNote>{error}</ErrorNote>
      <div className="mt-7 space-y-3">
        {notes.length ? (
          notes.map((note) => (
            <Link
              key={note.id}
              to={`/sessions/${note.skill_request}`}
              onClick={() => handleClick(note)}
              className={`ticket p-4 flex items-start gap-3 hover:-translate-y-0.5 transition-transform ${
                note.is_read ? '' : 'bg-violet-50'
              }`}
            >
              {!note.is_read && <Circle size={8} className="mt-1.5 shrink-0 fill-violet-600 text-violet-600" />}
              <div className={note.is_read ? '' : 'flex-1'}>
                <p className="font-semibold">{note.title}</p>
                <p className="text-sm text-ink-600 mt-1">{note.body}</p>
                <p className="font-mono text-[11px] text-ink-400 mt-2">{new Date(note.created_at).toLocaleString()}</p>
              </div>
            </Link>
          ))
        ) : (
          <p className="text-ink-600">No notifications yet.</p>
        )}
      </div>
    </div>
  )
}
