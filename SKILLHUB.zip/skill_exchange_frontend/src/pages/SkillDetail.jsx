import { useEffect, useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { getSkill } from '../api/skills'
import { getPublicProfile } from '../api/auth'
import { sendRequest } from '../api/exchanges'
import { useAuth } from '../context/AuthContext'
import { LevelStamp } from '../components/ui/Badge'
import StarRating from '../components/ui/StarRating'
import Loader from '../components/ui/Loader'
import ErrorNote from '../components/ui/ErrorNote'
import { formatError } from '../components/skills/SkillForm'
import { categoryPillClasses } from '../utils/categoryColor'
import { formatExperience } from '../utils/experience'
import { GraduationCap } from 'lucide-react'

export default function SkillDetail() {
  const { id } = useParams()
  const { user } = useAuth()
  const navigate = useNavigate()
  const [skill, setSkill] = useState(null)
  const [teacher, setTeacher] = useState(null)
  const [loading, setLoading] = useState(true)
  const [message, setMessage] = useState('')
  const [error, setError] = useState('')
  const [sent, setSent] = useState(false)
  const [sending, setSending] = useState(false)

  useEffect(() => {
    setLoading(true)
    getSkill(id)
      .then(({ data }) => {
        setSkill(data)
        return getPublicProfile(data.user)
      })
      .then(({ data }) => setTeacher(data))
      .catch(() => setError('Could not load this listing.'))
      .finally(() => setLoading(false))
  }, [id])

  const submitRequest = async (e) => {
    e.preventDefault()
    setError('')
    setSending(true)
    try {
      await sendRequest({ skill: skill.id, message })
      setSent(true)
    } catch (err) {
      setError(formatError(err))
    } finally {
      setSending(false)
    }
  }

  if (loading) return <Loader label="Fetching listing" />
  if (!skill) return <div className="max-w-3xl mx-auto px-5 py-16"><ErrorNote>{error || 'Listing not found.'}</ErrorNote></div>

  const isOwner = user?.id === skill.user

  return (
    <div className="max-w-3xl mx-auto px-5 py-14">
      <button onClick={() => navigate(-1)} className="font-mono text-xs uppercase tracking-widest text-ink-400 hover:text-ink-800">← Back to the board</button>

      <div className="ticket p-7 pt-6 mt-6">
        <div className="flex items-start justify-between gap-4">
          <span className="font-mono text-xs text-ink-400">#{String(skill.id).padStart(4, '0')}</span>
          <LevelStamp level={skill.level} />
        </div>

        <h1 className="font-display text-3xl font-semibold mt-4">{skill.title}</h1>
        {skill.category_name && (
          <span className={`text-[11px] font-semibold px-2.5 py-1 rounded-full ${categoryPillClasses(skill.category_name)}`}>
            {skill.category_name}
          </span>
        )}
        {formatExperience(skill.experience_months) && (
          <p className="mt-3 text-xs font-mono text-ink-600 flex items-center gap-1.5">
            <GraduationCap size={14} />
            {formatExperience(skill.experience_months)} of experience with this skill
          </p>
        )}

        <p className="text-ink-700 mt-5 leading-relaxed whitespace-pre-wrap">
          {skill.description || 'No description provided.'}
        </p>

        <div className="mt-7 pt-6 border-t border-ink-800/10 flex items-center justify-between flex-wrap gap-3">
          <div>
            {user ? (
              <Link to={`/users/${skill.user}`} className="font-display text-lg font-semibold hover:underline">
                @{skill.username}
              </Link>
            ) : (
              <span className="font-display text-lg font-semibold">@{skill.username}</span>
            )}
            {teacher?.rating && (
              <div className="mt-1">
                <StarRating value={teacher.rating.average_rating || 0} count={teacher.rating.review_count} />
                <p className="font-mono text-[11px] uppercase tracking-wider text-moss-600 mt-1">{teacher.completed_sessions} verified session{teacher.completed_sessions === 1 ? '' : 's'} completed</p>
              </div>
            )}
          </div>
          {isOwner && (
            <Link to="/my-skills" className="btn-secondary !py-2 !px-3 !text-xs">Manage this listing</Link>
          )}
        </div>
      </div>

      {!isOwner && (
        <div className="mt-8">
          <h2 className="font-display text-xl font-semibold mb-4">Request to learn this</h2>
          {!user ? (
            <p className="text-ink-600">
              <Link to="/login" className="underline font-semibold text-ink-900">Log in</Link> to send a request to @{skill.username}.
            </p>
          ) : sent ? (
            <p className="text-moss-600 font-semibold">Request sent — @{skill.username} will get back to you.</p>
          ) : (
            <form onSubmit={submitRequest} className="ticket p-6 pt-5 space-y-4">
              <ErrorNote>{error}</ErrorNote>
              <div>
                <label className="label">Message</label>
                <textarea className="input min-h-[100px]" required value={message} onChange={(e) => setMessage(e.target.value)} placeholder={`Tell @${skill.username} what you're hoping to learn and when you're free.`} />
              </div>
              <button className="btn-primary" disabled={sending}>{sending ? 'Sending…' : 'Send request'}</button>
            </form>
          )}
        </div>
      )}
    </div>
  )
}
