import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import ErrorNote from '../components/ui/ErrorNote'
import PasswordInput from '../components/ui/PasswordInput'
import { formatError } from '../components/skills/SkillForm'

export default function Register() {
  const { register } = useAuth()
  const navigate = useNavigate()
  const [form, setForm] = useState({
    username: '', email: '', first_name: '', last_name: '', password: '', password2: '',
  })
  const [error, setError] = useState('')
  const [saving, setSaving] = useState(false)

  const change = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.value }))

  const submit = async (e) => {
    e.preventDefault()
    setError('')
    setSaving(true)
    try {
      await register(form)
      navigate('/')
    } catch (err) {
      setError(formatError(err))
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="max-w-md mx-auto px-5 py-20">
      <p className="font-mono text-xs uppercase tracking-widest text-amber-600 mb-2">Pull up a chair</p>
      <h1 className="font-display text-3xl font-semibold mb-8">Join the board</h1>
      <form onSubmit={submit} className="ticket p-6 pt-5 space-y-4">
        <ErrorNote>{error}</ErrorNote>
        <div>
          <label className="label">Username</label>
          <input className="input" required value={form.username} onChange={change('username')} />
        </div>
        <div>
          <label className="label">Email</label>
          <input className="input" type="email" required value={form.email} onChange={change('email')} />
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="label">First name</label>
            <input className="input" value={form.first_name} onChange={change('first_name')} />
          </div>
          <div>
            <label className="label">Last name</label>
            <input className="input" value={form.last_name} onChange={change('last_name')} />
          </div>
        </div>
        <div>
          <label className="label">Password</label>
          <PasswordInput required value={form.password} onChange={change('password')} />
        </div>
        <div>
          <label className="label">Confirm password</label>
          <PasswordInput required value={form.password2} onChange={change('password2')} />
        </div>
        <button className="btn-primary w-full" disabled={saving}>{saving ? 'Creating account…' : 'Create account'}</button>
      </form>
      <p className="text-sm text-ink-600 mt-5 text-center">
        Already have a pass? <Link to="/login" className="text-ink-900 font-semibold underline">Log in</Link>
      </p>
    </div>
  )
}
