import { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { Sparkles } from 'lucide-react'
import { getPublicProfile } from '../api/auth'
import { listSkills } from '../api/skills'
import { listReviews } from '../api/reviews'
import StarRating from '../components/ui/StarRating'
import SkillCard from '../components/skills/SkillCard'
import ReviewCard from '../components/reviews/ReviewCard'
import AchievementsGrid from '../components/achievements/AchievementsGrid'
import Loader from '../components/ui/Loader'
import ErrorNote from '../components/ui/ErrorNote'

export default function PublicProfile() {
  const { id } = useParams()
  const [profile, setProfile] = useState(null)
  const [skills, setSkills] = useState([])
  const [reviews, setReviews] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    setLoading(true)
    Promise.all([getPublicProfile(id), listSkills({ user: id }), listReviews(id)])
      .then(([pRes, sRes, rRes]) => {
        setProfile(pRes.data)
        setSkills(sRes.data.results ?? sRes.data)
        setReviews(rRes.data.results ?? rRes.data)
      })
      .catch(() => setError('Could not find this trader.'))
      .finally(() => setLoading(false))
  }, [id])

  if (loading) return <Loader label="Pulling up their card" />
  if (!profile) return <div className="max-w-3xl mx-auto px-5 py-16"><ErrorNote>{error}</ErrorNote></div>

  return (
    <div className="max-w-4xl mx-auto px-5 py-14">
      <div className="ticket p-7 pt-6">
        <p className="font-mono text-xs uppercase tracking-widest text-amber-600 mb-1">Trading card</p>
        <div className="flex items-center gap-2 flex-wrap">
          <h1 className="font-display text-3xl font-semibold">
            {profile.first_name ? `${profile.first_name} ${profile.last_name}` : `@${profile.username}`}
          </h1>
          {profile.is_standout_teacher && (
            <span className="stamp bg-amber-100 text-amber-700 flex items-center gap-1">
              <Sparkles size={12} /> Standout teacher
            </span>
          )}
        </div>
        <p className="font-mono text-xs text-ink-400 mt-1">@{profile.username}</p>

        {profile.profile?.bio && <p className="text-ink-700 mt-5 leading-relaxed">{profile.profile.bio}</p>}
        {profile.profile?.location && <p className="font-mono text-xs text-ink-500 mt-2">📍 {profile.profile.location}</p>}

        <div className="mt-5 pt-5 border-t border-ink-800/10">
          <StarRating value={profile.rating?.average_rating || 0} count={profile.rating?.review_count} />
        </div>
      </div>

      <AchievementsGrid achievements={profile.achievements} heading="Skills learned" />

      <div className="mt-10">
        <h2 className="font-display text-xl font-semibold mb-4">Skills offered</h2>
        {skills.length === 0 ? (
          <p className="text-ink-600">No listings from @{profile.username} yet.</p>
        ) : (
          <div className="grid sm:grid-cols-2 gap-5">
            {skills.map((s) => <SkillCard key={s.id} skill={s} />)}
          </div>
        )}
      </div>

      {reviews.length > 0 && (
        <div className="mt-10">
          <h2 className="font-display text-xl font-semibold mb-4">Reviews</h2>
          <div className="ticket p-6 pt-4">
            {reviews.map((r) => <ReviewCard key={r.id} review={r} />)}
          </div>
        </div>
      )}
    </div>
  )
}
