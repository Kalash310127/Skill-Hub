import { useState } from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import ErrorNote from '../components/ui/ErrorNote'
import PasswordInput from '../components/ui/PasswordInput'
import { formatError } from '../components/skills/SkillForm'

export default function Login() {
  const { login } = useAuth()
  const navigate = useNavigate()
  const location = useLocation()
  const [form, setForm] = useState({ username: '', password: '' })
  const [error, setError] = useState('')
  const [saving, setSaving] = useState(false)

  const submit = async (e) => {
    e.preventDefault()
    setError('')
    setSaving(true)
    try {
      await login(form.username, form.password)
      navigate(location.state?.from?.pathname || '/')
    } catch (err) {
      setError(err?.response?.data?.detail || formatError(err) || 'Could not log in. Check your details.')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="max-w-md mx-auto px-5 py-20">
      <p className="font-mono text-xs uppercase tracking-widest text-amber-600 mb-2">Welcome back</p>
      <h1 className="font-display text-3xl font-semibold mb-8">Log in to the board</h1>
      <form onSubmit={submit} className="ticket p-6 pt-5 space-y-4">
        <ErrorNote>{error}</ErrorNote>
        <div>
          <label className="label">Username</label>
          <input className="input" required value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })} />
        </div>
        <div>
          <label className="label">Password</label>
          <PasswordInput required value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
        </div>
        <button className="btn-primary w-full" disabled={saving}>{saving ? 'Logging in…' : 'Log in'}</button>
      </form>
      <p className="text-sm text-ink-600 mt-5 text-center">
        New here? <Link to="/register" className="text-ink-900 font-semibold underline">Create an account</Link>
      </p>
    </div>
  )
}
