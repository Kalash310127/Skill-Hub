import { useEffect, useState } from 'react'
import { listRequests, acceptRequest, rejectRequest, cancelRequest, completeRequest, setMeetLink } from '../api/exchanges'
import { createReview, listReviews } from '../api/reviews'
import { useAuth } from '../context/AuthContext'
import RequestCard from '../components/requests/RequestCard'
import ReviewForm from '../components/reviews/ReviewForm'
import Modal from '../components/ui/Modal'
import Loader from '../components/ui/Loader'
import ErrorNote from '../components/ui/ErrorNote'

const ACTIONS = { accept: acceptRequest, reject: rejectRequest, cancel: cancelRequest, complete: completeRequest }

export default function Requests() {
  const { user } = useAuth()
  const [requests, setRequests] = useState([])
  const [tab, setTab] = useState('received')
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [busyId, setBusyId] = useState(null)
  const [reviewTarget, setReviewTarget] = useState(null)
  const [myReviews, setMyReviews] = useState([])

  const load = () => {
    setLoading(true)
    Promise.all([listRequests(), listReviews()])
      .then(([reqRes, revRes]) => {
        setRequests(reqRes.data.results ?? reqRes.data)
        setMyReviews(revRes.data.results ?? revRes.data)
      })
      .catch(() => setError('Could not load your requests.'))
      .finally(() => setLoading(false))
  }

  useEffect(() => { if (user) load() }, [user])

  const received = requests.filter((r) => r.teacher_username === user?.username)
  const sent = requests.filter((r) => r.requester_username === user?.username)
  const reviewedIds = new Set(myReviews.filter((r) => r.reviewer_username === user?.username).map((r) => r.skill_request))

  const handleAction = async (action, id) => {
    if (action === 'review') {
      const req = requests.find((r) => r.id === id)
      setReviewTarget(req)
      return
    }
    setBusyId(id)
    setError('')
    try {
      await ACTIONS[action](id)
      load()
    } catch (err) {
      setError(err?.response?.data?.detail || 'That action could not be completed.')
    } finally {
      setBusyId(null)
    }
  }

  const submitReview = async ({ rating, comment }) => {
    await createReview({ skill_request: reviewTarget.id, rating, comment })
    setReviewTarget(null)
    load()
  }

  const handleSetMeetLink = async (id, link) => {
    await setMeetLink(id, link)
    load()
  }

  const list = tab === 'received' ? received : sent

  return (
    <div className="max-w-4xl mx-auto px-5 py-14">
      <p className="font-mono text-xs uppercase tracking-widest text-amber-600 mb-2">The exchange desk</p>
      <h1 className="font-display text-3xl font-semibold mb-8">Your requests</h1>

      <div className="flex gap-2 mb-8 border-b border-ink-800/15">
        {['received', 'sent'].map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`font-mono text-xs uppercase tracking-widest px-4 py-3 border-b-2 -mb-px transition-colors ${
              tab === t ? 'border-ink-800 text-ink-900' : 'border-transparent text-ink-400 hover:text-ink-700'
            }`}
          >
            {t} ({t === 'received' ? received.length : sent.length})
          </button>
        ))}
      </div>

      {error && <ErrorNote>{error}</ErrorNote>}
      {loading ? (
        <Loader label="Checking the desk" />
      ) : list.length === 0 ? (
        <p className="text-ink-600 font-display text-lg py-10">
          {tab === 'received' ? 'No one has requested your skills yet.' : "You haven't sent any requests yet — go browse the board."}
        </p>
      ) : (
        <div className="grid sm:grid-cols-2 gap-5">
          {list.map((req) => (
            <RequestCard
              key={req.id}
              request={{ ...req, review: reviewedIds.has(req.id) }}
              perspective={tab}
              busy={busyId === req.id}
              onAction={handleAction}
              onSetMeetLink={handleSetMeetLink}
            />
          ))}
        </div>
      )}

      {reviewTarget && (
        <Modal title={`Rate @${reviewTarget.teacher_username}`} onClose={() => setReviewTarget(null)}>
          {reviewedIds.has(reviewTarget.id) ? (
            <p className="text-ink-600">You've already reviewed this exchange. Thanks for the feedback!</p>
          ) : (
            <ReviewForm onSubmit={submitReview} onCancel={() => setReviewTarget(null)} />
          )}
        </Modal>
      )}
    </div>
  )
}
