import { Link } from 'react-router-dom'

export default function NotFound() {
  return (
    <div className="max-w-lg mx-auto px-5 py-28 text-center">
      <p className="font-mono text-xs uppercase tracking-widest text-clay-500 mb-3">Stamped: void</p>
      <h1 className="font-display text-4xl font-semibold mb-4">This ticket doesn't exist</h1>
      <p className="text-ink-600 mb-8">The listing or page you're after isn't on the board.</p>
      <Link to="/" className="btn-primary">Back to the board</Link>
    </div>
  )
}
