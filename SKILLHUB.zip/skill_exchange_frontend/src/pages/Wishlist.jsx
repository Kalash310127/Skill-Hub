import { useEffect, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { addWishlistItem, deleteWishlistItem, listWishlist } from '../api/skills'
import Loader from '../components/ui/Loader'
import ErrorNote from '../components/ui/ErrorNote'

export default function Wishlist() {
  const navigate = useNavigate()
  const [items, setItems] = useState([]); const [title, setTitle] = useState(''); const [notes, setNotes] = useState(''); const [error, setError] = useState(''); const [loading, setLoading] = useState(true)
  const load = () => { setLoading(true); listWishlist().then(({ data }) => setItems(data.results ?? data)).catch(() => setError('Could not load your wishlist.')).finally(() => setLoading(false)) }
  useEffect(load, [])
  const add = async (e) => { e.preventDefault(); try { await addWishlistItem({ title, notes }); setTitle(''); setNotes(''); load() } catch (err) { setError(err?.response?.data?.title?.[0] || 'Could not add that skill.') } }
  return <div className="max-w-3xl mx-auto px-5 py-14"><p className="font-mono text-xs uppercase tracking-widest text-violet-600 mb-2">Learning intentions</p><h1 className="font-display text-3xl font-semibold">Skills I want to learn</h1><p className="text-ink-600 mt-2">Keep a separate list of interests without turning each one into an active request. Tap the heart on any listing to add it here too.</p>
    <form onSubmit={add} className="ticket p-5 mt-7 space-y-3"><ErrorNote>{error}</ErrorNote><input required className="input" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. GraphQL API design" /><textarea className="input min-h-[80px]" value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Optional notes: goal, preferred level, availability" /><button className="btn-primary">Add to wishlist</button></form>
    {loading ? <Loader label="Loading wishlist" /> : <div className="mt-6 space-y-3">{items.length ? items.map((item) => <div
        key={item.id}
        onClick={() => item.skill && navigate(`/skills/${item.skill}`)}
        className={`ticket p-4 flex justify-between gap-3 ${item.skill ? 'cursor-pointer hover:-translate-y-0.5 hover:shadow-lift transition-all' : ''}`}
      >
        <div>
          <h2 className="font-display text-lg font-semibold">{item.skill ? <Link to={`/skills/${item.skill}`} className="hover:underline" onClick={(e) => e.stopPropagation()}>{item.title}</Link> : item.title}</h2>
          {item.notes && <p className="text-sm text-ink-600 mt-1">{item.notes}</p>}
          {item.skill && <p className="text-[11px] text-ink-400 mt-1">♥ from a listing — click to view it</p>}
        </div>
        <button className="btn-secondary !py-2 !px-3 !text-xs shrink-0" onClick={(e) => { e.stopPropagation(); deleteWishlistItem(item.id).then(load) }}>Remove</button>
      </div>) : <p className="text-ink-600 mt-8">Your wishlist is empty. Add a skill you want to explore.</p>}</div>}
  </div>
}
