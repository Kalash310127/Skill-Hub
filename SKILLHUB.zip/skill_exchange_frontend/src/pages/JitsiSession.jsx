import { useEffect, useRef, useState } from 'react'
import { Link, useParams, useNavigate } from 'react-router-dom'
import { CheckCircle2 } from 'lucide-react'
import { getRequest } from '../api/exchanges'
import Loader from '../components/ui/Loader'
import ErrorNote from '../components/ui/ErrorNote'

const JITSI_DOMAIN = 'meet.jit.si'
const EXTERNAL_API_SRC = `https://${JITSI_DOMAIN}/external_api.js`

// Loads the Jitsi IFrame API script once and reuses it on subsequent visits.
function loadJitsiScript() {
  return new Promise((resolve, reject) => {
    if (window.JitsiMeetExternalAPI) return resolve()
    const existing = document.querySelector(`script[src="${EXTERNAL_API_SRC}"]`)
    if (existing) {
      existing.addEventListener('load', () => resolve())
      existing.addEventListener('error', reject)
      return
    }
    const script = document.createElement('script')
    script.src = EXTERNAL_API_SRC
    script.async = true
    script.onload = () => resolve()
    script.onerror = reject
    document.body.appendChild(script)
  })
}

export default function JitsiSession() {
  const { id } = useParams()
  const navigate = useNavigate()
  const containerRef = useRef(null)
  const apiRef = useRef(null)
  const [request, setRequest] = useState(null)
  const [error, setError] = useState('')
  const [ended, setEnded] = useState(false)

  useEffect(() => {
    getRequest(id).then(({ data }) => setRequest(data)).catch(() => setError('This Jitsi room is unavailable.'))
  }, [id])

  useEffect(() => {
    if (!request?.meet_link || ended) return

    let cancelled = false
    const roomName = request.meet_link.split('/').pop()

    loadJitsiScript().then(() => {
      if (cancelled || !containerRef.current) return
      const api = new window.JitsiMeetExternalAPI(JITSI_DOMAIN, {
        roomName,
        parentNode: containerRef.current,
        width: '100%',
        height: '100%',
        configOverwrite: { prejoinPageEnabled: true },
      })
      apiRef.current = api

      // The moment the call is ready to close (hangup pressed, or the
      // meeting ends), immediately tear down the embed ourselves — this is
      // what stops Jitsi's own "8x8 / Jitsi as a Service" promo screen from
      // ever having a chance to render, since we never let it get that far.
      api.addEventListener('readyToClose', () => {
        api.dispose()
        apiRef.current = null
        setEnded(true)
      })
    })

    return () => {
      cancelled = true
      apiRef.current?.dispose()
      apiRef.current = null
    }
  }, [request, ended])

  if (error) return <div className="max-w-4xl mx-auto px-5 py-12"><ErrorNote>{error}</ErrorNote></div>
  if (!request) return <Loader label="Opening your Jitsi room" />
  if (!request.meet_link) return <div className="max-w-4xl mx-auto px-5 py-12"><ErrorNote>No Jitsi room has been created yet.</ErrorNote></div>

  return (
    <div className="max-w-6xl mx-auto px-5 py-8">
      <div className="flex justify-between items-center mb-4">
        <div>
          <p className="font-mono text-xs uppercase tracking-widest text-violet-600">Live session</p>
          <h1 className="font-display text-2xl font-semibold">{request.skill_title}</h1>
        </div>
        <Link to="/learning" className="btn-secondary">Back to requests</Link>
      </div>

      {ended ? (
        <div className="w-full h-[72vh] rounded-xl border border-ink-800/15 bg-ink-900 flex flex-col items-center justify-center gap-4 text-white">
          <CheckCircle2 size={40} className="text-emerald-400" />
          <p className="font-display text-xl font-semibold">You've left the call</p>
          <div className="flex gap-3">
            <button className="btn-secondary" onClick={() => setEnded(false)}>Rejoin</button>
            <Link to="/learning" className="btn-primary">Back to Learning</Link>
          </div>
        </div>
      ) : (
        <div ref={containerRef} className="w-full h-[72vh] rounded-xl overflow-hidden border border-ink-800/15 bg-ink-900" />
      )}
    </div>
  )
}
