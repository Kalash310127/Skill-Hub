import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { Clock, Users } from 'lucide-react'
import { listRequests } from '../api/exchanges'
import { useAuth } from '../context/AuthContext'
import Loader from '../components/ui/Loader'
import ErrorNote from '../components/ui/ErrorNote'

const JOIN_WINDOW_MINUTES = 5

function LearningCard({ req }) {
  const sessionAt = req.fixed_session_at ? new Date(req.fixed_session_at) : null
  const joinOpensAt = sessionAt ? new Date(sessionAt.getTime() - JOIN_WINDOW_MINUTES * 60000) : null
  const now = new Date()
  const canJoin = !!req.meet_link && joinOpensAt && now >= joinOpensAt

  return (
    <div className="ticket p-5">
      <div className="flex items-start justify-between gap-3">
        <span className="font-mono text-[11px] text-ink-400">#{String(req.id).padStart(4, '0')}</span>
        {req.is_waitlisted && (
          <span className="text-[11px] font-semibold px-2.5 py-1 rounded-full bg-amber-100 text-amber-700">Waitlisted</span>
        )}
      </div>
      <Link to={`/skills/${req.skill}`} className="font-display text-lg font-semibold mt-3 block hover:underline">
        {req.skill_title}
      </Link>
      <p className="text-xs text-ink-600 mt-1">with <span className="font-semibold text-ink-800">@{req.teacher_username}</span></p>

      {/* Shown every time this page loads, every day, for as long as this
          request stays 'accepted' — it only drops off the list once the
          teacher marks the session complete. */}
      {sessionAt ? (
        <p className="mt-3 text-sm font-mono text-violet-700 flex items-center gap-1.5">
          <Clock size={14} />
          {sessionAt.toLocaleDateString(undefined, { weekday: 'long', month: 'short', day: 'numeric' })} · {sessionAt.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' })}
        </p>
      ) : (
        <p className="mt-3 text-sm text-ink-400">No fixed time set by the teacher yet.</p>
      )}

      {req.is_waitlisted ? (
        <p className="mt-3 text-xs text-amber-700">This slot was full — you'll be notified the moment a seat opens up.</p>
      ) : req.meet_link ? (
        canJoin ? (
          <Link to={`/sessions/${req.id}`} target="_blank" rel="noopener noreferrer" className="btn-primary mt-4 !py-2 !px-4 !text-xs inline-flex">Join session</Link>
        ) : (
          <p className="mt-4 text-[11px] text-ink-400">
            {joinOpensAt ? `Join button unlocks at ${joinOpensAt.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' })}` : 'Waiting on a fixed session time.'}
          </p>
        )
      ) : (
        <p className="mt-4 text-[11px] text-ink-400">The teacher hasn't set up the Jitsi room yet.</p>
      )}
    </div>
  )
}

export default function Learning() {
  const { user } = useAuth()
  const [requests, setRequests] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    if (!user) return
    setLoading(true)
    listRequests()
      .then(({ data }) => setRequests(data.results ?? data))
      .catch(() => setError('Could not load what you\'re learning.'))
      .finally(() => setLoading(false))
  }, [user])

  // A skill you're learning stays fixed here — same learners, same slot —
  // until the teacher marks it complete. No one is added or swapped in
  // partway through; once capacity is set and requests are accepted for a
  // session, that roster doesn't change until it's done.
  const learning = requests.filter(
    (r) => r.requester_username === user?.username && r.status === 'accepted'
  )

  return (
    <div className="max-w-4xl mx-auto px-5 py-14">
      <p className="font-mono text-xs uppercase tracking-widest text-violet-600 mb-2 flex items-center gap-2"><Users size={13} /> In progress</p>
      <h1 className="font-display text-3xl font-semibold mb-2">What you're learning</h1>
      <p className="text-ink-600 mb-8">
        Every skill you've been accepted into, with its date and time — it stays here every day until the teacher marks the session complete.
      </p>

      {error && <ErrorNote>{error}</ErrorNote>}
      {loading ? (
        <Loader label="Gathering your sessions" />
      ) : learning.length === 0 ? (
        <p className="text-ink-600 font-display text-lg py-10">
          Nothing in progress yet. <Link to="/" className="underline">Browse the board</Link> and send a request.
        </p>
      ) : (
        <div className="grid sm:grid-cols-2 gap-5">
          {learning.map((req) => <LearningCard key={req.id} req={req} />)}
        </div>
      )}
    </div>
  )
}
