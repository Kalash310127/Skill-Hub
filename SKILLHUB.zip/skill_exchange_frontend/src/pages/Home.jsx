import { useEffect, useState } from 'react'
import { Search, Shuffle } from 'lucide-react'
import { listSkills, listCategories, listTags, listRandomPicks, listWishlist, toggleWishlist } from '../api/skills'
import { useAuth } from '../context/AuthContext'
import SkillCard from '../components/skills/SkillCard'
import SkillCarousel from '../components/skills/SkillCarousel'
import Loader from '../components/ui/Loader'
import ErrorNote from '../components/ui/ErrorNote'

const LEVELS = ['', 'beginner', 'intermediate', 'advanced']

export default function Home() {
  const [skills, setSkills] = useState([])
  const [categories, setCategories] = useState([])
  const [tags, setTags] = useState([])
  const [tag, setTag] = useState('')
  const [randomPicks, setRandomPicks] = useState([])
  const [wishlistedIds, setWishlistedIds] = useState(new Set())
  const { user } = useAuth()
  const [count, setCount] = useState(0)
  const [next, setNext] = useState(null)
  const [previous, setPrevious] = useState(null)
  const [page, setPage] = useState(1)
  const [search, setSearch] = useState('')
  const [category, setCategory] = useState('')
  const [level, setLevel] = useState('')
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    listCategories().then(({ data }) => setCategories(data.results ?? data)).catch(() => {})
    listTags().then(({ data }) => setTags(data.results ?? data)).catch(() => {})
  }, [])

  const loadRandomPicks = () => {
    listRandomPicks().then(({ data }) => setRandomPicks(data.results ?? data)).catch(() => {})
  }

  // Fetched once per visit — deliberately NOT based on what you've searched
  // for or learned before, so it doesn't just reinforce your own history.
  useEffect(loadRandomPicks, [user])

  useEffect(() => {
    if (!user) return
    listWishlist()
      .then(({ data }) => {
        const items = data.results ?? data
        setWishlistedIds(new Set(items.filter((i) => i.skill).map((i) => i.skill)))
      })
      .catch(() => {})
  }, [user])

  const handleToggleWishlist = async (skill) => {
    // Optimistic update — flip the heart immediately, like Instagram does,
    // then reconcile with the server.
    setWishlistedIds((prev) => {
      const next = new Set(prev)
      next.has(skill.id) ? next.delete(skill.id) : next.add(skill.id)
      return next
    })
    try {
      await toggleWishlist(skill.id)
    } catch {
      // roll back on failure
      setWishlistedIds((prev) => {
        const next = new Set(prev)
        next.has(skill.id) ? next.delete(skill.id) : next.add(skill.id)
        return next
      })
    }
  }

  useEffect(() => {
    setLoading(true)
    setError('')
    const params = { page, ordering: '-created_at' }
    if (search) params.search = search
    if (category) params.category__name = category
    if (level) params.level = level
    if (tag) params.tags__name = tag

    listSkills(params)
      .then(({ data }) => {
        setSkills(data.results ?? data)
        setCount(data.count ?? (data.results ?? data).length)
        setNext(data.next ?? null)
        setPrevious(data.previous ?? null)
      })
      .catch(() => setError('Could not load listings. Is the backend running?'))
      .finally(() => setLoading(false))
  }, [page, search, category, level, tag])

  useEffect(() => setPage(1), [search, category, level, tag])

  return (
    <div>
      <section className="relative overflow-hidden" style={{ background: 'linear-gradient(135deg, #7C5CFC 0%, #FF6B5B 100%)' }}>
        <div className="absolute -top-20 -right-20 w-80 h-80 rounded-full bg-white/10 blur-3xl" />
        <div className="absolute bottom-0 left-1/3 w-64 h-64 rounded-full bg-white/10 blur-3xl" />
        <div className="relative max-w-6xl mx-auto px-5 pt-16 pb-14">
          <p className="font-mono text-xs uppercase tracking-[0.25em] text-white/80">Est. barter, no cash</p>
          <h1 className="font-display text-4xl md:text-5xl font-bold mt-4 max-w-xl leading-[1.1] text-white">
            Trade what you know for what you want to learn.
          </h1>
          <p className="text-white/80 mt-4 max-w-lg">
            Post a skill you can teach, browse what the board is offering, and send a
            request when something catches your eye. No listing fees, no currency — just people teaching people.
          </p>

          <div className="mt-8 flex items-center gap-2 bg-parchment-50 rounded-xl p-1.5 max-w-xl shadow-lift">
            <Search size={18} className="text-ink-400 ml-2" />
            <input
              className="flex-1 bg-transparent outline-none px-2 py-2 text-ink-900 placeholder:text-ink-400"
              placeholder="Search the board — try 'Docker' or 'PostgreSQL'"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
        </div>
      </section>

      {/* Random pick-of-the-day carousel — sits right under the search bar,
          shuffled every load, on purpose unrelated to search/filters/history.
          Shown to logged-out visitors too, not just logged-in users. Hidden
          the moment there's an active search, so it isn't gliding and
          auto-advancing behind/above the search results — unmounting it
          also stops its autoplay timer outright. */}
      {!search && randomPicks.length > 0 && (
        <section className="max-w-6xl mx-auto px-5 pt-10">
          <div className="flex items-center justify-between mb-5">
            <div>
              <p className="font-mono text-xs uppercase tracking-widest text-violet-600">Shuffled, not personalized</p>
              <h2 className="font-display text-2xl font-semibold mt-1">Something random from the board</h2>
            </div>
            <button onClick={loadRandomPicks} className="btn-secondary !py-2 !px-3 !text-xs flex items-center gap-1.5">
              <Shuffle size={13} /> Shuffle again
            </button>
          </div>
          <SkillCarousel skills={randomPicks} wishlistedIds={wishlistedIds} onToggleWishlist={user ? handleToggleWishlist : undefined} />
        </section>
      )}

      <section className="max-w-6xl mx-auto px-5 py-10">
        <div className="flex flex-wrap items-center gap-3 mb-8">
          <select className="input !w-auto" value={category} onChange={(e) => setCategory(e.target.value)}>
            <option value="">All categories</option>
            {categories.map((c) => (
              <option key={c.id} value={c.name}>{c.name}</option>
            ))}
          </select>
          <select className="input !w-auto" value={level} onChange={(e) => setLevel(e.target.value)}>
            {LEVELS.map((l) => (
              <option key={l} value={l}>{l ? l[0].toUpperCase() + l.slice(1) : 'All levels'}</option>
            ))}
          </select>
          <select className="input !w-auto" value={tag} onChange={(e) => setTag(e.target.value)}>
            <option value="">All tags</option>
            {tags.map((t) => <option key={t.id} value={t.name}>#{t.name}</option>)}
          </select>
          <span className="font-mono text-xs text-ink-400 ml-auto">{count} listing{count === 1 ? '' : 's'} on the board</span>
        </div>

        {error && <ErrorNote>{error}</ErrorNote>}
        {loading ? (
          <Loader label="Pinning up listings" />
        ) : skills.length === 0 ? (
          <p className="text-ink-600 py-16 text-center font-display text-lg">
            Nothing here yet. Be the first to post a skill.
          </p>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {skills.map((skill) => (
              <SkillCard
                key={skill.id}
                skill={skill}
                wishlisted={wishlistedIds.has(skill.id)}
                onToggleWishlist={user ? handleToggleWishlist : undefined}
              />
            ))}
          </div>
        )}

        {(next || previous) && (
          <div className="flex justify-center gap-3 mt-10">
            <button className="btn-secondary" disabled={!previous} onClick={() => setPage((p) => p - 1)}>Previous</button>
            <span className="font-mono text-xs text-ink-600 self-center">Page {page}</span>
            <button className="btn-secondary" disabled={!next} onClick={() => setPage((p) => p + 1)}>Next</button>
          </div>
        )}
      </section>
    </div>
  )
}
