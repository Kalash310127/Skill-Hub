import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { Pencil } from 'lucide-react'
import { useAuth } from '../context/AuthContext'
import { listSkills } from '../api/skills'
import { listReviews } from '../api/reviews'
import StarRating from '../components/ui/StarRating'
import SkillCard from '../components/skills/SkillCard'
import ReviewCard from '../components/reviews/ReviewCard'
import AchievementsGrid from '../components/achievements/AchievementsGrid'
import Loader from '../components/ui/Loader'

export default function Profile() {
  const { user } = useAuth()
  const [skills, setSkills] = useState([])
  const [reviews, setReviews] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!user) return
    Promise.all([listSkills({ user: user.id }), listReviews(user.id)])
      .then(([sRes, rRes]) => {
        setSkills(sRes.data.results ?? sRes.data)
        setReviews(rRes.data.results ?? rRes.data)
      })
      .finally(() => setLoading(false))
  }, [user])

  if (!user) return <Loader label="Loading profile" />

  return (
    <div className="max-w-4xl mx-auto px-5 py-14">
      <div className="ticket p-7 pt-6">
        <div className="flex items-start justify-between flex-wrap gap-4">
          <div className="flex items-center gap-4">
            {user.profile?.profile_picture ? (
              <img src={user.profile.profile_picture} alt={user.username} className="h-16 w-16 rounded-full object-cover shrink-0" />
            ) : (
              <div className="h-16 w-16 rounded-full shrink-0 flex items-center justify-center text-white font-display text-lg font-semibold"
                   style={{ background: 'linear-gradient(135deg, #7C5CFC 0%, #FF6B5B 100%)' }}>
                {`${user.first_name?.[0] || user.username?.[0] || '?'}${user.last_name?.[0] || ''}`.toUpperCase()}
              </div>
            )}
            <div>
              <p className="font-mono text-xs uppercase tracking-widest text-amber-600 mb-1">Your trading card</p>
              <h1 className="font-display text-3xl font-semibold">
                {user.first_name ? `${user.first_name} ${user.last_name}` : `@${user.username}`}
              </h1>
              <p className="font-mono text-xs text-ink-400 mt-1">@{user.username}</p>
            </div>
          </div>
          <Link to="/profile/edit" className="btn-secondary">
            <Pencil size={14} /> Edit profile
          </Link>
        </div>

        {user.profile?.bio && <p className="text-ink-700 mt-5 leading-relaxed">{user.profile.bio}</p>}
        {user.profile?.location && (
          <p className="font-mono text-xs text-ink-500 mt-2">📍 {user.profile.location}</p>
        )}

        <div className="mt-5 pt-5 border-t border-ink-800/10">
          <StarRating value={user.rating?.average_rating || 0} count={user.rating?.review_count} />
        </div>
      </div>

      <AchievementsGrid achievements={user.achievements} />

      <div className="mt-10">
        <h2 className="font-display text-xl font-semibold mb-4">Your listings</h2>
        {loading ? <Loader label="Loading" /> : skills.length === 0 ? (
          <p className="text-ink-600">No listings yet. <Link to="/my-skills" className="underline font-semibold text-ink-900">Post one</Link>.</p>
        ) : (
          <div className="grid sm:grid-cols-2 gap-5">
            {skills.map((s) => <SkillCard key={s.id} skill={s} />)}
          </div>
        )}
      </div>

      {reviews.length > 0 && (
        <div className="mt-10">
          <h2 className="font-display text-xl font-semibold mb-4">Reviews received</h2>
          <div className="ticket p-6 pt-4">
            {reviews.map((r) => <ReviewCard key={r.id} review={r} />)}
          </div>
        </div>
      )}
    </div>
  )
}
