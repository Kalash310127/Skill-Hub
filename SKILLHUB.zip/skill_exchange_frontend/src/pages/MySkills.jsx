import { useEffect, useState } from 'react'
import { Plus, Pencil, Trash2 } from 'lucide-react'
import { listSkills, createSkill, updateSkill, deleteSkill } from '../api/skills'
import { useAuth } from '../context/AuthContext'
import { LevelStamp } from '../components/ui/Badge'
import SkillForm from '../components/skills/SkillForm'
import Modal from '../components/ui/Modal'
import Loader from '../components/ui/Loader'
import ErrorNote from '../components/ui/ErrorNote'
import { formatExperience } from '../utils/experience'

export default function MySkills() {
  const { user } = useAuth()
  const [skills, setSkills] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [showCreate, setShowCreate] = useState(false)
  const [editing, setEditing] = useState(null)

  const load = () => {
    setLoading(true)
    listSkills({ user: user.id })
      .then(({ data }) => setSkills(data.results ?? data))
      .catch(() => setError('Could not load your listings.'))
      .finally(() => setLoading(false))
  }

  useEffect(() => { if (user) load() }, [user])

  const handleCreate = async (payload) => {
    await createSkill(payload)
    setShowCreate(false)
    load()
  }

  const handleUpdate = async (payload) => {
    await updateSkill(editing.id, payload)
    setEditing(null)
    load()
  }

  const handleDelete = async (id) => {
    if (!confirm('Remove this listing from the board?')) return
    await deleteSkill(id)
    load()
  }

  return (
    <div className="max-w-4xl mx-auto px-5 py-14">
      <div className="flex items-center justify-between mb-8 flex-wrap gap-3">
        <div>
          <p className="font-mono text-xs uppercase tracking-widest text-amber-600 mb-2">Your stall</p>
          <h1 className="font-display text-3xl font-semibold">Skills you teach</h1>
        </div>
        <button className="btn-primary" onClick={() => setShowCreate(true)}>
          <Plus size={16} /> New listing
        </button>
      </div>

      {error && <ErrorNote>{error}</ErrorNote>}
      {loading ? (
        <Loader label="Gathering your listings" />
      ) : skills.length === 0 ? (
        <p className="text-ink-600 font-display text-lg py-10">You haven't posted anything yet. Put a skill up on the board.</p>
      ) : (
        <div className="grid sm:grid-cols-2 gap-5">
          {skills.map((skill) => (
            <div key={skill.id} className="ticket p-5 pt-4">
              <div className="flex items-start justify-between gap-3">
                <span className="font-mono text-[11px] text-ink-400">#{String(skill.id).padStart(4, '0')}</span>
                <LevelStamp level={skill.level} />
              </div>
              <h3 className="font-display text-lg font-semibold mt-4">{skill.title}</h3>
              {formatExperience(skill.experience_months) && (
                <p className="text-[11px] font-mono text-ink-600 mt-1">{formatExperience(skill.experience_months)} experience</p>
              )}
              <p className="text-sm text-ink-600 mt-2 line-clamp-2">{skill.description || 'No description yet.'}</p>
              <div className="mt-5 pt-3 border-t border-ink-800/10 flex gap-2">
                <button className="btn-secondary !py-1.5 !px-3 !text-xs flex-1" onClick={() => setEditing(skill)}>
                  <Pencil size={13} /> Edit
                </button>
                <button className="btn-danger !py-1.5 !px-3 !text-xs flex-1" onClick={() => handleDelete(skill.id)}>
                  <Trash2 size={13} /> Remove
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {showCreate && (
        <Modal title="Post a new skill" onClose={() => setShowCreate(false)}>
          <SkillForm onSubmit={handleCreate} onCancel={() => setShowCreate(false)} submitLabel="Post listing" />
        </Modal>
      )}
      {editing && (
        <Modal title="Edit listing" onClose={() => setEditing(null)}>
          <SkillForm initial={editing} onSubmit={handleUpdate} onCancel={() => setEditing(null)} submitLabel="Save changes" />
        </Modal>
      )}
    </div>
  )
}
